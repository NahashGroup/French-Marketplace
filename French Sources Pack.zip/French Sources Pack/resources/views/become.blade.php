@extends('layouts.app')

@section('content')
  <div class="row">
    @include('layouts.menu.left')
    <div class="col-lg-9">
      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Devenir vendeur</div>
        <div class="card-body">
          <p class="desc-pre">{{ $settings->become_page }}</p>
                @if(Auth::user()->vendor)
                  <div class="text-center">
                    <button class="btn btn-success" disabled>Vous êtes déjà vendeur !</button>
                  </div>
                @else
                  <div class="text-center">
                      <form method="POST" action="{{ route('become.new.seller') }}">
                          @csrf
                          <h2 class="mb-1">{{ $settings->fee_vendor }} EUR</h2>
                          <p>{{ App\Models\Settings::eurToXMR($settings->fee_vendor) }} XMR</p>
                          <button type="submit" class="btn btn-success">Devenir vendeur</button>
                      </form>
                  </div>
                @endif
        </div>
      </div>
    </div>
  </div>
@endsection