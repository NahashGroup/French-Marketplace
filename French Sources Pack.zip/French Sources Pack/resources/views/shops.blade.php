@extends('layouts.app')

@section('content')
  <div class="row">
    @include('layouts.menu.left')
    <div class="col-lg-9">
      <div class="card mt-4">
        <div class="card-header bg-dark text-white"><p class="mb-0">Boutiques</p></div>
      </div>
      <div class="row">
        @foreach($vendors as $item)
        <div class="col-lg-3">
            <div class="card mt-4">
                <div class="card-body text-center">
                    @if($item->user->picture == "default-avatar.png")
                        <img src="{{ asset('img/default-avatar.png') }}" class="vendor-profil-picture" />
                    @else
                        <img src="{{ asset('storage/'.$item->user->picture) }}" class="vendor-profil-picture" />
                    @endif
                    <p class="mb-0"><a class="mt-2" href="{{ route('profil', $item->user->name) }}" ><span class="badge bg-success">{{ $item->user->name }}</span></a></p>
                        <p class="mb-0">Qualité</p>
                        <div class="progress" role="progressbar" aria-label="Example with label" aria-valuenow="{{ $item->user->totalQualityUserSum($item->user->name) }}" aria-valuemin="0" aria-valuemax="100">
                          <div class="progress-bar" style="width: {{ $item->user->totalQualityUserSum($item->user->name) }}%">{{ $item->user->totalQualityUserSum($item->user->name) }}%</div>
                        </div>
                      <p class="mb-0">Communication</p>
                      <div class="progress" role="progressbar" aria-label="Example with label" aria-valuenow="{{ $item->user->totalCommuUserSum($item->user->name) }}" aria-valuemin="0" aria-valuemax="100">
                        <div class="progress-bar" style="width: {{ $item->user->totalCommuUserSum($item->user->name) }}%">{{ $item->user->totalCommuUserSum($item->user->name) }}%</div>
                      </div>
                      <p class="mb-0">Livraison</p>
                      <div class="progress mb-4" role="progressbar" aria-label="Example with label" aria-valuenow="{{ $item->user->totalDeliUserSum($item->user->name) }}" aria-valuemin="0" aria-valuemax="100">
                        <div class="progress-bar" style="width: {{ $item->user->totalDeliUserSum($item->user->name) }}%">{{ $item->user->totalDeliUserSum($item->user->name) }}%</div>
                      </div>
                    <p class="mb-0"><a class="btn btn-success" href="{{ route('shop', $item->User->name) }}">Voir la boutique</a></p>
                </div>
            </div>
        </div>
        @endforeach
      </div>
    </div>
  </div>
@endsection