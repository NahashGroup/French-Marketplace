@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      @if(App\Models\Settings::test() == 0)
      <div class="card">
        <div class="card-header bg-dark text-white">Portefeuille</div>
        <div class="card-body">
              <label>Montant du portefeuille</label>
              @if($balance['balance'] != 0)
                <h3 class="mb-0"><i class="fa-solid fa-unlock text-success"></i> {{ $monero->atomicToXMRminusFees($balance['unlocked_balance']) }}</h3>
              @else
                <h3 class="mb-0"><i class="fa-solid fa-unlock text-success"></i> 0.000000000000</h3>
              @endif
              @if($balance['balance'] != 0)
                <p><small> Total : {{ $monero->atomicToXMRminusFees($balance['balance']) }}</small></p>
              @else
                <p>Total : 0.000000000000</p>
              @endif
              <div class="form-floating mb-4">
                <input placeholder="Adresse Monero" value="{{ $address['address'] }}" type="text" class="form-control" id="floatingInputGroup1" disabled>
                <label for="floatingInputGroup1">Adresse XMR <span style="color:red">*</span></label>
              </div>
        </div>
      </div>

      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Retrait</div>
        <div class="card-body">
          <form method="POST" action="{{ route('profil.wallet.withdrawal') }}">
            @csrf
            <div class="form-floating mb-4">
              <input placeholder="Montant en Monero" type="text" class="form-control @error('amount') is-invalid @enderror" name="amount" id="floatingInputGroup1">
              <label for="floatingInputGroup1">Montant <span style="color:red">*</span></label>
              @error('amount')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
              @enderror
            </div>
            <div class="form-floating mb-4">
              <input placeholder="Adresse Monero" type="text" class="form-control @error('address') is-invalid @enderror" name="address" id="floatingInputGroup1">
              <label for="floatingInputGroup1">Adresse de Destination <span style="color:red">*</span></label>
              @error('address')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
              @enderror
            </div>
            <button type="submit" class="btn btn-success">Envoyer</button>
          </form>
        </div>
      </div>

      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Dernières transactions - Reçues</div>
        <div class="card-body">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Confirmations</th>
                <th scope="col">Frais</th>
                <th scope="col">Montant</th>
                <th scope="col">Bloqué</th>
              </tr>
            </thead>
            <tbody>
            @if(array_key_exists('in', $trans))
              @foreach($trans['in'] as $i => $item)
                <tr>
                  <td><a target="__blank" href="http://explorer.monerotech.info:6001/tx/{{$item['txid']}}/1">{{ Str::limit($item['txid'], 15) }}</a></td>
                  @if(isset($item['confirmations']))
                  <td>{{ $item['confirmations'] }}</td>
                  @else
                  <td>Aucune confirmation</td>
                  @endif
                  <td>{{ number_format($monero->atomicToXMR($item['fee']), 12) }}</td>
                  <td>{{ number_format($monero->atomicToXMR($item['amount']), 12) }}</td>
                  @if($item['locked'] == true)
                    <td><span class="badge bg-danger">Bloqué</span></td>
                  @else
                    <td><span class="badge bg-success">Débloqué</span></td>
                  @endif
                </tr>
              @endforeach
            @else
              <tr>
                <td colspan="5"><div class="alert alert-warning text-center">Aucune transaction reçue</div></td>
              </tr>
            @endif
            </tbody>
          </table>
        </div>
      </div>

      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Dernières transactions - Envoyées</div>
        <div class="card-body">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Confirmations</th>
                <th scope="col">Frais</th>
                <th scope="col">Montant</th>
                <th scope="col">Bloqué</th>
              </tr>
            </thead>
            <tbody>
            @if(array_key_exists('out', $trans))
              @foreach($trans['out'] as $i => $item)
                <tr>
                  <td><a target="__blank" href="http://explorer.monerotech.info:6001/tx/{{$item['txid']}}/1">{{ Str::limit($item['txid'], 15) }}</a></td>
                  @if(isset($item['confirmations']))
                  <td>{{ $item['confirmations'] }}</td>
                  @else
                  <td>Aucune confirmation</td>
                  @endif
                  <td>{{ number_format($monero->atomicToXMR($item['fee']), 12) }}</td>
                  <td>{{ number_format($monero->atomicToXMR($item['amount']), 12) }}</td>
                  @if($item['locked'] == true)
                    <td><span class="badge bg-danger">Bloqué</span></td>
                  @else
                    <td><span class="badge bg-success">Débloqué</span></td>
                  @endif
                </tr>
              @endforeach
            @else
              <tr>
                <td colspan="5"><div class="alert alert-warning text-center">Aucune transaction envoyée</div></td>
              </tr>
            @endif
            </tbody>
          </table>
        </div>
      </div>


      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Dernières transactions - En attentes</div>
        <div class="card-body">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Confirmations</th>
                <th scope="col">Frais</th>
                <th scope="col">Montant</th>
                <th scope="col">Bloqué</th>
              </tr>
            </thead>
            <tbody>
            @if(array_key_exists('pending', $trans))
              @foreach($trans['pending'] as $i => $item)
                <tr>
                  <td><a target="__blank" href="http://explorer.monerotech.info:6001/tx/{{$item['txid']}}/1">{{ Str::limit($item['txid'], 15) }}</a></td>
                  @if(isset($item['confirmations']))
                  <td>{{ $item['confirmations'] }}</td>
                  @else
                  <td>Aucune confirmation</td>
                  @endif
                  <td>{{ number_format($monero->atomicToXMR($item['fee']), 12) }}</td>
                  <td>{{ number_format($monero->atomicToXMR($item['amount']), 12) }}</td>
                  @if($item['locked'] == true)
                    <td><span class="badge bg-danger">Bloqué</span></td>
                  @else
                    <td><span class="badge bg-success">Débloqué</span></td>
                  @endif
                </tr>
              @endforeach
            @else
              <tr>
                <td colspan="5"><div class="alert alert-warning text-center">Aucune transaction en attente</div></td>
              </tr>
            @endif
            </tbody>
          </table>
        </div>
      </div>
      @else
      <div class="card">
        <div class="card-header bg-dark text-white">Portefeuille</div>
        <div class="card-body">
          <div class="alert alert-warning">Le portefeuille ne fonctionne pas en mode test !</div>
        </div>
      </div>
      @endif
    </div>
  </div>
@endsection