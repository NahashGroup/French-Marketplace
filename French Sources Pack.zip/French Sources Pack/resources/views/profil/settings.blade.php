@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white">Paramètres</div>
        <div class="card-body">
            <form method="POST" action="{{ route('profil.settings.update') }}" >
                @csrf
                @method('PUT')
                <div class="form-floating mb-4">
                  <textarea placeholder="Saisissez votre PGP" style="height:450px" name="pgp" class="form-control mb-4 @error('pgp') is-invalid @enderror">{{ $user->pgp }}</textarea>
                  <label class="form-label">PGP <span style="color:red">*</span></label>
                  @error('pgp')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                  @enderror
                </div>
                <div class="form-check form-switch mb-2">
                  <input @if($user->twofa == 1) checked @endif class="form-check-input" type="checkbox" value="1" name="twofa" role="switch" id="flexSwitchCheckDefault">
                  <label class="form-check-label" for="flexSwitchCheckDefault">2FA</label>
                </div>
                <div class="alert alert-primary">Avec la connexion 2FA, vous devrez utiliser votre clé PGP pour déchiffrer le code qui sera caché dans le message signé</div>
                <button type="submit" class="btn btn-success">Mettre à jour les informations</button>
            </form>
            <hr>
            <form method="POST" action="{{ route('profil.settings.password.update') }}" >
              @csrf
              @method('PUT')
              <div class="form-floating mb-4">
                <input placeholder="Mot de passe" type="password" name="password" class="form-control mb-4 @error('password') is-invalid @enderror" />
                <label class="form-label">Mot de passe <span style="color:red">*</span></label>
                @error('password')
                  <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
              <div class="form-floating mb-4">
                <input placeholder="Confirmer le mot de passe" type="password" name="password_confirmation" class="form-control mb-4" />
                <label class="form-label">Confirmer le mot de passe <span style="color:red">*</span></label>
              </div>
              <button type="submit" class="btn btn-success">Mettre à jour le mot de passe</button>
            </form>
        </div>
      </div>
    </div>
  </div>
@endsection