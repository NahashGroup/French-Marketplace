@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Ticket - {{ $ticket->token }} </p></div>
        <div class="card-body">
            <div class="card div-messenger mb-4">
                <div class="card-body">
                    @foreach($messages as $item)
                            <div class="d-flex text-white mb-2">
                                <div class="flex-shrink-0 me-2">
                                        <a target="__blank" href="{{ route('profil', $item->user->name) }}">
                                            @if($item->user->picture == "default-avatar.png")
                                                <img class="rounded-circle" height="50" src="{{ asset('img/default-avatar.png') }}" alt="...">
                                            @else
                                                <img class="rounded-circle" height="50" src="{{ asset('storage/'.$item->user->picture) }}" alt="...">
                                            @endif
                                        </a>
                                </div>
                                <div class="p-3 w-100 @if($item->user_id == Auth::user()->id) @if($item->admin) bg-danger div-message-admin @else bg-success div-message-me @endif @else div-message-not-me bg-dark @endif">
                                    <div class="ms-3">
                                        <div class="">
                                            <a target="__blank" class="text-decoration-none text-white" href="{{ route('profil', $item->user->name) }}"><p class="mb-2">{{ $item->user->name }}</p></a>
                                        </div>
                                        <p style="clear:both" class="mb-0">{{ $item->message }}</p>
                                    </div>
                                    <div class="float-end">
                                        <span class="badge @if($item->user_id == Auth::user()->id) bg-dark @else bg-success @endif"><small>{{\Carbon\Carbon::parse($item->created_at)->diffForHumans()}}</small></span>
                                    </div>
                                </div>
                            </div>              
                    @endforeach
                </div>
            </div>
            @if($ticket->status == 0)
            <form method="POST" action="{{ route('profil.ticket.send', $ticket->token) }}">
                @csrf
                <div class="form-floating mb-4">
                    <textarea placeholder="Saisissez votre message" style="height:100px" name="message" class="form-control mb-4 @error('message') is-invalid @enderror"></textarea>
                    <label class="form-label">Message <span style="color:red">*</span></label>
                    @error('message')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <button type="submit" class="btn btn-success">Envoyer</button>
            </form>
            @else
                <button class="btn btn-success" disabled>Ticket résolu</button>
            @endif
        </div>
      </div>
    </div>
  </div>
@endsection