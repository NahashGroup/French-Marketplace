@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Support</p><a href="{{ route('profil.ticket.new') }}" class="btn btn-success float-end d-flex"><i class="fa-solid fa-plus"></i></a></div>
        <div class="card-body">
          <form class="d-none d-md-inline-block form-inline w-100" method="GET">
            <div class="input-group">
                <input class="form-control" name="query" type="text" placeholder="Rechercher..." aria-label="Rechercher..." aria-describedby="btnNavbarSearch" />
                <button class="btn btn-success" id="btnNavbarSearch" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
            </div>
          </form>
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">#ID</th>
                    <th scope="col">Sujet</th>
                    <th scope="col">Statut</th>
                    <th scope="col">&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                  @foreach($tickets as $item)
                    <tr>
                      <td class="align-middle">{{ $item->token }}</td>
                      <td class="align-middle">{{ $item->subject }}</td>
                      @if($item->status == 0 )
                        <td class="align-middle"><span class="badge bg-primary">Ouvert</span></td>
                      @else
                        <td class="align-middle"><span class="badge bg-success">Résolu</span></td>
                      @endif
                      <td class="align-middle"><a href="{{ route('profil.ticket.show', $item->token) }}" class="btn btn-success">Voir</a></td>
                    </tr>
                  @endforeach
                  @if($tickets->isEmpty())
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">Aucun résultat</div></td>
                    </tr>
                  @endif
                </tbody>
              </table>
              <div>{{ $tickets->links('pagination::simple-bootstrap-5') }}</div>
        </div>
      </div>
    </div>
  </div>
@endsection