@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Nouveau ticket</p></div>
        <div class="card-body">
            <form method="POST" action="{{ route('profil.ticket.add') }}">
                @csrf
                <div class="form-floating mb-4">
                    <input type="text" value="Problème avec la commande {{ request('title') }}" name="title" class="form-control @error('title') is-invalid @enderror" id="floatingInputGroup1" placeholder="Sujet">
                    <label for="floatingInputGroup1">Titre <span style="color:red">*</span></label>
                    @error('title')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <div class="form-floating mb-4">
                    <select class="form-control mb-4 @error('subject') is-invalid @enderror" name="subject">
                        <option value="report" @if(request('subject') == 'report') selected @endif>Signaler l'utilisateur</option>
                        <option value="order" @if(request('subject') == 'order') selected @endif>Problème de commande</option>
                        <option value="information">Demande d'information</option>
                        <option value="collaborate">Collaborer</option>
                    </select>
                    <label for="floatingInputGroup1">Sujet <span style="color:red">*</span></label>
                    @error('subject')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <div class="form-floating mb-4">
                    <textarea placeholder="Saisissez votre message" style="height:450px" name="message" class="form-control mb-4 @error('message') is-invalid @enderror">{{ old('message') }}</textarea>
                    <label class="form-label">Message <span style="color:red">*</span></label>
                    @error('message')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <div class="form-floating mb-4">
                    {!! captcha_img() !!}
                </div>
                <div class="form-floating mb-4">
                    <input type="text" name="captcha" class="form-control @error('captcha') is-invalid @enderror" id="floatingInputGroup1" placeholder="Captcha ici">
                    <label for="floatingInputGroup1">Captcha <span style="color:red">*</span></label>
                    @error('captcha')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <button type="submit" class="btn btn-success">Envoyer</button>
            </form>
        </div>
      </div>
    </div>
  </div>
@endsection