@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Messages</p> <a href="{{ route('profil.message.new') }}" class="btn btn-success float-end d-flex"><i class="fa-solid fa-plus"></i></a></div>
        <div class="card-body">
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">#ID</th>
                    <th scope="col">Utilisateur</th>
                    <th scope="col">Dernier message</th>
                    <th scope="col">&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                  @foreach($messages as $item)
                    <tr>
                      <td class="align-middle">{{ \Illuminate\Support\Str::limit($item->token, 30, '...') }}</td>
                      @if($item->from_id == Auth::user()->id)
                        <td class="align-middle"><a href="{{ route('profil', $item->to->name) }}" class="badge bg-success text-decoration-none">{{ $item->to->name }}</a></td>
                      @else
                        <td class="align-middle"><a href="{{ route('profil', $item->from->name) }}" class="badge bg-success text-decoration-none">{{ $item->from->name }}</a> </td>
                      @endif
                      <td class="align-middle">{{ \Illuminate\Support\Str::limit($item->last_message, 30, '...') }}</td>
                      <td class="align-middle"><a href="{{ route('profil.message.show', $item->token) }}" class="btn btn-success">Voir</a></td>
                    </tr>
                  @endforeach
                  @if($messages->isEmpty())
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">Aucun résultat</div></td>
                    </tr>
                  @endif
                </tbody>
              </table>
              <div>{{ $messages->links('pagination::simple-bootstrap-5') }}</div>
        </div>
      </div>
    </div>
  </div>
@endsection