@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Nouveau message</p></div>
        <div class="card-body">
            <form method="POST" action="{{ route('profil.message.start') }}">
                @csrf
                <div class="form-floating mb-4">
                    <input placeholder="Saisissez le nom d'utilisateur..." value="{{ request('name') }}" name="name" class="form-control mb-4 @error('name') is-invalid @enderror" />
                    <label class="form-label">Nom d'utilisateur <span style="color:red">*</span></label>
                    @error('name')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <div class="form-floating mb-4">
                    <textarea placeholder="Saisissez votre message" style="height:450px" name="message" class="form-control mb-4 @error('message') is-invalid @enderror"></textarea>
                    <label class="form-label">Message <span style="color:red">*</span></label>
                    @error('message')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <button type="submit" class="btn btn-success">Envoyer</button>
            </form>
        </div>
      </div>
    </div>
  </div>
@endsection