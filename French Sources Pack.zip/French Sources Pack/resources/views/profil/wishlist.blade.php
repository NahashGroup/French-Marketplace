@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Liste de souhaits</p></div>
        <div class="card-body">
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Titre</th>
                    <th scope="col">Prix</th>
                    <th scope="col">&nbsp;</th>
                    <th scope="col">&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                  @foreach($wishlists as $item)
                  <tr>
                    <td class="align-middle">{{ $item->product->name }}</td>
                    <td class="align-middle">{{ $item->product->price }} EUR</td>
                    <td class="align-middle"><a href="{{ route('product', $item->product_token) }}" class="btn btn-success"><i class="fa-solid fa-eye"></i></a></td>
                    <td class="align-middle">
                        <form method="POST" action="{{ route('wishlist.remove', $item->token) }}">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger"><i class="fa-solid fa-trash"></i></button>
                        </form>
                    </td>
                  </tr>
                  @endforeach
                  @if($wishlists->isEmpty())
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">Aucun résultat</div></td>
                    </tr>
                  @endif
                </tbody>
            </table>
        </div>
      </div>
    </div>
  </div>
@endsection