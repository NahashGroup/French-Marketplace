@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white">Tableau de bord</div>
        <div class="card-body">
          <div class="row">
            <div class="col-lg-4">
              <div class="card">
                <div class="card-body text-center text-white bg-dark">
                  <p class="fs-3 mb-0 text-center">{{ $cOrder }}</p>
                  <small class="fs-6">Commandes</small>
                  <hr class="mb-1 mt-1">
                  @if(App\Models\Settings::test() == 1)
                    <a class="text-decoration-none text-white" href="{{ route('order.test.all') }}"><small>Voir en détails</small></a>
                    <span class="badge bg-warning">Mode test</span>
                  @else
                    <a class="text-decoration-none text-white" href="{{ route('order.all') }}"><small>Voir en détails</small></a>
                  @endif
                </div>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="card">
                <div class="card-body text-center text-white bg-dark">
                  <p class="fs-3 mb-0 text-center">{{ $cTicket }}</p>
                  <small class="fs-6">Tickets</small>
                  <hr class="mb-1 mt-1">
                  <a class="text-decoration-none text-white" href="{{ route('profil.ticket.all') }}"><small>Voir en détails</small></a>
                </div>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="card">
                <div class="card-body text-center text-white bg-dark">
                  <p class="fs-3 mb-0 text-center">{{ $cWishlist }}</p>
                  <small class="fs-6">Liste de souhaits</small>
                  <hr class="mb-1 mt-1">
                  <a class="text-decoration-none text-white" href="{{ route('profil.wishlist.all') }}"><small>Voir en détails</small></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="card mt-2">
        <div class="card-header bg-dark text-white">Dernières commandes</div>
        <div class="card-body">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">#ID</th>
                <th scope="col">Prix en XMR</th>
                <th scope="col">Statut</th>
                <th scope="col">&nbsp;</th>
              </tr>
            </thead>
            <tbody>
            @if(App\Models\Settings::test() == 1)
              @foreach($orders as $item)
                <tr>
                  <td class="align-middle">{{ $item->token }}</td>
                  <td class="align-middle">{{ $item->monero_price }} XMR</td>
                  @if($item->status == 0)
                  <td class="align-middle"><span class="badge bg-primary">Nouvelle commande</span></td>
                  @else
                  @if($item->status == 1)
                  <td class="align-middle"><span class="badge bg-success">Adresse envoyée</span></td>
                  @else
                    @if($item->status == 2)
                      <td class="align-middle"><span class="badge bg-success">Commande envoyée</span></td>
                    @else
                      @if($item->status == 3)
                        <td class="align-middle"><span class="badge bg-success">Commande terminée</span></td>
                      @endif
                    @endif
                  @endif
                  @endif
                  <td class="align-middle"><a href="{{ route('order.test.show', $item->token) }}" class="btn btn-success">Voir</a></td>
                </tr>
              @endforeach
              @if($orders->isEmpty())
                <tr>
                  <td colspan="4"><div class="alert alert-warning text-center">Aucune commande</div></td>
                </tr>
              @endif
            @else
              @foreach($orders as $item)
                 <tr>
                  <td class="align-middle">{{ $item->token }}</td>
                  <td class="align-middle">{{ $item->monero_price }} XMR</td>
                  @if($item->status == 0)
                  <td class="align-middle"><span class="badge bg-primary">Nouvelle commande</span></td>
                  @else
                  @if($item->status == 1)
                  <td class="align-middle"><span class="badge bg-success">Adresse envoyée</span></td>
                  @else
                    @if($item->status == 2)
                      <td class="align-middle"><span class="badge bg-success">Commande envoyée</span></td>
                    @else
                      @if($item->status == 3)
                        <td class="align-middle"><span class="badge bg-success">Commande terminée</span></td>
                      @endif
                    @endif
                  @endif
                  @endif
                    <td class="align-middle"><a href="{{ route('order.show', $item->token) }}" class="btn btn-success">Voir</a></td>
                </tr>
              @endforeach
              @if($orders->isEmpty())
                <tr>
                  <td colspan="4"><div class="alert alert-warning text-center">Aucune commande</div></td>
                </tr>
              @endif
            @endif
            </tbody>
          </table>
        </div>
      </div>

      <div class="card mt-2 mb-2">
        <div class="card-header bg-dark text-white">Derniers tickets</div>
        <div class="card-body">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">#ID</th>
                <th scope="col">Sujet</th>
                <th scope="col">Statut</th>
                <th scope="col">&nbsp;</th>
              </tr>
            </thead>
            <tbody>
              @foreach($tickets as $item)
                <tr>
                  <td class="align-middle">{{ $item->token }}</td>
                  <td class="align-middle">{{ $item->subject }}</td>
                  @if($item->status == 0 )
                    <td class="align-middle"><span class="badge bg-primary">Ouvert</span></td>
                  @else
                    <td class="align-middle"><span class="badge bg-success">Résolu</span></td>
                  @endif
                  <td class="align-middle"><a href="{{ route('profil.ticket.show', $item->token) }}" class="btn btn-success">Voir</a></td>
                </tr>
              @endforeach
              @if($tickets->isEmpty())
                <tr>
                  <td colspan="4"><div class="alert alert-warning text-center">Aucun ticket</div></td>
                </tr>
              @endif
            </tbody>
          </table>
        </div>
      </div>

      <div class="card mt-2 mb-2">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Derniers souhaits dans la liste de souhaits</p></div>
        <div class="card-body">
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Titre</th>
                    <th scope="col">Prix</th>
                    <th scope="col">&nbsp;</th>
                    <th scope="col">&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                  @foreach($wishlists as $item)
                  <tr>
                    <td class="align-middle">{{ $item->product->name }}</td>
                    <td class="align-middle">{{ $item->product->price }} EUR</td>
                    <td class="align-middle"><a href="{{ route('product', $item->product_token) }}" class="btn btn-success"><i class="fa-solid fa-eye"></i></a></td>
                    <td class="align-middle">
                        <form method="POST" action="{{ route('wishlist.remove', $item->token) }}">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger"><i class="fa-solid fa-trash"></i></button>
                        </form>
                    </td>
                  </tr>
                  @endforeach
                  @if($wishlists->isEmpty())
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">Aucun souhait dans la liste de souhaits</div></td>
                    </tr>
                  @endif
                </tbody>
            </table>
        </div>
      </div>

    </div>
  </div>
@endsection