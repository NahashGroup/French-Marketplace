@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white">Modifier le profil</div>
        <div class="card-body">
            <form method="POST" action="{{ route('profil.pic.add') }}" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                @if($user->picture == "default-avatar.png")
                  <img class="mb-2" src="{{ asset('img/default-avatar.png') }}" height="100" /><br>
                @else
                  <img class="mb-2" src="{{ asset('storage/'.$user->picture) }}" height="100" /><br>
                @endif
                <label>Photo de profil <span style="color:red">*</span></label>
                <input type="file" class="form-control mb-2 @error('picture') is-invalid @enderror" name="picture" />
                @error('picture')
                  <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                  </span>
                @enderror
                <div class="alert alert-primary">Dimension : 225x225</div>
                <button type="submit" class="btn btn-success">Mettre à jour la photo de profil</button>
            </form>
            <hr>
            <form method="POST" action="{{ route('profil.desc.update') }}">
                @csrf
                @method('PUT')
                <div class="form-floating mb-4">
                  <textarea placeholder="Saisissez votre description" style="height:250px" class="form-control mb-2 @error('description') is-invalid @enderror" name="description">{{ $user->description }}</textarea>
                  @error('description')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                  @enderror
                  <label>Description <span style="color:red">*</span></label>
                </div>
                <button type="submit" class="btn btn-success">Mettre à jour la description</button>
            </form>
        </div>
      </div>
    </div>
  </div>
@endsection