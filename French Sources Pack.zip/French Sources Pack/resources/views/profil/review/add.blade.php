@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Ajouter un avis @if($review->test == 1) <span class="badge bg-warning">Mode test</span> @endif</p></div>
        <div class="card-body">
            <h5>Produit</h5>
            <div class="row mb-4">
                <div class="col-lg-2">
                    <img src="{{ asset('storage/'.$review->product->picture) }}" height="100" />
                </div>
                <div class="col-lg-10">
                    <h5><a class="text-decoration-none text-dark" href="{{ route('product', $review->product->token) }}">{{ $review->product->name }}</a></h5>
                    <p class="mb-0">Commande : {{ $review->order->token }}</p>
                    <p>Prix : {{ $review->order->product_price }} EUR <i>({{ $review->order->monero_price }} XMR)</i></p>
                </div>
            </div>
            <form method="POST" action="{{ route('profil.review.add', $review->token) }}">
                @csrf
                @method('PUT')
                <div class="form-floating mb-4">
                    <textarea style="min-height:250px" name="message" class="form-control @error('message') is-invalid @enderror" id="floatingInputGroup1" placeholder="Message">{{ old('message') }}</textarea>
                    <label for="floatingInputGroup1">Message <span style="color:red">*</span></label>
                    @error('message')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <h5>Note</h5>
                <div class="input-group">
                    <div class="form-floating mb-4">
                        <select class="form-control mb-4 @error('rating_qual') is-invalid @enderror" name="rating_qual">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                        <label for="floatingInputGroup1">Qualité <span style="color:red">*</span></label>
                        @error('rating_qual')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="form-floating mb-4">
                        <select class="form-control mb-4 @error('rating_com') is-invalid @enderror" name="rating_com">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                        <label for="floatingInputGroup1">Communication <span style="color:red">*</span></label>
                        @error('rating_com')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="form-floating mb-4">
                        <select class="form-control mb-4 @error('rating_deli') is-invalid @enderror" name="rating_deli">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                        <label for="floatingInputGroup1">Livraison <span style="color:red">*</span></label>
                        @error('rating_deli')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                </div>
                <div class="form-floating mb-4">
                    {!! captcha_img() !!}
                </div>
                <div class="form-floating mb-4">
                    <input type="text" name="captcha" class="form-control @error('captcha') is-invalid @enderror" id="floatingInputGroup1" placeholder="Captcha ici">
                    <label for="floatingInputGroup1">Captcha <span style="color:red">*</span></label>
                    @error('captcha')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <button type="submit" class="btn btn-success">Envoyer</button>
            </form>
        </div>
      </div>
    </div>
  </div>
@endsection