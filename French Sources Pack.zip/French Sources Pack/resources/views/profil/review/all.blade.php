@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Avis</p></div>
        <div class="card-body">
        @if(App\Models\Settings::test() == 1)
          <div class="alert alert-warning">Le système de notation est désactivé en mode test !</div>
        @else
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Titre</th>
                    <th scope="col">Prix</th>
                    <th scope="col">&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                  @foreach($reviews as $item)
                  <tr>
                    <td class="align-middle">{{ $item->product->name }}</td>
                    <td class="align-middle">{{ $item->product->price }}</td>
                    <td class="align-middle"><a href="{{ route('profil.review.new', $item->token) }}" class="btn btn-success">Ajouter l'avis</a></td>
                  </tr>
                  @endforeach
                  @if($reviews->isEmpty())
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">Aucun résultat</div></td>
                    </tr>
                  @endif
                </tbody>
              </table>
        @endif
        </div>
      </div>
    </div>
  </div>
@endsection