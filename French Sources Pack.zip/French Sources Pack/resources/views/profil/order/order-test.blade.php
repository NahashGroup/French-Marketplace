@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Commande : {{ $order->token }}</p></div>
        <div class="card-body">
            <div class="row">
              <div class="col-lg-6">
                <p class="mb-0"><strong>Client</strong></p>
                <p class="mb-0">Nom d'utilisateur : <a target="__blank" href="{{ route('profil', $order->customer->name) }}" class="badge bg-success text-decoration-none">{{ $order->customer->name }}</a></p>
                <p class="mb-0">Création : {{date('d-m-Y', strtotime($order->created_at))}}</p>
                <p class="mb-0">Paiement : <span class="badge bg-warning">Mode test</span></p>
              </div>
              <div class="col-lg-6">
                <p class="mb-0"><strong>Vendeur</strong></p>
                <p class="mb-0">Nom d'utilisateur : 
                  <a target="__blank" href="{{ route('profil', $order->vendor->user->name) }}" class="badge bg-success text-decoration-none">{{ $order->vendor->user->name }}</a>
                  <a href="{{ route('profil.message.new', ['name' => $order->vendor->user->name]) }}" class="badge bg-success"><i class="fa-solid fa-envelope"></i></a>
                  <a href="{{ route('profil.ticket.new', ['subject' => 'report']) }}" class="badge bg-danger"><i class="fa-solid fa-flag"></i></a>
                </p>
              </div>
            </div>
            <div class="mt-4">
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Photo</th>
                    <th scope="col">Titre</th>
                    <th scope="col">Prix en XMR</th>
                    <th scope="col">Statut</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="align-middle"><img class="mb-2" src="{{ asset('storage/'.$order->product_picture) }}" height="70" /></td>
                    <td class="align-middle">{{ $order->product_name }}</td>
                    <td class="align-middle">{{ $order->monero_price }} XMR</td>
                    @if($order->status == 0)
                      <td class="align-middle"><span class="badge bg-primary">Nouvelle commande</span></td>
                    @else
                      @if($order->status == 1)
                        <td class="align-middle"><span class="badge bg-success">Adresse envoyée</span></td>
                        @else
                          @if($order->status == 2)
                            <td class="align-middle"><span class="badge bg-success">Commande envoyée</span></td>
                          @else
                            @if($order->status == 3)
                              <td class="align-middle"><span class="badge bg-success">Commande terminée</span></td>
                            @endif
                          @endif
                      @endif
                    @endif
                  </tr>
                </tbody>
              </table>
              @if($order->gps == 0)
                @if(empty($order->address))
                <form method="POST" action="{{ route('order.test.address', $order->token) }}">
                  @csrf
                  @method('PUT')
                  <div class="form-floating mb-4">
                    <textarea style="height:280px" placeholder="Saisissez votre adresse de livraison" name="address" class="form-control mb-4"></textarea>
                    <label for="floatingInputGroup1">Adresse <span style="color:red">*</span></label>
                  </div>
                  <button type="submit" class="btn btn-success mb-4">Envoyer l'adresse</button>
                  <div class="alert alert-primary">Votre adresse sera chiffrée avec la clé PGP du vendeur !</div>
                </form>
                @else
                  <div class="form-floating mb-4">
                    <textarea style="height:280px" placeholder="Saisissez votre adresse de livraison" name="address" class="form-control mb-4" disabled>{{ $order->address }}</textarea>
                    <label for="floatingInputGroup1">Adresse <span style="color:red">*</span></label>
                  </div>
                @endif
              @else
                @if($order->status == 2)
                  <div class="form-floating mb-4">
                    <textarea style="height:280px" placeholder="Infos GPS" name="info" class="form-control mb-4" disabled>{{ $gps->info }}</textarea>
                    <label for="floatingInputGroup1">Coordonnées GPS <span style="color:red">*</span></label>
                  </div>
                @else
                  <div class="alert alert-warning">Vous recevrez des instructions du vendeur, avec les coordonnées GPS de l'endroit où se trouve votre produit, ainsi que des informations supplémentaires pour vous aider à le trouver.</div>
                @endif
              @endif
              @if($order->status == 2)
                <form method="POST" action="{{ route('order.test.confirm', $order->token) }}">
                  @csrf
                  @method('PUT')
                  <button type="submit" class="btn btn-success mb-2 float-start">J'ai reçu la commande</div>
                </form>
              @endif
              <a href="{{ route('profil.ticket.new', ['subject' => 'order', 'title' => $order->token]) }}" class="btn btn-danger float-end"><i class="fa-solid fa-flag"></i> Signaler la commande</a>
            </div>
        </div>
      </div>
    </div>
  </div>
@endsection