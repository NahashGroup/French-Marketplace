    <div class="p-2 bg-dark text-white">Profil</div>
    <ul class="list-group">
        <li class="list-group-item"><a class="text-decoration-none" href="{{ route('profil.my.dashboard') }}">Tableau de bord</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="{{ route('profil.edit.profil') }}">Photo de profil & Description</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="{{ route('profil.settings') }}">Paramètres</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="{{ route('profil.wallet') }}">Portefeuille</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="{{ route('profil.wishlist.all') }}">Liste de souhaits</a></li>
        @if(App\Models\Settings::test() == 1)
            <li class="list-group-item"><a class="text-decoration-none" href="{{ route('order.test.all') }}">Commandes <span class="badge bg-warning">Mode test</span></a></li>
        @else
            <li class="list-group-item"><a class="text-decoration-none" href="{{ route('order.all') }}">Commandes</li>
        @endif
        <li class="list-group-item"><a class="text-decoration-none" href="{{ route('profil.review.all') }}">Avis</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="{{ route('profiL.message.all') }}">Messages</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="{{ route('profil.ticket.all') }}">Support</a></li>
    </ul>
    @if(Auth::user()->vendor)
        <div class="p-2 bg-dark text-white mt-4">Vendeur</div>
        <ul class="list-group">
            <li class="list-group-item"><a class="text-decoration-none" href="{{ route('vendor.dashboard') }}">Tableau de bord</a></li>
            <li class="list-group-item"><a class="text-decoration-none" href="{{ route('vendor.settings') }}">Paramètres</a></li>
            <li class="list-group-item"><a class="text-decoration-none" href="{{ route('product.all') }}">Produits</a></li>
            @if(App\Models\Settings::test() == 1)
                <li class="list-group-item"><a class="text-decoration-none" href="{{ route('sale.test.all') }}">Ventes <span class="badge bg-warning">Mode test</span></a></li>
            @else
                <li class="list-group-item"><a class="text-decoration-none" href="{{ route('sale.all') }}">Ventes</li>
            @endif
            <li class="list-group-item"><a class="text-decoration-none" href="{{ route('product.stock.all') }}">Stocks</a></li>
            <li class="list-group-item"><a class="text-decoration-none" href="{{ route('deliveries.all') }}">Modes de livraison</a></li>
        </ul>
    @endif