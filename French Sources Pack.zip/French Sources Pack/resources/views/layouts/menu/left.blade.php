<div class="col-lg-3">
    <div class="card mt-4">
        <div class="card-header bg-dark text-white">Catégories</div>
        <ul class="list-group">
          @foreach (App\Models\Market\Category::allCategorie() as $item)
            @if(!empty($item['children']))
              <a href="{{ route('category', $item['token']) }}" class="list-group-item mt-0"><i class="fas fa-caret-down"></i> {{ $item['name'] }} </a>
              @foreach ($item['children'] as $children)
                <a href="{{ route('category', $children['token']) }}" class="list-group-item mt-0">&nbsp; &nbsp; &nbsp; <i class="fas fa-caret-right"></i> {{ $children['name'] }}</a>
              @endforeach
            @else
              <a href="{{ route('category', $item['token']) }}" class="list-group-item mt-0"><i class="fas fa-caret-right"></i> {{ $item['name'] }}</a>
            @endif
          @endforeach
        </ul>
    </div>
    <div class="card mt-4 mb-4">
      <div class="card-header bg-dark text-white">Filtre de recherche</div>
      <div class="card-body">
        <form method="GET" action="{{ route('search.filter.get') }}">

          <div class="form-floating mb-4 me-2">
            <input placeholder="Rechercher..." value="{{ request()->input('query') }}" name="query" type="text" value="" class="form-control" id="floatingInputGroup1" >
            <label for="floatingInputGroup1">Rechercher <span style="color:red">*</span></label>
          </div>

          <div class="form-floating mt-2">
            <select name="vendor" class="form-select">
              <option value="all" selected>Tous</option>
              @foreach(App\Models\Market\Vendor::get() as $item)
                <option @if(request()->input('vendor') == $item->user->name) selected @endif value="{{ $item->user->name }}">{{ $item->user->name }}</option>
              @endforeach
            </select>
            <label for="floatingInputGroup1">Vendeur <span style="color:red">*</span></label>
            @error('category')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
          </div>
          <div class="mt-4">
            <label class="mb-2">Prix</label>
            <div class="input-group">
              <div class="form-floating mb-4 me-2">
                <input type="text" @if(request()->input('pmin')) value="{{ request()->input('pmin') }}"  @else value="0" @endif name="pmin" class="form-control" id="floatingInputGroup1" >
                <label for="floatingInputGroup1">Min</label>
              </div>
              <div class="form-floating mb-4">
                <input type="text" @if(request()->input('pmax')) value="{{ request()->input('pmax') }}"  @else value="500000" @endif name="pmax" class="form-control" id="floatingInputGroup1" >
                <label for="floatingInputGroup1">Max</label>
              </div>
            </div>
          </div>
          <div class="form-floating mt-4">
            <select class="form-control mb-4 @error('category') is-invalid @enderror" name="cat">
              <option value="all" selected>Toutes</option>
                @foreach(App\Models\Market\Category::allCategorie() as $item)
                    @if(!empty($item['children']))
                    <option @if(request()->input('cat') == $item['token'] ) selected @endif value="{{ $item['token'] }}" >{{ $item['name'] }} </option>
                        @foreach ($item['children'] as $children)
                            <option @if(request()->input('cat') == $children['token'] ) selected @endif value="{{ $children['token'] }}" >-- {{ $children['name'] }}</option>
                        @endforeach
                    @else
                        <option @if(request()->input('cat') == $item['token'] ) selected @endif value="{{ $item['token'] }}" >{{ $item['name'] }}</option>
                    @endif
                @endforeach
            </select>
            <label for="floatingInputGroup1">Catégorie <span style="color:red">*</span></label>
            @error('category')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
          </div>
          <div class="form-floating mt-4 mb-4">
            <select class="form-select" name="sto">
              <option value="all">Monde entier</option>
              @foreach(App\Models\Country::get() as $item)
                <option @if(request()->input('sto') == $item->id ) selected @endif value="{{ $item->id }}">{{ $item->nicename}}</option>
              @endforeach
            </select>
            <label for="floatingInputGroup1">Expédition à <span style="color:red">*</span></label>
            @error('category')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
          </div>
          <div class="d-grid gap-2">
            <button type="submit" class="btn btn-success">Rechercher</button>
          </div>
        </form>
      </div>
    </div>
  </div>