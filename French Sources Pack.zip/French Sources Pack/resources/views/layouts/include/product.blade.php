@foreach($products as $item)
<div class="col-lg-12">
  <div class="card mt-2">
    <div class="card-header bg-dark text-white">Vendeur : <a href="{{ route('profil', $item->vendor->user->name) }}" class="badge bg-success text-decoration-none">{{ $item->vendor->user->name }}</a></div>
    <div class="card-body">
      <div class="product-picture-card">
        <img height="200" src="{{ asset('storage/'.$item->picture) }}" />
      </div>
      <div class="product-info-card">
        <h4 class="mb-0"><a class="text-dark text-decoration-none" href="{{ route('product', $item->token) }}">{{ $item->name }}</a></h4><br>
        <p class="mb-0"><strong>Catégorie</strong> : <a href="{{ route('category', $item->category->token) }}" class="badge bg-success text-decoration-none">{{ $item->category->name }}</a></p>
        <p class="mb-0"><strong>Vendu</strong> : {{ $item->order->count() }}</p>
        <p class="mb-0"><strong>Stock</strong> : 
          @if($item->stock != 0)
            <span class="badge bg-success">En stock</span>
          @else
            <span class="badge bg-danger">En rupture de stock</span>
          @endif
        </p>
        <p class="mb-0"><strong>Expédition</strong> : {{ $item->delivery->country->nicename }}</p>
        <p class="mb-0"><strong>Délai</strong> : {{ $item->delivery->delay }} jours</p>
        @if($item->delivery->gps == 1)
          <p class="mb-0"><strong>Coordonnées GPS : <span class="badge bg-success">Actif</span></strong> </p>
        @else
          <p class="mb-0"><strong>Coordonnées GPS : <span class="badge bg-primary">Inactif</span></strong> </p>
        @endif
      </div>
      <div class="product-buy-card">
          <h4>{{ $item->price }} EUR</h4>
          <a href="{{ route('product', $item->token) }}" class="btn btn-success fs-5 w-100">Acheter</a>
          <p class="mb-0"><small>Qualité</small></p>
          <div class="progress " role="progressbar" aria-label="Example with label" aria-valuenow="{{ $item->qualityReviewSum($item->token) }}" aria-valuemin="0" aria-valuemax="100">
            <div class="progress-bar" style="width: {{ $item->qualityReviewSum($item->token) }}%">{{ $item->qualityReviewSum($item->token) }}%</div>
          </div>
          <p class="mb-0"><small>Communication</small></p>
          <div class="progress" role="progressbar" aria-label="Example with label" aria-valuenow="{{ $item->commuReviewSum($item->token) }}" aria-valuemin="0" aria-valuemax="100">
            <div class="progress-bar" style="width: {{ $item->commuReviewSum($item->token) }}%">{{ $item->commuReviewSum($item->token) }}%</div>
          </div>
          <p class="mb-0"><small>Livraison</small></p>
          <div class="progress" role="progressbar" aria-label="Example with label" aria-valuenow="{{ $item->deliReviewSum($item->token) }}" aria-valuemin="0" aria-valuemax="100">
            <div class="progress-bar" style="width: {{ $item->deliReviewSum($item->token) }}%">{{ $item->deliReviewSum($item->token) }}%</div>
          </div>
      </div>
    </div>
  </div>
</div>
@endforeach