<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Admin Panel</title>
        <link href="{{ asset('css/bootstrap.css') }}" rel="stylesheet" />
        <link href="{{ asset('css/custom.css') }}" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="{{ route('index') }}">{{ env('APP_NAME') }}</a>
            <!-- Navbar Search-->
            <a target="__blank" href="{{ route('index') }}" class="btn btn-success">Voir la place de marché</a>
            <span class="nav-link active ms-4 text-white">Url : {{ $_SERVER['SERVER_NAME'] }}</span>
            <span class="nav-link active ms-4 text-white">Port : {{ $_SERVER['SERVER_PORT'] }}</span>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading text-light">Général</div>
                            <a class="nav-link active" href="{{ route('admin.index') }}">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Tableau de bord
                            </a>
                            <a class="nav-link active" href="{{ route('admin.settings') }}">
                                <div class="sb-nav-link-icon"><i class="fas fa-cog"></i></div>
                                Paramètres
                            </a>
                            <div class="sb-sidenav-menu-heading text-light">Utilisateurs</div>
                            <a class="nav-link active" href="{{ route('admin.customer.all') }}" >
                                <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                                Clients
                            </a>
                            <a class="nav-link active" href="{{ route('admin.vendor.all') }}" >
                                <div class="sb-nav-link-icon"><i class="fas fa-dollar-sign"></i></div>
                                Vendeurs
                            </a>
                            <a class="nav-link active" href="{{ route('admin.user.banned') }}" >
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-ban"></i></div>
                                Bannis
                            </a>
                            <div class="sb-sidenav-menu-heading text-light">Marché</div>
                            <a class="nav-link active" href="{{ route('admin.product.all') }}">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-cart-shopping"></i></div>
                                Produits
                            </a>
                            <a class="nav-link active" href="{{ route('admin.categories') }}">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-list"></i></div>
                                Catégories
                            </a>
                            @if(App\Models\Settings::test() == 1)
                                <a class="nav-link active" href="{{ route('admin.orders.test') }}">
                                    <div class="sb-nav-link-icon"><i class="fa-solid fa-money-bill"></i></div>
                                    Orders <span class="badge bg-warning ms-2">Mode test</span>
                                </a>
                            @else
                                <a class="nav-link active" href="{{ route('admin.orders') }}">
                                    <div class="sb-nav-link-icon"><i class="fa-solid fa-money-bill"></i></div>
                                    Commandes
                                </a>
                            @endif
                            <a class="nav-link active" href="{{ route('admin.support.all') }}">
                                <div class="sb-nav-link-icon"><i class="fa-regular fa-life-ring"></i></div>
                                Support
                            </a>
                            <form method="POST" action="{{ route('logout') }}">
                                @csrf
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-danger ms-2 me-2 mt-4"><i class="fa-solid fa-right-from-bracket"></i> Se déconnecter</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Connecté en tant que:</div>
                        <span class="badge bg-danger"><i class="fas fa-user"></i> {{ Auth::user()->name }}</span>
                    </div>
                </nav>
            </div>

            @yield('content-admin')

        </div>
    </body>
</html>