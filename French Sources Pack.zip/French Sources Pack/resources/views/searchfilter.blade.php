@extends('layouts.app')

@section('content')
  <div class="row">
    @include('layouts.menu.left')
    <div class="col-lg-9">
      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Filtre de recherche
        </div>
      </div>
      <div class="row">
        @include('layouts.include.productfilter')
        <div>{{ $products->links('pagination::simple-bootstrap-5') }}</div>
      </div>
      <div></div>
    </div>
  </div>
@endsection