@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-12">
      <div class="card mt-4">
        <div class="card-body">
            <div class="text-center">
                <h1 class="mb-0" style="font-family:impact;font-size: 100px;">404 Page non trouvée :(<h1>
                <a class="btn btn-success" href="{{ route('index') }}">Retour à l'accueil</a>
            </div>
        </div>
      </div>
    </div>
  </div>
@endsection