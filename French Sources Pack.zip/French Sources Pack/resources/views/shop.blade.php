@extends('layouts.app')

@section('content')
  <div class="row">
    @include('layouts.menu.left')
    <div class="col-lg-9">
      <div class="card mt-4">
        <div class="card-header bg-dark text-white"><p class="mb-0">Boutique de {{ $user->name }}</p></div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-3">
                  @if($user->picture == "default-avatar.png")
                    <img src="{{ asset('img/default-avatar.png') }}" width="200" />
                  @else
                    <img src="{{ asset('storage/'.$user->picture) }}" width="200" />
                  @endif
                </div>
                <div class="col-lg-3">
                    <h3 class="mb-0">{{ $user->name }}</h3>
                    @if($user->vendor)
                      <p class="mb-4"><span class="badge bg-success">Vendeur</span></p>
                    @else
                      @if($user->admin)
                        <p class="mb-4"><span class="badge bg-danger">Admin</span></p>
                      @else
                      <p class="mb-4"><span class="badge bg-success">Client</span></p>
                      @endif
                    @endif
                    @auth
                      @if(Auth::user()->id != $user->id)
                        <a href="{{ route('profil.message.new', ['name' => $user->name]) }}" class="btn btn-success mb-2 profil-button"><i class="fa-solid fa-paper-plane"></i> Envoyer un message</a><br>
                        <a href="{{ route('profil.ticket.new', ['subject' => 'report']) }}" class="btn btn-danger profil-button"><i class="fa-solid fa-flag"></i> Signaler l'utilisateur</a>
                      @endif
                    @endauth
                </div>
                @if($user->vendor)
                <div class="col-lg-5">
                  <h5>Statistiques du vendeur</h5>
                  <hr>
                  <div style="width:100%">
                    <p class="mb-0">Qualité</p>
                    <div class="progress" role="progressbar" aria-label="Example with label" aria-valuenow="{{ $user->totalQualityUserSum($user->name) }}" aria-valuemin="0" aria-valuemax="100">
                      <div class="progress-bar" style="width: {{ $user->totalQualityUserSum($user->name) }}%">{{ $user->totalQualityUserSum($user->name) }}%</div>
                    </div>
                  </div>
                  <p class="mb-0">Communication</p>
                  <div class="progress" role="progressbar" aria-label="Example with label" aria-valuenow="{{ $user->totalCommuUserSum($user->name) }}" aria-valuemin="0" aria-valuemax="100">
                    <div class="progress-bar" style="width: {{ $user->totalCommuUserSum($user->name) }}%">{{ $user->totalCommuUserSum($user->name) }}%</div>
                  </div>
                  <p class="mb-0">Livraison</p>
                  <div class="progress mb-4" role="progressbar" aria-label="Example with label" aria-valuenow="{{ $user->totalDeliUserSum($user->name) }}" aria-valuemin="0" aria-valuemax="100">
                    <div class="progress-bar" style="width: {{ $user->totalDeliUserSum($user->name) }}%">{{ $user->totalDeliUserSum($user->name) }}%</div>
                  </div>
                  <a href="{{ route('profil', $user->name) }}" class="btn btn-success">Voir le profil</a>
                </div>
                @endif
            </div>
        </div>
      </div>
      @if($user->vendor)
        @if($user->vendor->vacation == 1)
          <div class="alert alert-danger mt-4">{{ $user->name }} est actuellement en vacances, vous ne pouvez pas acheter de produits auprès de ce vendeur pour le moment.</div>
        @endif
      @endif
        @if(!empty($user->vendor->desc_shop))
        <div class="col-lg-12">
          <div class="card mt-4">
            <div class="card-header bg-dark text-white">Description de la boutique</div>
            <div class="card-body">
              <p class="desc-profil">{{ $user->vendor->desc_shop }}</div>
            </div>
          </div>
        </div>
        @endif
        <div class="card mt-4">
          <div class="card-header bg-dark text-white">Produits {{ $user->name }}</div>
        </div>
        <div class="row mb-4">
          @include('layouts.include.product')
        </div>
      <div>{{ $products->links('pagination::simple-bootstrap-5') }}</div>
    </div>
  </div>
@endsection