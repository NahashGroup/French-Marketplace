@extends('layouts.app')

@section('content')
  <div class="row">
    @include('layouts.menu.left')
    <div class="col-lg-9">
      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Notifications</div>
        <div class="card-body">
            @if($notifications->isEmpty())
                <div class="alert alert-warning">Aucune notification.</div>
            @else
                @foreach($notifications as $item)
                    @if($item->order_token == NULL and $item->ticket_token == NULL)
                        <div class="alert alert-info">
                            Vous avez reçu un nouveau message de <a class="text-dark text-decoration-none" href="{{ route('profil', $item->from->name) }}">{{ $item->from->name }}</a> sur votre conversation.
                            
                            <form class="float-end" method="POST" action="{{ route('notification.message', $item->message_token) }}">
                                @csrf
                                @method('PUT')
                                <button type="submit" class="float-end button-send"><i class="fas fa-eye"></i></button>
                            </form>

                        </div>
                    @else
                        @if($item->order_token == NULL and $item->message_token == NULL)
                            <div class="alert alert-info">
                                Vous avez reçu un nouveau message de {{ $item->from->name }} sur votre ticket #{{ $item->ticket->token }}.

                                <form class="float-end" method="POST" action="{{ route('notification.message', $item->ticket_token) }}">
                                    @csrf
                                    @method('PUT')
                                    <button type="submit" class="float-end button-send"><i class="fas fa-eye"></i></button>
                                </form>

                            </div>
                        @else
                            <div class="alert alert-info">
                                Vous avez reçu une nouvelle commande de {{ $item->from->name }} pour {{ $item->order->monero_price }} XMR.
                                <form class="float-end" method="POST" action="{{ route('notification.message', $item->order_token) }}">
                                    @csrf
                                    @method('PUT')
                                    <button type="submit" class="float-end button-send"><i class="fas fa-eye"></i></button>
                                </form>
                            </div>
                        @endif
                    @endif
                @endforeach
            <div>{{ $notifications->links('pagination::simple-bootstrap-5') }}</div>
            @endif
        </div>
      </div>
    </div>
  </div>
@endsection