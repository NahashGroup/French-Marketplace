@extends('layouts.start')


@section('content')
<div class="container">
    <div class="card mt-4">
        <div class="card-header bg-dark text-white">2FA - Confirmez votre clé PGP</div>
        <div class="card-body">
            <div class="form-group">
                <div class="form-floating mb-4">
                    <textarea style="min-height:300px" placeholder="Déchiffrez ce message" name="decrypt_message" id="decrypt_message" class="form-control" rows="10" style="resize: none;"  readonly>{{ session()->get('message') }}</textarea>
                    <label for="floatingInputGroup1">Déchiffrez ce message <span style="color:red">*</span></label>
                    @error('name')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>                
                <div class="alert alert-primary">Déchiffrez ce message et obtenez le numéro de validation.</div>
            </div>
            <form method="POST" action="{{ route('verif.pgp') }}">
                @csrf
                    <div class="form-floating mb-4">
                        <input placeholder="Numéro de validation" type="number" value="{{ old('validation_number') }}" class="form-control @error('validation_number') is-invalid @enderror" required name="validation_number" id="validation_number"/>
                        <label for="floatingInputGroup1">Numéro de validation <span style="color:red">*</span></label>
                        @error('validation_number')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>

                    <div class="mr-2 mb-2">{!! captcha_img() !!}</div>
                    <div class="form-floating mb-4">
                        <input type="text" class="form-control @error('captcha') is-invalid @enderror" required name="captcha" placeholder="Captcha ici">
                        <label for="floatingInputGroup1">Captcha <span style="color:red">*</span></label>
                        @error('captcha')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                <button class="btn btn-dark">Confirmer le 2FA</button>
            </form>
        </div>
    </div>
</div>


@endsection