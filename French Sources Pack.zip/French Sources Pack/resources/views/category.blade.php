@extends('layouts.app')

@section('content')
  <div class="row">
    @include('layouts.menu.left')
    <div class="col-lg-9">
      <div class="card mt-4">
        <div class="card-header bg-dark text-white">{{ $category->name }}</div>
      </div>
      <div class="row">
        @include('layouts.include.product')
      </div>
      <div>{{ $products->links('pagination::simple-bootstrap-5') }}</div>
    </div>
  </div>
@endsection