@extends('layouts.app')

@section('content')
    <div class="card">
      <div class="card-header bg-dark text-white"><h4>Informations</h4></div>
      <div class="card-body">{{ $settings->information_index }}</div>
  </div>
  <div class="row">
    @include('layouts.menu.left')
    <div class="col-lg-9">
      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Top des Vendeurs</div>
      </div>
        <div class="row">
          @foreach($vendors as $item)
          <div class="col-lg-2">
            <a href="#">
            <div class="card mt-2">
              <div class="card-body">
                @if($item->vendor->user->picture == "default-avatar.png")
                  <img height="100" src="{{ asset('img/default-avatar.png') }}" class="vendor-profil-picture" />
                @else
                  <img height="100" src="{{ asset('storage/'.$item->vendor->user->picture) }}" class="vendor-profil-picture" />
                @endif
                <p class="text-center mb-0"><a href="{{ route('profil', $item->vendor->user->name) }}" class="badge bg-success text-decoration-none" >{{ $item->vendor->user->name }}</a></p>
              </div>
            </div>
            </a>
          </div>
          @endforeach
        </diV>
      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Meilleures Offres</div>
      </div>
      <div class="row">
        @include('layouts.include.product')
        <div>{{ $products->links('pagination::simple-bootstrap-5') }}</div>
      </div>
    </div>
  </div>
@endsection