@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Stocks</div>
        <div class="card-body">
          <form class="d-none d-md-inline-block form-inline w-100" method="GET">
            <div class="input-group">
                <input class="form-control" name="query" type="text" placeholder="Rechercher..." aria-label="Rechercher..." aria-describedby="btnNavbarSearch" />
                <button class="btn btn-success" id="btnNavbarSearch" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
            </div>
          </form>
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Photo</th>
                    <th scope="col">Titre</th>
                    <th scope="col">Stock</th>
                    <th scope="col">&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                @if(request()->has('query'))
                  @foreach($products as $item)
                    <tr>
                      <td class="align-middle"><img class="mb-2" src="{{ asset('storage/'.$item->picture) }}" height="70" /></td>
                      <td class="align-middle">{{ $item->name }}</td>
                      <td class="align-middle">
                          <form method="POST" action="{{ route('product.add.stock', $item->token) }}">
                              @csrf
                              @method('PUT')
                              <div class="input-group">
                                  <input class="form-control" name="stock" type="number" value="{{ $item->stock}}" />
                                  <button class="btn btn-success" type="submit"><i class="fa-solid fa-check"></i></button>
                              </div>
                          </form>
                      </td>
                      <td class="align-middle"><a href="{{ route('product.edit', $item->token) }}" class="btn btn-success">Modifier</a> <a href="{{ route('product', $item->token) }}" class="btn btn-success">Voir</a></td>
                    </tr>
                  @endforeach
                  @if($products->isEmpty())
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">Aucun résultat</div></td>
                    </tr>
                  @endif
                @else
                  @foreach($all as $item)
                    <tr>
                      <td class="align-middle"><img class="mb-2" src="{{ asset('storage/'.$item->picture) }}" height="70" /></td>
                      <td class="align-middle">{{ $item->name }}</td>
                      <td class="align-middle">
                          <form method="POST" action="{{ route('product.add.stock', $item->token) }}">
                              @csrf
                              @method('PUT')
                              <div class="input-group">
                                  <input class="form-control" name="stock" type="number" value="{{ $item->stock}}" />
                                  <button class="btn btn-success" type="submit"><i class="fa-solid fa-check"></i></button>
                              </div>
                          </form>
                      </td>
                      <td class="align-middle"><a href="{{ route('product.edit', $item->token) }}" class="btn btn-success">Modifier</a> <a href="{{ route('product', $item->token) }}" class="btn btn-success">Voir</a></td>
                    </tr>
                  @endforeach
                  @if($all->isEmpty())
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">Aucun résultat</div></td>
                    </tr>
                  @endif
                @endif
                </tbody>
              </table>
              @if(request()->has('query'))
                <div>{{ $products->links('pagination::simple-bootstrap-5') }}</div>
              @else
                <div>{{ $all->links('pagination::simple-bootstrap-5') }}</div>
              @endif
        </div>
      </div>
    </div>
  </div>
@endsection