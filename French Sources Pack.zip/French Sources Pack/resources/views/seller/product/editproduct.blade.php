@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white">Modifier le produit - {{ $product->name }}</div>
        <div class="card-body">
            <form method="POST" action="{{ route('product.action.update', $product->token) }}" enctype="multipart/form-data" >
                @csrf
                @method('PUT')
                <div class="form-floating mb-4">
                    <input placeholder="Saisissez le titre du produit" type="text" value="{{ $product->name }}" name="name" class="form-control @error('name') is-invalid @enderror" id="floatingInputGroup1" >
                    <label for="floatingInputGroup1">Titre <span style="color:red">*</span></label>
                    @error('name')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <div class="form-floating mb-4">
                    <select class="form-control mb-4 @error('category') is-invalid @enderror" name="category">
                        @foreach(App\Models\Market\Category::allCategorie() as $item)
                            @if(!empty($item['children']))
                            <option value="{{ $item['token'] }}" >{{ $item['name'] }} </option>
                                @foreach ($item['children'] as $children)
                                    <option value="{{ $children['token'] }}" >-- {{ $children['name'] }}</option>
                                @endforeach
                            @else
                                <option value="{{ $item['token'] }}" >{{ $item['name'] }}</option>
                            @endif
                        @endforeach
                    </select>
                    <label for="floatingInputGroup1">Catégorie <span style="color:red">*</span></label>
                    @error('category')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <div class="input-group">
                    <div class="form-floating mb-4 me-4">
                        <input placeholder="Saisissez le prix du produit" type="text" value="{{ $product->price }}" name="price" class="form-control @error('price') is-invalid @enderror" id="floatingInputGroup1" >
                        <label for="floatingInputGroup1">Prix <span style="color:red">*</span></label>
                        @error('price')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>

                    <div class="form-floating mb-4">
                        <input placeholder="Saisissez le stock du produit" type="text" value="{{ $product->stock }}" name="stock" class="form-control @error('stock') is-invalid @enderror" id="floatingInputGroup1" >
                        <label for="floatingInputGroup1">Stock <span style="color:red">*</span></label>
                        @error('stock')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                </div>
                <div class="form-floating mb-4">
                    <textarea placeholder="Saisissez la description du produit" style="height:280px" name="description" class="form-control mb-4 @error('description') is-invalid @enderror">{{ $product->description }}</textarea>
                    <label for="floatingInputGroup1">Description <span style="color:red">*</span></label>
                    @error('description')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <img class="mb-2" src="{{ asset('storage/'.$product->picture) }}" height="100" /><br>
                <label for="floatingInputGroup1">Photo <span style="color:red">*</span></label>
                <input type="file" name="picture" class="form-control mb-4 @error('picture') is-invalid @enderror" />
                @error('picture')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror

                <div class="mb-0">
                    @if($product->picsupp1)
                        <img class="mb-2" src="{{ asset('storage/'.$product->picsupp1) }}" height="100" /><br>
                    @endif
                    <label class="form-label">Picture supp 1</label>
                    <input type="file" name="picsupp1" class="form-control mb-4 @error('picsupp1') is-invalid @enderror" />
                    @error('picsupp1')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                </div>
                <div class="mb-0">
                    @if($product->picsupp2)
                        <img class="mb-2" src="{{ asset('storage/'.$product->picsupp2) }}" height="100" /><br>
                    @endif
                    <label>Picture supp 2</label>
                    <input type="file" name="picsupp2" class="form-control mb-4 @error('picsupp2') is-invalid @enderror" />
                    @error('picsupp2')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                </div>
                <div class="mb-0">
                    @if($product->picsupp3)
                        <img class="mb-2" src="{{ asset('storage/'.$product->picsupp3) }}" height="100" /><br>
                    @endif
                    <label>Picture supp 3</label>
                    <input type="file" name="picsupp3" class="form-control mb-4 @error('picsupp3') is-invalid @enderror" />
                    @error('picsupp3')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                </div>
                <div class="form-floating mb-4">
                    <select class="form-control mb-4 @error('delivery') is-invalid @enderror" name="delivery">
                        @foreach(App\Models\Market\Delivery::where('user_id', Auth::user()->id)->get() as $delivery)
                            <option value="{{ $delivery->token }}">{{ $delivery->name }}</option>
                        @endforeach
                    </select>
                    <label>Livraison <span style="color:red">*</span></label>
                    @error('delivery')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                </div>
                <button type="submit" class="btn btn-success">Modifier le produit</button>
            </form>
        </div>
      </div>
    </div>
  </div>
@endsection