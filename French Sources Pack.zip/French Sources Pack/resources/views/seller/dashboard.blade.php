@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Tableau de bord</p></div>
        <div class="card-body">
          <div class="row">
            <div class="col-lg-12">
              <div class="card bg-dark text-white mb-2">
                <div class="card-header pb-0">Total earnings @if(App\Models\Settings::test() == 1) <span class="badge bg-warning">Mode test</span>@endif</div>
                <hr class="mb-2 mt-2">
                <div class="card-body pt-0">
                  <div class="row">
                    <div class="col-lg-6">
                      <p class="fs-3 mb-0 text-center">@if(App\Models\Settings::test() == 1) {{ $totalEurTest }} @else {{ $totalEur }} @endif <small class="fs-6">EUR</small></p>
                    </div>
                    <div class="col-lg-6">
                      <p class="fs-3 mb-0 text-center">@if(App\Models\Settings::test() == 1) {{ $totalXmrTest }} @else @if($totalXmr != 0) {{ $totalXmr }} @else 0.000000000000 @endif @endif <small class="fs-6">XMR</small></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="card bg-dark text-white">
                <div class="card-body">
                  <p class="fs-3 mb-0 text-center">@if(App\Models\Settings::test() == 1) {{ $cSalesTest }} @else {{ $cSales }} @endif <small class="fs-6">Ventes</small></p>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="card bg-dark text-white">
                <div class="card-body">
                  <p class="fs-3 mb-0 text-center">{{ $cProducts }} <small class="fs-6">Produits</small></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="card mt-2">
        <div class="card-header bg-dark text-white">Dernières ventes</div>
        <div class="card-body">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">#ID</th>
                <th scope="col">Prix en XMR</th>
                <th scope="col">Statut</th>
                <th scope="col">&nbsp;</th>
              </tr>
            </thead>
            <tbody>
            @if(App\Models\Settings::test() == 1)
              @foreach($salesTest as $item)
                <tr>
                  <td class="align-middle">{{ $item->token }}</td>
                  <td class="align-middle">{{ $item->monero_price }} XMR</td>
                  @if($item->status == 0)
                  <td class="align-middle"><span class="badge bg-primary">Nouvelle commande</span></td>
                  @else
                  @if($item->status == 1)
                  <td class="align-middle"><span class="badge bg-success">Adresse envoyée</span></td>
                  @else
                    @if($item->status == 2)
                      <td class="align-middle"><span class="badge bg-success">Commande envoyée</span></td>
                    @else
                      @if($item->status == 3)
                        <td class="align-middle"><span class="badge bg-success">Commande terminée</span></td>
                      @endif
                    @endif
                  @endif
                  @endif
                  <td class="align-middle"><a href="{{ route('sale.test.show', $item->token) }}" class="btn btn-success">Voir</a></td>
                </tr>
              @endforeach
            @else
              @foreach($sales as $item)
                 <tr>
                  <td class="align-middle">{{ $item->token }}</td>
                  <td class="align-middle">{{ $item->monero_price }} XMR</td>
                  @if($item->status == 0)
                  <td class="align-middle"><span class="badge bg-primary">Nouvelle commande</span></td>
                  @else
                  @if($item->status == 1)
                  <td class="align-middle"><span class="badge bg-success">Adresse envoyée</span></td>
                  @else
                    @if($item->status == 2)
                      <td class="align-middle"><span class="badge bg-success">Commande envoyée</span></td>
                    @else
                      @if($item->status == 3)
                        <td class="align-middle"><span class="badge bg-success">Commande terminée</span></td>
                      @endif
                    @endif
                  @endif
                  @endif
                    <td class="align-middle"><a href="{{ route('sale.show', $item->token) }}" class="btn btn-success">Voir</a></td>
                </tr>
              @endforeach
            @endif
            </tbody>
          </table>
        </div>
      </div>

      <div class="card mt-2">
        <div class="card-header bg-dark text-white">Derniers produits</div>
        <div class="card-body">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">Photo</th>
                <th scope="col">Titre</th>
                <th scope="col">Prix</th>
                <th scope="col">Catégorie</th>
                <th scope="col">Stock</th>
                <th scope="col">&nbsp;</th>
              </tr>
            </thead>
            <tbody>
            @foreach($products as $item)
              <tr>
                <td class="align-middle"><img class="mb-2" src="{{ asset('storage/'.$item->picture) }}" height="70" /></td>
                <td class="align-middle">{{ $item->name }}</td>
                <td class="align-middle">{{ $item->price }}</td>
                <td class="align-middle">{{ $item->category_id }}</td>
                <td class="align-middle">{{ $item->stock }}</td>
                <td class="align-middle"><a href="{{ route('product.edit', $item->token) }}" class="btn btn-success">Modifier</a> <a href="{{ route('product', $item->token) }}" class="btn btn-success">Voir</a></td>
              </tr>
            @endforeach
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </div>
@endsection