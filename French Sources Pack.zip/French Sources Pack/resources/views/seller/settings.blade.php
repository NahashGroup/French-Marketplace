@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card">
        <div class="card-header bg-dark text-white">Vendeur - Paramètres</div>
        <div class="card-body">
            <form method="POST" action="{{ route('vendor.settings.update') }}" >
                @csrf
                @method('PUT')
                <div class="form-floating mb-4">
                  <textarea placeholder="Saisissez la description de votre boutique" style="height:450px" name="desc_shop" class="@error('desc_shop') is-invalid @enderror form-control mb-4">{{ $vendor->desc_shop }}</textarea>
                  <label class="form-label">Description de la boutique <span style="color:red">*</span></label>
                </div>
                @error('desc_shop')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
                <div class="form-check form-switch mb-2">
                  <input @if($vendor->vacation == 1) checked @endif class="form-check-input @error('vacation') is-invalid @enderror" type="checkbox" value="1" name="vacation" role="switch" id="flexSwitchCheckDefault">
                  <label class="form-check-label" for="flexSwitchCheckDefault">Mode vacances</label>
                </div>
                @error('vacation')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
                <div class="alert alert-primary">Avec le mode vacances actif, vous déclarez être en pause; aucun nouvelle commande n'arrivera.</div>
                <button type="submit" class="btn btn-success">Mettre à jour les informations</button>
            </form>
        </div>
      </div>
    </div>
  </div>
@endsection