@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Vente : {{ $sale->token }}</p></div>
        <div class="card-body">
            <div class="row">
              <div class="col-lg-6">
                <p class="mb-0"><strong>Client</strong></p>
                <p class="mb-0">Nom d'utilisateur : 
                  <a target="__blank" href="{{ route('profil', $sale->customer->name) }}" class="badge bg-success text-decoration-none">{{ $sale->customer->name }}</a> 
                  <a href="{{ route('profil.message.new', ['name' => $sale->customer->name]) }}" class="badge bg-success"><i class="fa-solid fa-envelope"></i></a>
                  <a href="{{ route('profil.ticket.new', ['subject' => 'report']) }}" class="badge bg-danger"><i class="fa-solid fa-flag"></i></a>
                </p>
                <p class="mb-0">Création : {{date('d-m-Y', strtotime($sale->created_at))}}</p>
                <p class="mb-0">Paiement : Monero (XMR)</p>
              </div>
              <div class="col-lg-6">
                <p class="mb-0"><strong>Vendeur</strong></p>
                <p class="mb-0">Nom d'utilisateur : <a target="__blank" href="{{ route('profil', $sale->vendor->user->name) }}" class="badge bg-success text-decoration-none">{{ $sale->vendor->user->name }}</a></p>
              </div>
            </div>
            <div class="mt-4">
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Photo</th>
                    <th scope="col">Titre</th>
                    <th scope="col">Prix en XMR</th>
                    <th scope="col">Statut</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="align-middle"><img class="mb-2" src="{{ asset('storage/'.$sale->product_picture) }}" height="70" /></td>
                    <td class="align-middle">{{ $sale->product_name }}</td>
                    <td class="align-middle">{{ $sale->monero_price }} XMR</td>
                    @if($sale->status == 0)
                      <td class="align-middle"><span class="badge bg-primary">Nouvelle commande</span></td>
                    @else
                      @if($sale->status == 1)
                        <td class="align-middle"><span class="badge bg-success">Adresse envoyée</span></td>
                      @else
                        @if($sale->status == 2)
                          <td class="align-middle"><span class="badge bg-success">Commande envoyée</span></td>
                        @else
                          @if($sale->status == 3)
                            <td class="align-middle"><span class="badge bg-success">Commande terminée</span></td>
                          @endif
                        @endif
                      @endif
                    @endif
                  </tr>
                </tbody>
              </table>
              <div class="form-floating mb-4">
                @if($sale->gps != 1)
                  <textarea style="height:350px" placeholder="Adresse" class="form-control mb-4" disabled>{{ $sale->address }}</textarea>
                  <label>Adresse <span style="color:red">*</span></label>
                  <div class="alert alert-primary">L'adresse sera chiffrée avec votre clé PGP !</div>
                @else
                  @if($sale->status == 0)
                    <form method="POST" action="{{ route('sale.gps.send', $sale->token) }}">
                      @csrf
                      <div class="input-group mb-4">
                        <div class="form-floating me-4">
                            <input type="text" value="" name="lat" class="form-control @error('lat') is-invalid @enderror" id="floatingInputGroup1" placeholder="lat">
                            <label for="floatingInputGroup1">Latitude<span style="color:red">*</span></label>
                            @error('lat')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="form-floating">
                            <input type="text" value="" name="lon" class="form-control @error('lon') is-invalid @enderror" id="floatingInputGroup1" placeholder="lon">
                            <label for="floatingInputGroup1">Longitude <span style="color:red">*</span></label>
                            @error('lon')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>                               
                      </div>
                      <div class="form-floating mb-4">
                        <textarea placeholder="Saisissez des informations complémentaires" style="height:250px" class="form-control mb-2 @error('info') is-invalid @enderror" name="info"></textarea>
                        @error('info')
                          <span class="invalid-feedback" role="alert">
                              <strong>{{ $message }}</strong>
                          </span>
                        @enderror
                        <label>Informations complémentaires <span style="color:red">*</span></label>
                      </div>
                      <button class="btn btn-success" type="submit">Envoyer les coordonnées GPS</button>
                    </form>
                  @else
                    <textarea style="height:350px" placeholder="GPS" class="form-control mb-4" disabled>{{ $gps->info }}</textarea>
                    <label>Coordonnées GPS <span style="color:red">*</span></label>
                  @endif
                  <div class="alert alert-primary">Sera chiffré avec la clé PGP du client</div>
                @endif
              </div>

              <div class="input-group">
                @if($sale->gps == 0)
                  @if($sale->status == 1)
                    <form method="POST" action="{{ route('sale.order.send', $sale->token) }}" >
                        @csrf
                        @method('PUT')
                      <button type="submit" class="btn btn-success">J'ai envoyé la commande</button>
                    </form>
                  @endif
                @endif
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>
@endsection