@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Ventes</p></div>
        <div class="card-body">
          <form class="d-none d-md-inline-block form-inline w-100" method="GET">
            <div class="input-group">
                <input class="form-control" value="{{ request()->input('query') }}" name="query" type="text" placeholder="Rechercher..." aria-label="Rechercher..." aria-describedby="btnNavbarSearch" />
                <button class="btn btn-success" id="btnNavbarSearch" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
            </div>
          </form>
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">#ID</th>
                    <th scope="col">Prix en XMR</th>
                    <th scope="col">Statut</th>
                    <th scope="col">&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                @if(request()->has('query'))
                  @foreach($sales as $item)
                  <tr>
                    <td class="align-middle">{{ $item->token }}</td>
                    <td class="align-middle">{{ $item->monero_price }} XMR</td>
                    @if($item->status == 0)
                      <td class="align-middle"><span class="badge bg-primary">Nouvelle commande</span></td>
                    @else
                      <td class="align-middle"><span class="badge bg-success">Adresse envoyée</span></td>
                    @endif
                    <td class="align-middle"><a href="{{ route('sale.test.show', $item->token) }}" class="btn btn-success">Voir</a></td>
                  </tr>
                  @endforeach
                  @if($sales->isEmpty())
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">Aucun résultat</div></td>
                    </tr>
                  @endif
                @else
                  @foreach($all as $item)
                    <tr>
                      <td class="align-middle">{{ $item->token }}</td>
                      <td class="align-middle">{{ $item->monero_price }} XMR</td>
                      @if($item->status == 0)
                        <td class="align-middle"><span class="badge bg-primary">Nouvelle commande</span></td>
                      @else
                      @if($item->status == 1)
                      <td class="align-middle"><span class="badge bg-success">Adresse envoyée</span></td>
                      @else
                        @if($item->status == 2)
                          <td class="align-middle"><span class="badge bg-success">Commande envoyée</span></td>
                        @else
                          @if($item->status == 3)
                            <td class="align-middle"><span class="badge bg-success">Commande terminée</span></td>
                          @endif
                        @endif
                      @endif
                      @endif
                      <td class="align-middle"><a href="{{ route('sale.test.show', $item->token) }}" class="btn btn-success">Voir</a></td>
                    </tr>
                  @endforeach
                  @if($all->isEmpty())
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">Aucun résultat</div></td>
                    </tr>
                  @endif
                @endif
                </tbody>
              </table>
              @if(request()->has('query'))
                <div>{{ $sales->links('pagination::simple-bootstrap-5') }}</div>
              @else
                <div>{{ $all->links('pagination::simple-bootstrap-5') }}</div>
              @endif
        </div>
      </div>
    </div>
  </div>
@endsection