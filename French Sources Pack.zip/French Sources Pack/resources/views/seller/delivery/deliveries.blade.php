@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Modes de livraison</p> <a href="{{ route('delivery.new') }}" class="btn btn-success float-end d-flex"><i class="fa-solid fa-plus"></i></a></div>
        <div class="card-body">
          <form class="d-none d-md-inline-block form-inline w-100" method="GET">
            <div class="input-group">
                <input class="form-control" name="query" type="text" placeholder="Rechercher..." aria-label="Rechercher..." aria-describedby="btnNavbarSearch" />
                <button class="btn btn-success" id="btnNavbarSearch" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
            </div>
          </form>
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Titre</th>
                    <th scope="col">Prix</th>
                    <th scope="col">Expédition</th>
                    <th scope="col">GPS</th>
                    <th scope="col">&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                @if(request()->has('query'))
                  @foreach($deliveries as $item)
                    <tr>
                      <td class="align-middle">{{ $item->name }}</td>
                      <td class="align-middle">{{ $item->price }} EUR</td>
                      <td class="align-middle">{{ $item->country->nicename }}</td>
                      @if($item->gps == 1)
                        <td class="align-middle"><span class="badge bg-success">Actif</span></td>
                      @else
                        <td class="align-middle"><span class="badge bg-danger">Inactif</span></td>
                      @endif                   
                      <td class="align-middle"><a href="{{ route('delivery.edit', $item->token) }}" class="btn btn-success">Modifier</a></td>
                    </tr>
                  @endforeach
                  @if($deliveries->isEmpty())
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">Aucun résultat</div></td>
                    </tr>
                  @endif
                @else
                  @foreach($all as $item)
                    <tr>
                      <td class="align-middle">{{ $item->name }}</td>
                      <td class="align-middle">{{ $item->price }} EUR</td>
                      <td class="align-middle">{{ $item->country->nicename }}</td>
                      @if($item->gps == 1)
                        <td class="align-middle"><span class="badge bg-success">Actif</span></td>
                      @else
                        <td class="align-middle"><span class="badge bg-danger">Inactif</span></td>
                      @endif 
                      <td class="align-middle"><a href="{{ route('delivery.edit', $item->token) }}" class="btn btn-success">Modifier</a></td>
                    </tr>
                  @endforeach
                  @if($all->isEmpty())
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">Aucun résultat</div></td>
                    </tr>
                  @endif
                @endif
                </tbody>
              </table>
              @if(request()->has('query'))
                <div>{{ $deliveries->links('pagination::simple-bootstrap-5') }}</div>
              @else
                <div>{{ $all->links('pagination::simple-bootstrap-5') }}</div>
              @endif
        </div>
      </div>
    </div>
  </div>
@endsection