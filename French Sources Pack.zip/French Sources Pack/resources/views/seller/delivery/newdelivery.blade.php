@extends('layouts.app')

@section('content')
  <div class="row">
    <div class="col-lg-3">
        @include('layouts.menu.profil')
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white">Nouveau mode de livraison</div>
        <div class="card-body">
            <form method="POST" action="{{ route('delivery.add') }}" >
                @csrf
                <div class="form-floating mb-4">
                    <input type="text" value="{{ old('name') }}" placeholder="Titre" name="name" class="form-control mb-4 @error('name') is-invalid @enderror" />
                    @error('name')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                    <label>Titre <span style="color:red">*</span></label>
                </div>

                <div class="form-floating mb-4">
                    <input type="number" value="{{ old('delay') }}" name="delay" placeholder="Délai" class="form-control mb-4 @error('delay') is-invalid @enderror" />
                    @error('delay')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                    <label>Délai en jours <span style="color:red">*</span></label>
                </div>
                <div class="form-floating mb-4">
                    <select class="form-control mb-4" name="shippingto">
                        @foreach(App\Models\Country::get() as $item)
                            <option value="{{ $item->id }}">{{ $item->nicename }}</option>
                        @endforeach
                    </select>
                    <label>Expédition à <span style="color:red">*</span></label>
                </div>
                <div class="form-floating mb-4">
                    <input type="number" value="{{ old('price') }}" placeholder="Prix" name="price" class="form-control mb-4 @error('price') is-invalid @enderror" />
                    @error('price')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                    <label>Prix<span style="color:red">*</span></label>
                </div>
                <div class="form-floating mt-4 mb-4">
                    <select class="form-select" name="gps">
                      <option value="0">Non</option>
                      <option value="1">Oui</option>
                    </select>
                    <label for="floatingInputGroup1">Coordonnées GPS <span style="color:red">*</span></label>
                    @error('gps')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <div class="alert alert-primary">Avec le système de coordonnées GPS, l'acheteur ne doit pas fournir d'adresse, mais vous devez envoyer les coordonnées GPS du produit, accompagnées d'une description ou d'un lien avec une photo (sans EXIF).</div>
                <button type="submit" class="btn btn-success">Ajouter le mode de livraison</button>
            </form>
        </div>
      </div>
    </div>
  </div>
@endsection