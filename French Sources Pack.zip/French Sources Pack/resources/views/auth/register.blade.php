@extends('layouts.app')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-dark text-white">S'inscrire</div>
                <div class="card-body">
                    <form method="POST" action="{{ route('register') }}">
                        @csrf

                        <div class="form-floating mb-4">
                            <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" id="floatingInputGroup1" placeholder="Nom d'utilisateur">
                            <label for="floatingInputGroup1">Nom d'utilisateur <span style="color:red">*</span></label>
                            @error('name')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="form-floating mb-4">
                            <input type="password" name="password" class="form-control @error('password') is-invalid @enderror" id="floatingInputGroup1" placeholder="Mot de passe">
                            <label for="floatingInputGroup1">Mot de passe <span style="color:red">*</span></label>
                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="form-floating mb-4">
                            <input type="password" name="password_confirmation" class="form-control" id="floatingInputGroup1" placeholder="Confirmer le mot de passe">
                            <label for="floatingInputGroup1">Confirmer le mot de passe <span style="color:red">*</span></label>
                        </div>

                        <div class="form-floating mb-4">
                            {!! captcha_img() !!}
                        </div>

                        <div class="form-floating mb-4">
                            <input type="text" name="captcha" class="form-control @error('captcha') is-invalid @enderror" id="floatingInputGroup1" placeholder="Captcha ici">
                            <label for="floatingInputGroup1">Captcha <span style="color:red">*</span></label>
                            @error('captcha')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-success">
                                    S'inscrire
                                </button>
                                <a href="{{ route('login') }}" class="text-dark text-decoration-none">
                                    Vous avez déjà un compte ?
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
