@extends('layouts.app')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card mt-4">
                <div class="card-header bg-dark text-white">Se connecter</div>
                <div class="card-body">
                    <form method="POST" action="{{ route('login') }}">
                        @csrf
                            <div class="form-floating mb-4">
                                <input type="text" value="{{ old('name') }}" name="name" class="form-control @error('name') is-invalid @enderror" id="floatingInputGroup1" placeholder="Nom d'utilisateur">
                                <label for="floatingInputGroup1">Nom d'utilisateur <span style="color:red">*</span></label>
                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="form-floating mb-4">
                                <input type="password" name="password" class="form-control @error('password') is-invalid @enderror" id="floatingInputGroup1" placeholder="Mot de passe">
                                <label for="floatingInputGroup1">Mot de passe <span style="color:red">*</span></label>
                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        <div class="form-floating mb-4">
                            {!! captcha_img() !!}
                        </div>
                        <div class="form-floating mb-4">
                            <input type="text" name="captcha" class="form-control @error('captcha') is-invalid @enderror" id="floatingInputGroup1" placeholder="Captcha ici">
                            <label for="floatingInputGroup1">Captcha <span style="color:red">*</span></label>
                            @error('captcha')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-success">
                                    Se connecter
                                </button>
                                <a href="{{ route('register') }}" class="text-dark text-decoration-none">
                                    Vous n'avez pas de compte ?
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
