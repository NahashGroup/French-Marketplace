@extends('layouts.admin.app')


@section('content-admin')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        @include('layouts.include.alert')
                        <h1 class="mt-4">Tableau de bord</h1>
                        <div class="row">
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-dark text-white mb-4">
                                    <div class="card-body"><p class="text-center mb-0"><span class="fs-2">{{ $cVendor }}</span> Vendeurs</p></div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white text-decoration-none" href="{{ route('admin.vendor.all') }}">Voir les Détails</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-dark text-white mb-4">
                                    <div class="card-body"><p class="text-center mb-0"><span class="fs-2">{{ $cCustomers }}</span> Clients</p></div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white text-decoration-none" href="{{ route('admin.customer.all') }}">Voir les Détails</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-dark text-white mb-4">
                                    <div class="card-body"><p class="text-center mb-0"><span class="fs-2">{{ $cProducts }}</span> Produits</p></div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white text-decoration-none" href="{{ route('admin.product.all') }}">Voir les Détails</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-dark text-white mb-4">
                                    <div class="card-body"><p class="text-center mb-0"><span class="fs-2">{{ $cTickets }}</span> Tickets</p></div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white text-decoration-none" href="{{ route('admin.support.all') }}">Voir les Détails</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card mb-4">
                                    <div class="card-header bg-dark text-white">Informations sur le portefeuille</div>
                                    <div class="card-body">
                                        <div class="form-floating mb-4">
                                            <input placeholder="Adresse" type="text" value="{{ $get_addr_first['address'] }}" class="form-control mb-4" disabled />
                                            <label class="form-label">Adresse <span style="color:red">*</span></label>
                                        </div>
                                        <div class="form-floating mb-4">
                                            <input placeholder="Total" type="text" value="{{ $total_amount }} XMR" class="form-control mb-4" disabled />
                                            <label class="form-label">Total <span style="color:red">*</span></label>
                                        </div>
                                        <div class="form-floating mb-4">
                                            <input placeholder="Total Débloqué" type="text" value="{{ $unlock_amount }} XMR" class="form-control mb-4" disabled />
                                            <label class="form-label">Total Débloqué <span style="color:red">*</span></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card mb-4">
                                    <div class="card-header bg-dark text-white">Total des Commandes/Montants</div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-xl-6 col-md-6">
                                                <div class="card bg-dark text-white mb-4">
                                                    <div class="card-body">
                                                        <p class="text-center mb-0">
                                                            @if(App\Models\Settings::test() == 1)
                                                                <span class="fs-2">{{ $cOrdersTest }}</span> Commandes
                                                            @else
                                                                <span class="fs-2">{{ $cOrdersProd }}</span> Commandes
                                                            @endif
                                                        </p>
                                                    </div>
                                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                                        @if(App\Models\Settings::test() == 1)
                                                            <span class="badge bg-warning w-100">Mode test</span>
                                                        @endif
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-6 col-md-6">
                                                <div class="card bg-dark text-white mb-4">
                                                    <div class="card-body">
                                                        <p class="text-center mb-0">
                                                            @if(App\Models\Settings::test() == 1)
                                                                <span class="fs-2">{{ $cTotalAmountTest }}</span> EUR<br>
                                                                <span class="fs-5">{{ $cTotalXmrTest }}</span> XMR
                                                            @else
                                                                <span class="fs-2">{{ $cTotalAmountProd }}</span> EUR<br>
                                                                <span class="fs-5">{{ $cTotalXmrProd }}</span> XMR
                                                            @endif
                                                        </p>
                                                    </div>
                                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                                        @if(App\Models\Settings::test() == 1)
                                                            <span class="badge bg-warning w-100">Mode test</span>
                                                        @endif
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card mb-4">
                            <div class="card-header bg-dark text-white"><i class="fas fa-users me-1"></i> Utilisateurs</div>
                            <div class="card-body">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Photo de profil</th>
                                            <th>Nom d'utilisateur</th>
                                            <th>Rôle</th>
                                            <th>&nbsp;</th>
                                            <th>&nbsp;</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($users as $item)
                                        <tr>
                                            @if($item->picture != "default-avatar.png")
                                                <td><img src="{{ asset('storage/'. $item->picture) }}" height="50" /></td>
                                            @else
                                                <td><img src="{{ asset('img/default-avatar.png') }}" height="50" /></td>
                                            @endif
                                            <td>{{ $item->name }}</td>
                                            @if($item->vendor)
                                                <td><span class="badge bg-success">Vendeur</span></td>
                                            @else
                                                @if($item->admin)
                                                    <td><span class="badge bg-danger">Admin</span></td>
                                                @else
                                                    <td><span class="badge bg-success">Client</span></td>
                                                @endif
                                            @endif
                                            <td><a target="__blank" class="btn btn-success" href="{{ route('profil', $item->name) }}">Voir</a></td>
                                            <td><a class="btn btn-warning" href="#">Bannir</a></td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card mb-4">
                            <div class="card-header bg-dark text-white"><i class="fas fa-cart-shopping me-1"></i> Produits</div>
                            <div class="card-body">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Photo</th>
                                            <th>Titre</th>
                                            <th>Prix</th>
                                            <th>Stock</th>
                                            <th>Expédition à</th>
                                            <th>&nbsp;</th>
                                            <th>&nbsp;</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($products as $item)
                                        <tr>
                                            <td><img src="{{ asset('storage/'.$item->picture) }}" height="50" /></td>
                                            <td>{{ $item->name }}</td>
                                            <td>{{ $item->price }}</td>
                                            <td>{{ $item->stock }}</td>
                                            <td>{{ $item->delivery->country->nicename }}</td>
                                            <td><a target="__blank" class="btn btn-success" href="{{ route('product', $item->token) }}">Voir</a></td>
                                            <td>
                                                @if($item->locked == 0)
                                                    <form method="POST" action="{{ route('admin.product.locked', $item->token) }}" >
                                                        @csrf
                                                        @method('PUT')
                                                        <button type="submit" class="btn btn-warning"><i class="fa-solid fa-lock"></i></button>
                                                    </form>
                                                @else
                                                    <form method="POST" action="{{ route('admin.product.unlocked', $item->token) }}" >
                                                        @csrf
                                                        @method('PUT')
                                                        <button type="submit" class="btn btn-warning"><i class="fa-solid fa-unlock"></i></button>
                                                    </form>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
@endsection
