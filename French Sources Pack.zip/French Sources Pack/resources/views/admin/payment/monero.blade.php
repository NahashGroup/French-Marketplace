@extends('layouts.admin.app')


@section('content-admin')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        @include('layouts.include.alert')
                        <h1 class="mt-4">Paiement</h1>
                        <div class="card">
                            <div class="card-header bg-dark text-white">Monero</div>
                            <div class="card-body">
                                <div class="form-floating mt-4">
                                    <input type="text" value="127.0.0.1" class="form-control" id="floatingInputGroup1" disabled>
                                    <label for="floatingInputGroup1">Host</label>
                                </div>
                                <div class="form-floating mt-4">
                                    <input type="text" value="28082" class="form-control" id="floatingInputGroup1" disabled>
                                    <label for="floatingInputGroup1">Port</label>
                                </div>
                                <div class="form-floating mt-4">
                                    <input type="text" value="false" class="form-control" id="floatingInputGroup1" disabled>
                                    <label for="floatingInputGroup1">SSL</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
@endsection
