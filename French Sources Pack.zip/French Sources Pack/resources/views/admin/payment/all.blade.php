@extends('layouts.admin.app')


@section('content-admin')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        @include('layouts.include.alert')
                        <h1 class="mt-4">Paiements</h1>
                        <div class="card">
                            <div class="card-header bg-dark text-white">Paiements</div>
                            <div class="card-body">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Logo</th>
                                            <th>Nom</th>
                                            <th>Actif</th>
                                            <th>&nbsp;</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="align-middle"><img width="50" src="{{ asset('img/monero-logo.webp') }}" /></td>
                                            <td class="align-middle">MONERO (XMR)</td>
                                            <td class="align-middle"><span class="badge bg-primary">Inactif</span></td>
                                            <td class="align-middle"><a href="{{ route('admin.payment.monero') }}" class="btn btn-success">Voir</a></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
@endsection
