@extends('layouts.admin.app')


@section('content-admin')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        @include('layouts.include.alert')
                        <h1 class="mt-4">Commandes</h1>
                        <div class="card">
                            <div class="card-header bg-dark text-white">Commandes</div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                      <p class="mb-0"><strong>Client</strong></p>
                                      <p class="mb-0">Nom d'utilisateur : <a target="__blank" href="{{ route('profil', $order->customer->name) }}" class="badge bg-success text-decoration-none">{{ $order->customer->name }}</a></p>
                                      <p class="mb-0">Création : {{date('d-m-Y', strtotime($order->created_at))}}</p>
                                      <p class="mb-0">Paiement : <span class="badge bg-warning">Mode test</span></p>
                                    </div>
                                    <div class="col-lg-6">
                                      <p class="mb-0"><strong>Vendeur</strong></p>
                                      <p class="mb-0">Nom d'utilisateur : <a target="__blank" href="{{ route('profil', $order->vendor->user->name) }}" class="badge bg-success text-decoration-none">{{ $order->vendor->user->name }}</a></p>
                                    </div>
                                  </div>
                                  <div class="mt-4">
                                    <table class="table">
                                      <thead>
                                        <tr>
                                          <th scope="col">Photo</th>
                                          <th scope="col">Titre</th>
                                          <th scope="col">Prix en XMR</th>
                                          <th scope="col">Statut</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        <tr>
                                          <td class="align-middle"><img class="mb-2" src="{{ asset('storage/'.$order->product_picture) }}" height="70" /></td>
                                          <td class="align-middle">{{ $order->product_name }} XMR</td>
                                          <td class="align-middle">{{ $order->monero_price }} XMR</td>
                                          @if($order->status == 0)
                                            <td class="align-middle"><span class="badge bg-primary">Nouvelle commande</span></td>
                                          @else
                                            <td class="align-middle"><span class="badge bg-success">Adresse envoyée</span></td>
                                          @endif
                                        </tr>
                                      </tbody>
                                    </table>
                                    @if($order->gps == 0)
                                    <p>Coordonnées GPS : <span class="badge bg-primary">Inactif</span></p>
                                        <div class="form-floating mb-4">
                                          <textarea style="height:350px" placeholder="Adresse" class="form-control mb-4" disabled>{{ $order->address }}</textarea>
                                          <label for="floatingInputGroup1">Adresse <span style="color:red">*</span></label>
                                        </div>
                                    @else
                                    <p>Coordonnées GPS : <span class="badge bg-success">Actif</span></p>
                                      @if($order->status == 2)
                                        <div class="form-floating mb-4">
                                          <textarea style="height:280px" placeholder="Infos GPS" name="info" class="form-control mb-4" disabled>{{ $gps->info }}</textarea>
                                          <label for="floatingInputGroup1">Coordonnées GPS <span style="color:red">*</span></label>
                                        </div>
                                      @else
                                      <div class="alert alert-warning">Coordonnées GPS non reçues !</div>
                                      @endif
                                    @endif
                                  </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
@endsection
