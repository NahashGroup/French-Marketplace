@extends('layouts.admin.app')


@section('content-admin')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        @include('layouts.include.alert')
                        <h1 class="mt-4">Commandes</h1>
                        <div class="card">
                            <div class="card-header bg-dark text-white">Commandes</div>
                            <div class="card-body">
                                <form class="d-none d-md-inline-block form-inline w-100" method="GET">
                                    <div class="input-group">
                                        <input class="form-control" value="{{ request()->input('query') }}" name="query" type="text" placeholder="Rechercher..." aria-label="Rechercher..." aria-describedby="btnNavbarSearch" />
                                        <button class="btn btn-success" id="btnNavbarSearch" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </div>
                                </form>
                                <table class="table">
                                    <thead>
                                      <tr>
                                        <th scope="col">#ID</th>
                                        <th scope="col">Prix en XMR</th>
                                        <th scope="col">Statut</th>
                                        <th scope="col">&nbsp;</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                    @if(request()->has('query'))
                                      @foreach($orders as $item)
                                      <tr>
                                        <td class="align-middle">{{ $item->token }}</td>
                                        <td class="align-middle">{{ $item->monero_price }} XMR</td>
                                        @if($item->status == 0)
                                          <td class="align-middle"><span class="badge bg-primary">Nouvelle commande</span></td>
                                        @else
                                          <td class="align-middle"><span class="badge bg-success">Adresse envoyée</span></td>
                                        @endif
                                        <td class="align-middle"><a href="{{ route('admin.order.test', $item->token) }}" class="btn btn-success">Voir</a></td>
                                      </tr>
                                      @endforeach
                                    @else
                                      @foreach($all as $item)
                                        <tr>
                                          <td class="align-middle">{{ $item->token }}</td>
                                          <td class="align-middle">{{ $item->monero_price }} XMR</td>
                                          @if($item->status == 0)
                                            <td class="align-middle"><span class="badge bg-primary">Nouvelle commande</span></td>
                                          @else
                                            <td class="align-middle"><span class="badge bg-success">Adresse envoyée</span></td>
                                          @endif
                                          <td class="align-middle"><a href="{{ route('admin.order.test', $item->token) }}" class="btn btn-success">Voir</a></td>
                                        </tr>
                                      @endforeach
                                    @endif
                                    </tbody>
                                  </table>
                            </div>
                        </div>
                        @if(request()->has('query'))
                          <div>{{ $orders->links('pagination::simple-bootstrap-5') }}</div>
                        @else
                          <div>{{ $all->links('pagination::simple-bootstrap-5') }}</div>
                        @endif
                    </div>
                </main>
            </div>
@endsection
