@extends('layouts.admin.app')


@section('content-admin')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        @include('layouts.include.alert')
                        <h1 class="mt-4">Vendeurs</h1>
                        <div class="card">
                            <div class="card-header bg-dark text-white">Vendeurs</div>
                            <div class="card-body">
                                <form class="d-none d-md-inline-block form-inline w-100" method="GET">
                                    <div class="input-group">
                                        <input class="form-control" value="{{ request()->input('query') }}" name="query" type="text" placeholder="Rechercher..." aria-label="Rechercher..." aria-describedby="btnNavbarSearch" />
                                        <button class="btn btn-success" id="btnNavbarSearch" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </div>
                                </form>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Photo de profil</th>
                                            <th>Nom d'utilisateur</th>
                                            <th>Rôle</th>
                                            <th>&nbsp;</th>
                                            <th>&nbsp;</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    @if(request()->has('query'))
                                        @foreach($users as $item)
                                            @if($item->vendor)
                                                @if(!$item->admin)
                                                    <tr>
                                                        @if($item->picture != "default-avatar.png")
                                                            <td><img src="{{ asset('storage/'. $item->picture) }}" height="50" /></td>
                                                        @else
                                                            <td><img src="{{ asset('img/default-avatar.png') }}" height="50" /></td>
                                                        @endif
                                                        <td>{{ $item->name }}</td>
                                                        @if($item->vendor)
                                                            <td><span class="badge bg-success">Vendeur</span></td>
                                                        @else
                                                            @if($item->admin)
                                                                <td><span class="badge bg-danger">Admin</span></td>
                                                            @else
                                                                <td><span class="badge bg-success">Client</span></td>
                                                            @endif
                                                        @endif
                                                        <td><a target="__blank" class="btn btn-success" href="{{ route('profil', $item->name) }}">Voir</a></td>
                                                        <td>
                                                        @if($item->ban == 0)
                                                            <form method="POST" action="{{ route('admin.user.ban', $item->name) }}">
                                                                @csrf
                                                                @method('PUT')
                                                                <button type="submit" class="btn btn-warning" href="#">Bannir</button>
                                                            </form>
                                                        @else
                                                            <form method="POST" action="{{ route('admin.user.unban', $item->name) }}">
                                                                @csrf
                                                                @method('PUT')
                                                                <button type="submit" class="btn btn-warning" href="#">Débannir</button>
                                                            </form>
                                                        @endif
                                                        </td>
                                                    </tr>
                                                @endif
                                            @endif
                                        @endforeach
                                    @else
                                        @foreach($all as $item)
                                            @if($item->vendor)
                                                @if(!$item->admin)
                                                    <tr>
                                                        @if($item->picture != "default-avatar.png")
                                                            <td><img src="{{ asset('storage/'. $item->picture) }}" height="50" /></td>
                                                        @else
                                                            <td><img src="{{ asset('img/default-avatar.png') }}" height="50" /></td>
                                                        @endif
                                                        <td>{{ $item->name }}</td>
                                                        @if($item->vendor)
                                                            <td><span class="badge bg-success">Vendeur</span></td>
                                                        @else
                                                            @if($item->admin)
                                                                <td><span class="badge bg-danger">Admin</span></td>
                                                            @else
                                                                <td><span class="badge bg-success">Client</span></td>
                                                            @endif
                                                        @endif
                                                        <td><a target="__blank" class="btn btn-success" href="{{ route('profil', $item->name) }}">Voir</a></td>
                                                        <td>
                                                        @if($item->ban == 0)
                                                            <form method="POST" action="{{ route('admin.user.ban', $item->name) }}">
                                                                @csrf
                                                                @method('PUT')
                                                                <button type="submit" class="btn btn-warning" href="#">Bannir</button>
                                                            </form>
                                                        @else
                                                            <form method="POST" action="{{ route('admin.user.unban', $item->name) }}">
                                                                @csrf
                                                                @method('PUT')
                                                                <button type="submit" class="btn btn-warning" href="#">Débannir</button>
                                                            </form>
                                                        @endif
                                                        </td>
                                                    </tr>
                                                @endif
                                            @endif
                                        @endforeach
                                    @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        @if(request()->has('query'))
                            <div>{{ $users->links('pagination::simple-bootstrap-5') }}</div>
                        @else
                            <div>{{ $all->links('pagination::simple-bootstrap-5') }}</div>
                        @endif
                    </div>
                </main>
            </div>
@endsection
