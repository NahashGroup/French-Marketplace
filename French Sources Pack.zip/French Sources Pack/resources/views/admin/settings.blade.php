@extends('layouts.admin.app')


@section('content-admin')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        @include('layouts.include.alert')
                        <h1 class="mt-4">Paramètres</h1>
                        <div class="card">
                            <div class="card-header bg-dark text-white">Paramètres</div>
                            <div class="card-body">
                                <form action="{{ route('admin.settings.update') }}" method="POST">
                                    @csrf
                                    @method('PUT')
                                    <div class="input-group">
                                        <div class="form-floating me-4">
                                            <input type="number" value="{{ $settings->commission }}" name="commission" class="form-control @error('commission') is-invalid @enderror" id="floatingInputGroup1" placeholder="Commission">
                                            <label for="floatingInputGroup1">Commission (en %) <span style="color:red">*</span></label>
                                            @error('commission')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="form-floating">
                                            <input type="number" value="{{ $settings->fee_vendor }}" name="fee_vendor" class="form-control @error('fee_vendor') is-invalid @enderror" id="floatingInputGroup1" placeholder="Frais Vendeur">
                                            <label for="floatingInputGroup1">Frais Vendeur <span style="color:red">*</span></label>
                                            @error('fee_vendor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>                               
                                    </div>
                                    <hr>
                                    <div class="input-group mb-4">
                                        <div class="form-check form-switch me-4">
                                            <input class="form-check-input" type="checkbox" name="active_test" value="1" role="switch" id="flexSwitchCheckDefault" @if($settings->active_test == 1) checked @endif>
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Mode test</label>
                                        </div>
                                        <div class="form-check form-switch me-4">
                                            <input class="form-check-input" type="checkbox" name="lock_become_vendor" value="1" role="switch" id="flexSwitchCheckDefault" @if($settings->lock_become_vendor == 1) checked @endif>
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Devenir vendeur</label>
                                        </div>
                                    </div>
                                    <div class="form-floating me-4">
                                        <textarea style="min-height:280px" name="information_index" class="form-control @error('information_index') is-invalid @enderror" id="floatingInputGroup1">{{ $settings->information_index }}</textarea>
                                        <label for="floatingInputGroup1">Index des informations <span style="color:red">*</span></label>
                                        @error('information_index')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                      </div>
                                      <div class="form-floating me-4 mt-4">
                                        <textarea style="min-height:280px" name="become_page" class="form-control @error('information_index') is-invalid @enderror" id="floatingInputGroup1">{{ $settings->become_page }}</textarea>
                                        <label for="floatingInputGroup1">Page devenir vendeur<span style="color:red">*</span></label>
                                        @error('information_index')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                      </div>
                                    <button type="submit" class="btn btn-success mt-4">Mettre à jour les paramètres</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
@endsection
