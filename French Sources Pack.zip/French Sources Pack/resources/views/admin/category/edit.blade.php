@extends('layouts.admin.app')


@section('content-admin')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Catégories</h1>
                        <div class="card">
                            <div class="card-header bg-dark text-white">Modifier la catégorie</div>
                            <div class="card-body">
                                <form action="{{ route('admin.category.update', $category->id) }}" method="POST">
                                    @csrf
                                    @method('PUT')
                                    <div class="input-group">
                                        <div class="form-floating me-4">
                                            <input type="text" name="name" value="{{ $category->name }}" class="form-control @error('name') is-invalid @enderror" id="floatingInputGroup1">
                                            <label for="floatingInputGroup1">Titre <span style="color:red">*</span></label>
                                            @error('name')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="form-floating">
                                            <select class="form-control mb-4 @error('category') is-invalid @enderror custom-disabled" name="category">
                                                <option value="0">RACINE</option>
                                                @foreach(App\Models\Market\Category::allCategorie() as $item)
                                                    @if(!empty($item['children']))
                                                    <option value="{{ $item['token'] }}" >{{ $item['name'] }} </option>
                                                        @foreach ($item['children'] as $children)
                                                            <option value="{{ $children['token'] }}" >-- {{ $children['name'] }}</option>
                                                        @endforeach
                                                    @else
                                                        <option value="{{ $item['token'] }}" >{{ $item['name'] }}</option>
                                                    @endif
                                                @endforeach
                                            </select>
                                            <label for="floatingInputGroup1">Catégorie parent <span style="color:red">*</span></label>
                                            @error('fee_vendor')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>                               
                                    </div>
                                    <button type="submit" class="btn btn-success mt-4">Modifier la catégorie</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
@endsection
