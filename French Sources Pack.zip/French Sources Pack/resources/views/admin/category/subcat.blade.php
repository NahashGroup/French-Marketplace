@extends('layouts.admin.app')


@section('content-admin')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        @include('layouts.include.alert')
                        <h1 class="mt-4">Catégories</h1>
                        <div class="card">
                            <div class="card-header bg-dark text-white">
                                <p class="mb-0 float-start">
                                @if($category->parent_id == 0)
                                    <a class="text-decoration-none text-white" href="{{ route('admin.categories') }}"><i class="fa-solid fa-chevron-left"></i>
                                    {{ $category->name }}</a> 
                                @else
                                    <a class="text-decoration-none text-white" href="{{ route('admin.category.sub', $category->parent_id) }}"><i class="fa-solid fa-chevron-left"></i>
                                    {{ $category->name }}</a>
                                @endif
                                </p> 
                                    <a href="{{ route('admin.category.new') }}" class="btn btn-success float-end d-flex"><i class="fa-solid fa-plus"></i></a>
                                </div>
                            <div class="card-body">
                                <form class="d-none d-md-inline-block form-inline w-100" action="" method="GET">
                                    <div class="input-group">
                                        <input class="form-control" type="text" placeholder="Rechercher..." aria-label="Rechercher..." aria-describedby="btnNavbarSearch" />
                                        <button class="btn btn-success" id="btnNavbarSearch" type="button"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </div>
                                </form>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Titre</th>
                                            <th>&nbsp;</th>
                                            <th>&nbsp;</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($subCat as $item)
                                        <tr>
                                            <td>{{ $item->name }}</td>
                                            <td><a target="__blank" class="btn btn-success" href="{{ route('category', $item->token) }}">Voir</a></td>
                                            <td>
                                                <a class="btn btn-success" href="{{ route('admin.category.sub', $item->id) }}"><i class="fa-solid fa-folder"></i></a>
                                                <a class="btn btn-success" href="{{ route('admin.category.edit', $item->id) }}">Modifier</a>
                                                <form class="float-end ms-2" method="POST" action="{{ route('admin.category.delete', $item->id) }}">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger"><i class="fa-solid fa-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
@endsection
