@extends('layouts.admin.app')


@section('content-admin')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        @include('layouts.include.alert')
                        <h1 class="mt-4">Support</h1>
                        <div class="card">
                            <div class="card-header bg-dark text-white"><p class="mb-0 float-start">ID : {{ $ticket->token }}</p></div>
                            <div class="card-body">
                                <div class="card div-messenger mb-4">
                                    <div class="card-body">
                                        @foreach($messages as $item)
                                                <div class="d-flex text-white mb-2">
                                                    <div class="flex-shrink-0 me-2">
                                                            <a target="__blank" href="{{ route('profil', $item->user->name) }}">
                                                                @if($item->user->picture == "default-avatar.png")
                                                                    <img class="rounded-circle" height="50" src="{{ asset('img/default-avatar.png') }}" alt="...">
                                                                @else
                                                                    <img class="rounded-circle" height="50" src="{{ asset('storage/'.$item->user->picture) }}" alt="...">
                                                                @endif
                                                            </a>
                                                    </div>
                                                    <div class="p-3 w-100 @if($item->user_id == Auth::user()->id) @if($item->admin) bg-danger div-message-admin @else bg-success div-message-me @endif @else div-message-not-me bg-dark @endif">
                                                        <div class="ms-3">
                                                            <div class="">
                                                                <a target="__blank" class="text-decoration-none text-white" href="{{ route('profil', $item->user->name) }}"><p class="mb-2">{{ $item->user->name }}</p></a>
                                                            </div>
                                                            <p style="clear:both" class="mb-0">{{ $item->message }}</p>
                                                        </div>
                                                        <div class="float-end">
                                                            <span class="badge @if($item->user_id == Auth::user()->id) bg-dark @else @if($item->admin) bg-dark @else bg-success @endif @endif"><small>{{\Carbon\Carbon::parse($item->created_at)->diffForHumans()}}</small></span>
                                                        </div>
                                                    </div>
                                                </div>              
                                        @endforeach
                                    </div>
                                </div>
                                @if($ticket->status == 0)
                                    <form method="POST" action="{{ route('admin.support.send', $ticket->token) }}">
                                        @csrf
                                        <div class="form-floating mb-4">
                                            <textarea placeholder="Saisissez votre message" style="height:100px" name="message" class="form-control mb-4 @error('message') is-invalid @enderror"></textarea>
                                            <label class="form-label">Message <span style="color:red">*</span></label>
                                            @error('message')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <button type="submit" class="btn btn-success float-start">Envoyer</button>
                                    </form>
                                    <form method="POST" class="float-end" action="{{ route('admin.support.status', $ticket->token) }}">
                                        @csrf
                                        @method('PUT')
                                        <button type="submit" class="btn btn-danger">Résolu</button>
                                    </form>
                                @endif
                            </div>
                        </div>
                    </div>
                </main>
            </div>
@endsection
