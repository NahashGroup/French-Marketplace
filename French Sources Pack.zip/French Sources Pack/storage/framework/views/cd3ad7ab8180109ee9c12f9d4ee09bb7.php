    <div class="p-2 bg-dark text-white">Profil</div>
    <ul class="list-group">
        <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('profil.my.dashboard')); ?>">Tableau de bord</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('profil.edit.profil')); ?>">Photo de profil & Description</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('profil.settings')); ?>">Paramètres</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('profil.wallet')); ?>">Portefeuille</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('profil.wishlist.all')); ?>">Liste de souhaits</a></li>
        <?php if(App\Models\Settings::test() == 1): ?>
            <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('order.test.all')); ?>">Commandes <span class="badge bg-warning">Mode test</span></a></li>
        <?php else: ?>
            <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('order.all')); ?>">Commandes</li>
        <?php endif; ?>
        <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('profil.review.all')); ?>">Avis</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('profiL.message.all')); ?>">Messages</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('profil.ticket.all')); ?>">Support</a></li>
    </ul>
    <?php if(Auth::user()->vendor): ?>
        <div class="p-2 bg-dark text-white mt-4">Vendeur</div>
        <ul class="list-group">
            <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('vendor.dashboard')); ?>">Tableau de bord</a></li>
            <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('vendor.settings')); ?>">Paramètres</a></li>
            <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('product.all')); ?>">Produits</a></li>
            <?php if(App\Models\Settings::test() == 1): ?>
                <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('sale.test.all')); ?>">Ventes <span class="badge bg-warning">Mode test</span></a></li>
            <?php else: ?>
                <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('sale.all')); ?>">Ventes</li>
            <?php endif; ?>
            <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('product.stock.all')); ?>">Stocks</a></li>
            <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('deliveries.all')); ?>">Modes de livraison</a></li>
        </ul>
    <?php endif; ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/layouts/menu/profil.blade.php ENDPATH**/ ?>