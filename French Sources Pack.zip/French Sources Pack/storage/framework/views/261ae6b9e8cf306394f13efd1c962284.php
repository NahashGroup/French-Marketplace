

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-3">
        <?php echo $__env->make('layouts.menu.profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Vente : <?php echo e($sale->token); ?></p></div>
        <div class="card-body">
            <div class="row">
              <div class="col-lg-6">
                <p class="mb-0"><strong>Client</strong></p>
                <p class="mb-0">Nom d'utilisateur : 
                  <a target="__blank" href="<?php echo e(route('profil', $sale->customer->name)); ?>" class="badge bg-success text-decoration-none"><?php echo e($sale->customer->name); ?></a> 
                  <a href="<?php echo e(route('profil.message.new', ['name' => $sale->customer->name])); ?>" class="badge bg-success"><i class="fa-solid fa-envelope"></i></a>
                  <a href="<?php echo e(route('profil.ticket.new', ['subject' => 'report'])); ?>" class="badge bg-danger"><i class="fa-solid fa-flag"></i></a>
                </p>
                <p class="mb-0">Création : <?php echo e(date('d-m-Y', strtotime($sale->created_at))); ?></p>
                <p class="mb-0">Paiement : Monero (XMR)</p>
              </div>
              <div class="col-lg-6">
                <p class="mb-0"><strong>Vendeur</strong></p>
                <p class="mb-0">Nom d'utilisateur : <a target="__blank" href="<?php echo e(route('profil', $sale->vendor->user->name)); ?>" class="badge bg-success text-decoration-none"><?php echo e($sale->vendor->user->name); ?></a></p>
              </div>
            </div>
            <div class="mt-4">
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Photo</th>
                    <th scope="col">Titre</th>
                    <th scope="col">Prix en XMR</th>
                    <th scope="col">Statut</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="align-middle"><img class="mb-2" src="<?php echo e(asset('storage/'.$sale->product_picture)); ?>" height="70" /></td>
                    <td class="align-middle"><?php echo e($sale->product_name); ?></td>
                    <td class="align-middle"><?php echo e($sale->monero_price); ?> XMR</td>
                    <?php if($sale->status == 0): ?>
                      <td class="align-middle"><span class="badge bg-primary">Nouvelle commande</span></td>
                    <?php else: ?>
                      <?php if($sale->status == 1): ?>
                        <td class="align-middle"><span class="badge bg-success">Adresse envoyée</span></td>
                      <?php else: ?>
                        <?php if($sale->status == 2): ?>
                          <td class="align-middle"><span class="badge bg-success">Commande envoyée</span></td>
                        <?php else: ?>
                          <?php if($sale->status == 3): ?>
                            <td class="align-middle"><span class="badge bg-success">Commande terminée</span></td>
                          <?php endif; ?>
                        <?php endif; ?>
                      <?php endif; ?>
                    <?php endif; ?>
                  </tr>
                </tbody>
              </table>
              <div class="form-floating mb-4">
                <?php if($sale->gps != 1): ?>
                  <textarea style="height:350px" placeholder="Adresse" class="form-control mb-4" disabled><?php echo e($sale->address); ?></textarea>
                  <label>Adresse <span style="color:red">*</span></label>
                  <div class="alert alert-primary">L'adresse sera chiffrée avec votre clé PGP !</div>
                <?php else: ?>
                  <?php if($sale->status == 0): ?>
                    <form method="POST" action="<?php echo e(route('sale.gps.send', $sale->token)); ?>">
                      <?php echo csrf_field(); ?>
                      <div class="input-group mb-4">
                        <div class="form-floating me-4">
                            <input type="text" value="" name="lat" class="form-control <?php $__errorArgs = ['lat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingInputGroup1" placeholder="lat">
                            <label for="floatingInputGroup1">Latitude<span style="color:red">*</span></label>
                            <?php $__errorArgs = ['lat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-floating">
                            <input type="text" value="" name="lon" class="form-control <?php $__errorArgs = ['lon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingInputGroup1" placeholder="lon">
                            <label for="floatingInputGroup1">Longitude <span style="color:red">*</span></label>
                            <?php $__errorArgs = ['lon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>                               
                      </div>
                      <div class="form-floating mb-4">
                        <textarea placeholder="Saisissez des informations complémentaires" style="height:250px" class="form-control mb-2 <?php $__errorArgs = ['info'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="info"></textarea>
                        <?php $__errorArgs = ['info'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label>Informations complémentaires <span style="color:red">*</span></label>
                      </div>
                      <button class="btn btn-success" type="submit">Envoyer les coordonnées GPS</button>
                    </form>
                  <?php else: ?>
                    <textarea style="height:350px" placeholder="GPS" class="form-control mb-4" disabled><?php echo e($gps->info); ?></textarea>
                    <label>Coordonnées GPS <span style="color:red">*</span></label>
                  <?php endif; ?>
                  <div class="alert alert-primary">Sera chiffré avec la clé PGP du client</div>
                <?php endif; ?>
              </div>

              <div class="input-group">
                <?php if($sale->gps == 0): ?>
                  <?php if($sale->status == 1): ?>
                    <form method="POST" action="<?php echo e(route('sale.order.send', $sale->token)); ?>" >
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                      <button type="submit" class="btn btn-success">J'ai envoyé la commande</button>
                    </form>
                  <?php endif; ?>
                <?php endif; ?>
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/seller/sale/sale.blade.php ENDPATH**/ ?>