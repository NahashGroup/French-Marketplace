

<?php $__env->startSection('content'); ?>
  <div class="row">
    <?php echo $__env->make('layouts.menu.left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-lg-9">
      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Devenir vendeur</div>
        <div class="card-body">
          <p class="desc-pre"><?php echo e($settings->become_page); ?></p>
                <?php if(Auth::user()->vendor): ?>
                  <div class="text-center">
                    <button class="btn btn-success" disabled>Vous êtes déjà vendeur !</button>
                  </div>
                <?php else: ?>
                  <div class="text-center">
                      <form method="POST" action="<?php echo e(route('become.new.seller')); ?>">
                          <?php echo csrf_field(); ?>
                          <h2 class="mb-1"><?php echo e($settings->fee_vendor); ?> EUR</h2>
                          <p><?php echo e(App\Models\Settings::eurToXMR($settings->fee_vendor)); ?> XMR</p>
                          <button type="submit" class="btn btn-success">Devenir vendeur</button>
                      </form>
                  </div>
                <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/become.blade.php ENDPATH**/ ?>