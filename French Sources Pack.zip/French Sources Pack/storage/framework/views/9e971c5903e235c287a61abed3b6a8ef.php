


<?php $__env->startSection('content-admin'); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <?php echo $__env->make('layouts.include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <h1 class="mt-4">Categories</h1>
                        <div class="card">
                            <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Categories</p> <a href="<?php echo e(route('admin.category.new')); ?>" class="btn btn-success float-end d-flex"><i class="fa-solid fa-plus"></i></a></div>
                            <div class="card-body">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>&nbsp;</th>
                                            <th>&nbsp;</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><a target="__blank" class="btn btn-success" href="<?php echo e(route('category', $item->token)); ?>"><i class="fa-solid fa-eye"></i></a></td>
                                            <td>
                                                <a class="btn btn-success" href="<?php echo e(route('admin.category.sub', $item->id)); ?>"><i class="fa-solid fa-folder"></i></a>
                                                <a class="btn btn-success" href="<?php echo e(route('admin.category.edit', $item->id)); ?>"><i class="fa-solid fa-pen"></i></a>
                                                <form class="float-end ms-2" method="POST" action="<?php echo e(route('admin.category.delete', $item->id)); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger"><i class="fa-solid fa-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\xmrproject\resources\views/admin/category/all.blade.php ENDPATH**/ ?>