


<?php $__env->startSection('content-admin'); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <?php echo $__env->make('layouts.include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <h1 class="mt-4">Bannis</h1>
                        <div class="card">
                            <div class="card-header bg-dark text-white">Bannis</div>
                            <div class="card-body">
                                <form class="d-none d-md-inline-block form-inline w-100" action="" method="GET">
                                    <div class="input-group">
                                        <input class="form-control" value="<?php echo e(request()->input('query')); ?>" type="text" name="query" placeholder="Rechercher..." aria-label="Rechercher..." aria-describedby="btnNavbarSearch" />
                                        <button class="btn btn-success" id="btnNavbarSearch" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </div>
                                </form>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Photo de profil</th>
                                            <th>Nom d'utilisateur</th>
                                            <th>Rôle</th>
                                            <th>&nbsp;</th>
                                            <th>&nbsp;</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(request()->has('query')): ?>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$item->admin): ?>
                                                    <tr>
                                                        <?php if($item->picture != "default-avatar.png"): ?>
                                                            <td><img src="<?php echo e(asset('storage/'. $item->picture)); ?>" height="50" /></td>
                                                        <?php else: ?>
                                                            <td><img src="<?php echo e(asset('img/default-avatar.png')); ?>" height="50" /></td>
                                                        <?php endif; ?>
                                                        <td><?php echo e($item->name); ?></td>
                                                        <?php if($item->vendor): ?>
                                                            <td><span class="badge bg-success">Vendeur</span></td>
                                                        <?php else: ?>
                                                            <?php if($item->admin): ?>
                                                                <td><span class="badge bg-danger">Admin</span></td>
                                                            <?php else: ?>
                                                                <td><span class="badge bg-success">Client</span></td>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                        <td><a target="__blank" class="btn btn-success" href="<?php echo e(route('profil', $item->name)); ?>">Voir</a></td>
                                                        <td>
                                                        <?php if($item->ban == 0): ?>
                                                            <form method="POST" action="<?php echo e(route('admin.user.ban', $item->name)); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                                <button type="submit" class="btn btn-warning" href="#">Bannir</button>
                                                            </form>
                                                        <?php else: ?>
                                                            <form method="POST" action="<?php echo e(route('admin.user.unban', $item->name)); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                                <button type="submit" class="btn btn-warning" href="#">Débannir</button>
                                                            </form>
                                                        <?php endif; ?>
                                                        </td>
                                                    </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$item->admin): ?>
                                                    <tr>
                                                        <?php if($item->picture != "default-avatar.png"): ?>
                                                            <td><img src="<?php echo e(asset('storage/'. $item->picture)); ?>" height="50" /></td>
                                                        <?php else: ?>
                                                            <td><img src="<?php echo e(asset('img/default-avatar.png')); ?>" height="50" /></td>
                                                        <?php endif; ?>
                                                        <td><?php echo e($item->name); ?></td>
                                                        <?php if($item->vendor): ?>
                                                            <td><span class="badge bg-success">Vendeur</span></td>
                                                        <?php else: ?>
                                                            <?php if($item->admin): ?>
                                                                <td><span class="badge bg-danger">Admin</span></td>
                                                            <?php else: ?>
                                                                <td><span class="badge bg-success">Client</span></td>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                        <td><a target="__blank" class="btn btn-success" href="<?php echo e(route('profil', $item->name)); ?>">Voir</a></td>
                                                        <td>
                                                        <?php if($item->ban == 0): ?>
                                                            <form method="POST" action="<?php echo e(route('admin.user.ban', $item->name)); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                                <button type="submit" class="btn btn-warning" href="#">Bannir</button>
                                                            </form>
                                                        <?php else: ?>
                                                            <form method="POST" action="<?php echo e(route('admin.user.unban', $item->name)); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                                <button type="submit" class="btn btn-warning" href="#">Débannir</button>
                                                            </form>
                                                        <?php endif; ?>
                                                        </td>
                                                    </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <?php if(request()->has('query')): ?>
                            <div><?php echo e($users->links('pagination::simple-bootstrap-5')); ?></div>
                        <?php else: ?>
                            <div><?php echo e($all->links('pagination::simple-bootstrap-5')); ?></div>
                        <?php endif; ?>
                    </div>
                </main>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/admin/users/banned.blade.php ENDPATH**/ ?>