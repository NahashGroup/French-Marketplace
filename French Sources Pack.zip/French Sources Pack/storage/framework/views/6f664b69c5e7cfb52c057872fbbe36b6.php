


<?php $__env->startSection('content-admin'); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <?php echo $__env->make('layouts.include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <h1 class="mt-4">Dashboard</h1>
                        <div class="row">
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-dark text-white mb-4">
                                    <div class="card-body"><p class="text-center mb-0"><span class="fs-2"><?php echo e($cVendor); ?></span> Vendors</p></div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white text-decoration-none" href="<?php echo e(route('admin.vendor.all')); ?>">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-dark text-white mb-4">
                                    <div class="card-body"><p class="text-center mb-0"><span class="fs-2"><?php echo e($cCustomers); ?></span> Customers</p></div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white text-decoration-none" href="<?php echo e(route('admin.customer.all')); ?>">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-dark text-white mb-4">
                                    <div class="card-body"><p class="text-center mb-0"><span class="fs-2"><?php echo e($cProducts); ?></span> Products</p></div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white text-decoration-none" href="<?php echo e(route('admin.product.all')); ?>">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-dark text-white mb-4">
                                    <div class="card-body"><p class="text-center mb-0"><span class="fs-2"><?php echo e($cTickets); ?></span> Tickets</p></div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white text-decoration-none" href="<?php echo e(route('admin.support.all')); ?>">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card mb-4">
                                    <div class="card-header bg-dark text-white">Wallet info</div>
                                    <div class="card-body">
                                        <div class="form-floating mb-4">
                                            <input placeholder="Address" type="text" value="<?php echo e($get_addr_first['address']); ?>" class="form-control mb-4" disabled />
                                            <label class="form-label">Address <span style="color:red">*</span></label>
                                        </div>
                                        <div class="form-floating mb-4">
                                            <input placeholder="Total" type="text" value="<?php echo e($total_amount); ?> XMR" class="form-control mb-4" disabled />
                                            <label class="form-label">Total <span style="color:red">*</span></label>
                                        </div>
                                        <div class="form-floating mb-4">
                                            <input placeholder="Total Unlocked" type="text" value="<?php echo e($unlock_amount); ?> XMR" class="form-control mb-4" disabled />
                                            <label class="form-label">Total Unlocked <span style="color:red">*</span></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card mb-4">
                                    <div class="card-header bg-dark text-white">Total Orders/Amount</div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-xl-6 col-md-6">
                                                <div class="card bg-dark text-white mb-4">
                                                    <div class="card-body">
                                                        <p class="text-center mb-0">
                                                            <?php if(App\Models\Settings::test() == 1): ?>
                                                                <span class="fs-2"><?php echo e($cOrdersTest); ?></span> Orders
                                                            <?php else: ?>
                                                                <span class="fs-2"><?php echo e($cOrdersProd); ?></span> Orders
                                                            <?php endif; ?>
                                                        </p>
                                                    </div>
                                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                                        <?php if(App\Models\Settings::test() == 1): ?>
                                                            <span class="badge bg-warning w-100">Test mode</span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-6 col-md-6">
                                                <div class="card bg-dark text-white mb-4">
                                                    <div class="card-body">
                                                        <p class="text-center mb-0">
                                                            <?php if(App\Models\Settings::test() == 1): ?>
                                                                <span class="fs-2"><?php echo e($cTotalAmountTest); ?></span> EUR<br>
                                                                <span class="fs-5"><?php echo e($cTotalXmrTest); ?></span> XMR
                                                            <?php else: ?>
                                                                <span class="fs-2"><?php echo e($cTotalAmountProd); ?></span> EUR<br>
                                                                <span class="fs-5"><?php echo e($cTotalXmrProd); ?></span> XMR
                                                            <?php endif; ?>
                                                        </p>
                                                    </div>
                                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                                        <?php if(App\Models\Settings::test() == 1): ?>
                                                            <span class="badge bg-warning w-100">Test mode</span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card mb-4">
                            <div class="card-header bg-dark text-white"><i class="fas fa-users me-1"></i> Users</div>
                            <div class="card-body">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Picture</th>
                                            <th>Username</th>
                                            <th>Role</th>
                                            <th>&nbsp;</th>
                                            <th>&nbsp;</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <?php if($item->picture != "default-avatar.png"): ?>
                                                <td><img src="<?php echo e(asset('storage/'. $item->picture)); ?>" height="50" /></td>
                                            <?php else: ?>
                                                <td><img src="<?php echo e(asset('img/default-avatar.png')); ?>" height="50" /></td>
                                            <?php endif; ?>
                                            <td><?php echo e($item->name); ?></td>
                                            <?php if($item->vendor): ?>
                                                <td><span class="badge bg-success">Vendor</span></td>
                                            <?php else: ?>
                                                <?php if($item->admin): ?>
                                                    <td><span class="badge bg-danger">Admin</span></td>
                                                <?php else: ?>
                                                    <td><span class="badge bg-success">Customer</span></td>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <td><a target="__blank" class="btn btn-success" href="<?php echo e(route('profil', $item->name)); ?>">View</a></td>
                                            <td><a class="btn btn-warning" href="#">Ban</a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card mb-4">
                            <div class="card-header bg-dark text-white"><i class="fas fa-cart-shopping me-1"></i> Products</div>
                            <div class="card-body">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Picture</th>
                                            <th>Name</th>
                                            <th>Price</th>
                                            <th>Stock</th>
                                            <th>Shipping to</th>
                                            <th>&nbsp;</th>
                                            <th>&nbsp;</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><img src="<?php echo e(asset('storage/'.$item->picture)); ?>" height="50" /></td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->price); ?></td>
                                            <td><?php echo e($item->stock); ?></td>
                                            <td><?php echo e($item->delivery->country->nicename); ?></td>
                                            <td><a target="__blank" class="btn btn-success" href="<?php echo e(route('product', $item->token)); ?>">View</a></td>
                                            <td>
                                                <?php if($item->locked == 0): ?>
                                                    <form method="POST" action="<?php echo e(route('admin.product.locked', $item->token)); ?>" >
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?>
                                                        <button type="submit" class="btn btn-warning"><i class="fa-solid fa-lock"></i></button>
                                                    </form>
                                                <?php else: ?>
                                                    <form method="POST" action="<?php echo e(route('admin.product.unlocked', $item->token)); ?>" >
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?>
                                                        <button type="submit" class="btn btn-warning"><i class="fa-solid fa-unlock"></i></button>
                                                    </form>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\xmrproject\resources\views/admin/index.blade.php ENDPATH**/ ?>