


<?php $__env->startSection('content-admin'); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <?php echo $__env->make('layouts.include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <h1 class="mt-4">Categories</h1>
                        <div class="card">
                            <div class="card-header bg-dark text-white">
                                <p class="mb-0 float-start">
                                <?php if($category->parent_id == 0): ?>
                                    <a class="text-decoration-none text-white" href="<?php echo e(route('admin.categories')); ?>"><i class="fa-solid fa-chevron-left"></i>
                                    <?php echo e($category->name); ?></a> 
                                <?php else: ?>
                                    <a class="text-decoration-none text-white" href="<?php echo e(route('admin.category.sub', $category->parent_id)); ?>"><i class="fa-solid fa-chevron-left"></i>
                                    <?php echo e($category->name); ?></a>
                                <?php endif; ?>
                                </p> 
                                    <a href="<?php echo e(route('admin.category.new')); ?>" class="btn btn-success float-end d-flex"><i class="fa-solid fa-plus"></i></a>
                                </div>
                            <div class="card-body">
                                <form class="d-none d-md-inline-block form-inline w-100" action="" method="GET">
                                    <div class="input-group">
                                        <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                                        <button class="btn btn-success" id="btnNavbarSearch" type="button"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </div>
                                </form>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>&nbsp;</th>
                                            <th>&nbsp;</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $subCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><a target="__blank" class="btn btn-success" href="<?php echo e(route('category', $item->token)); ?>">View</a></td>
                                            <td>
                                                <a class="btn btn-success" href="<?php echo e(route('admin.category.sub', $item->id)); ?>"><i class="fa-solid fa-folder"></i></a>
                                                <a class="btn btn-success" href="<?php echo e(route('admin.category.edit', $item->id)); ?>">Edit</a>
                                                <form class="float-end ms-2" method="POST" action="<?php echo e(route('admin.category.delete', $item->id)); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger"><i class="fa-solid fa-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\xmrproject\resources\views/admin/category/subcat.blade.php ENDPATH**/ ?>