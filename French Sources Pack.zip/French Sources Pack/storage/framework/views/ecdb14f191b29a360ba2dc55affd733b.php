


<?php $__env->startSection('content-admin'); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <?php echo $__env->make('layouts.include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <h1 class="mt-4">Orders</h1>
                        <div class="card">
                            <div class="card-header bg-dark text-white">Orders - <?php echo e($order->token); ?></div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                      <p class="mb-0"><strong>Customer</strong></p>
                                      <p class="mb-0">Name : <a target="__blank" href="<?php echo e(route('profil', $order->customer->name)); ?>" class="badge bg-success text-decoration-none"><?php echo e($order->customer->name); ?></a></p>
                                      <p class="mb-0">Created : <?php echo e(date('d-m-Y', strtotime($order->created_at))); ?></p>
                                      <p class="mb-0">Payment : Monero (XMR)</p>
                                    </div>
                                    <div class="col-lg-6">
                                      <p class="mb-0"><strong>Vendor</strong></p>
                                      <p class="mb-0">Name : <a target="__blank" href="<?php echo e(route('profil', $order->vendor->user->name)); ?>" class="badge bg-success text-decoration-none"><?php echo e($order->vendor->user->name); ?></a></p>
                                    </div>
                                  </div>
                                  <div class="mt-4">
                                    <table class="table">
                                      <thead>
                                        <tr>
                                          <th scope="col">Picture</th>
                                          <th scope="col">Name</th>
                                          <th scope="col">Price in XMR</th>
                                          <th scope="col">Status</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        <tr>
                                          <td class="align-middle"><img class="mb-2" src="<?php echo e(asset('storage/'.$order->product_picture)); ?>" height="70" /></td>
                                          <td class="align-middle"><?php echo e($order->product_name); ?> XMR</td>
                                          <td class="align-middle"><?php echo e($order->monero_price); ?> XMR</td>
                                          <?php if($order->status == 0): ?>
                                            <td class="align-middle"><span class="badge bg-primary">New order</span></td>
                                          <?php else: ?>
                                            <td class="align-middle"><span class="badge bg-success">Address send</span></td>
                                          <?php endif; ?>
                                        </tr>
                                      </tbody>
                                    </table>
                                    <?php if($order->gps == 0): ?>
                                    <p>GPS Coordinate : <span class="badge bg-primary">Not active</span></p>
                                        <div class="form-floating mb-4">
                                          <textarea style="height:350px" placeholder="Address" class="form-control mb-4" disabled><?php echo e($order->address); ?></textarea>
                                          <label for="floatingInputGroup1">Address <span style="color:red">*</span></label>
                                        </div>
                                    <?php else: ?>
                                    <p>GPS Coordinate : <span class="badge bg-success">Active</span></p>
                                      <?php if($order->status == 2): ?>
                                        <div class="form-floating mb-4">
                                          <textarea style="height:280px" placeholder="GPS info" name="info" class="form-control mb-4" disabled><?php echo e($gps->info); ?></textarea>
                                          <label for="floatingInputGroup1">GPS Coordinate <span style="color:red">*</span></label>
                                        </div>
                                      <?php else: ?>
                                      <div class="alert alert-warning">GPS Coordinate not received !</div>
                                      <?php endif; ?>
                                    <?php endif; ?>
                                  </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\xmrproject\resources\views/admin/market/orders/order.blade.php ENDPATH**/ ?>