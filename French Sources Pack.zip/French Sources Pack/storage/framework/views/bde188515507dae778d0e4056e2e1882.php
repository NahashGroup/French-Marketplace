

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-3">
        <?php echo $__env->make('layouts.menu.profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white">Dashboard</div>
        <div class="card-body">
          <div class="row">
            <div class="col-lg-4">
              <div class="card">
                <div class="card-body text-center text-white bg-dark">
                  <p class="fs-3 mb-0 text-center"><?php echo e($cOrder); ?></p>
                  <small class="fs-6">Orders</small>
                  <hr class="mb-1 mt-1">
                  <?php if(App\Models\Settings::test() == 1): ?>
                    <a class="text-decoration-none text-white" href="<?php echo e(route('order.test.all')); ?>"><small>View details</small></a>
                    <span class="badge bg-warning">Test mode</span>
                  <?php else: ?>
                    <a class="text-decoration-none text-white" href="<?php echo e(route('order.all')); ?>"><small>View details</small></a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="card">
                <div class="card-body text-center text-white bg-dark">
                  <p class="fs-3 mb-0 text-center"><?php echo e($cTicket); ?></p>
                  <small class="fs-6">Tickets</small>
                  <hr class="mb-1 mt-1">
                  <a class="text-decoration-none text-white" href="<?php echo e(route('profil.ticket.all')); ?>"><small>View details</small></a>
                </div>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="card">
                <div class="card-body text-center text-white bg-dark">
                  <p class="fs-3 mb-0 text-center"><?php echo e($cWishlist); ?></p>
                  <small class="fs-6">Wishlists</small>
                  <hr class="mb-1 mt-1">
                  <a class="text-decoration-none text-white" href="<?php echo e(route('profil.wishlist.all')); ?>"><small>View details</small></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="card mt-2">
        <div class="card-header bg-dark text-white">Last orders</div>
        <div class="card-body">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">#ID</th>
                <th scope="col">Price in XMR</th>
                <th scope="col">Status</th>
                <th scope="col">&nbsp;</th>
              </tr>
            </thead>
            <tbody>
            <?php if(App\Models\Settings::test() == 1): ?>
              <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="align-middle"><?php echo e($item->token); ?></td>
                  <td class="align-middle"><?php echo e($item->monero_price); ?> XMR</td>
                  <?php if($item->status == 0): ?>
                  <td class="align-middle"><span class="badge bg-primary">New order</span></td>
                  <?php else: ?>
                  <?php if($item->status == 1): ?>
                  <td class="align-middle"><span class="badge bg-success">Address send</span></td>
                  <?php else: ?>
                    <?php if($item->status == 2): ?>
                      <td class="align-middle"><span class="badge bg-success">Order send</span></td>
                    <?php else: ?>
                      <?php if($item->status == 3): ?>
                        <td class="align-middle"><span class="badge bg-success">Order completed</span></td>
                      <?php endif; ?>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php endif; ?>
                  <td class="align-middle"><a href="<?php echo e(route('order.test.show', $item->token)); ?>" class="btn btn-success">View</a></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php if($orders->isEmpty()): ?>
                <tr>
                  <td colspan="4"><div class="alert alert-warning text-center">No orders</div></td>
                </tr>
              <?php endif; ?>
            <?php else: ?>
              <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                  <td class="align-middle"><?php echo e($item->token); ?></td>
                  <td class="align-middle"><?php echo e($item->monero_price); ?> XMR</td>
                  <?php if($item->status == 0): ?>
                  <td class="align-middle"><span class="badge bg-primary">New order</span></td>
                  <?php else: ?>
                  <?php if($item->status == 1): ?>
                  <td class="align-middle"><span class="badge bg-success">Address send</span></td>
                  <?php else: ?>
                    <?php if($item->status == 2): ?>
                      <td class="align-middle"><span class="badge bg-success">Order send</span></td>
                    <?php else: ?>
                      <?php if($item->status == 3): ?>
                        <td class="align-middle"><span class="badge bg-success">Order completed</span></td>
                      <?php endif; ?>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php endif; ?>
                    <td class="align-middle"><a href="<?php echo e(route('order.show', $item->token)); ?>" class="btn btn-success">View</a></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php if($orders->isEmpty()): ?>
                <tr>
                  <td colspan="4"><div class="alert alert-warning text-center">No orders</div></td>
                </tr>
              <?php endif; ?>
            <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="card mt-2 mb-2">
        <div class="card-header bg-dark text-white">Last tickets</div>
        <div class="card-body">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">#ID</th>
                <th scope="col">Subject</th>
                <th scope="col">Status</th>
                <th scope="col">&nbsp;</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="align-middle"><?php echo e($item->token); ?></td>
                  <td class="align-middle"><?php echo e($item->subject); ?></td>
                  <?php if($item->status == 0 ): ?>
                    <td class="align-middle"><span class="badge bg-primary">Open</span></td>
                  <?php else: ?>
                    <td class="align-middle"><span class="badge bg-success">Solved</span></td>
                  <?php endif; ?>
                  <td class="align-middle"><a href="<?php echo e(route('profil.ticket.show', $item->token)); ?>" class="btn btn-success">View</a></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php if($tickets->isEmpty()): ?>
                <tr>
                  <td colspan="4"><div class="alert alert-warning text-center">No ticket</div></td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="card mt-2 mb-2">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Last wishlists</p></div>
        <div class="card-body">
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Price</th>
                    <th scope="col">&nbsp;</th>
                    <th scope="col">&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="align-middle"><?php echo e($item->product->name); ?></td>
                    <td class="align-middle"><?php echo e($item->product->price); ?> EUR</td>
                    <td class="align-middle"><a href="<?php echo e(route('product', $item->product_token)); ?>" class="btn btn-success"><i class="fa-solid fa-eye"></i></a></td>
                    <td class="align-middle">
                        <form method="POST" action="<?php echo e(route('wishlist.remove', $item->token)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger"><i class="fa-solid fa-trash"></i></button>
                        </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php if($wishlists->isEmpty()): ?>
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">No wishlist</div></td>
                    </tr>
                  <?php endif; ?>
                </tbody>
            </table>
        </div>
      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\xmrproject\resources\views/profil/dashboard.blade.php ENDPATH**/ ?>