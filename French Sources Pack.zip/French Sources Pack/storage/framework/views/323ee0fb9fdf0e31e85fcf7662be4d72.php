<?php $__env->startSection('content'); ?>
    <div class="card">
      <div class="card-header bg-dark text-white"><h4>Informations</h4></div>
      <div class="card-body"><?php echo e($settings->information_index); ?></div>
  </div>
  <div class="row">
    <?php echo $__env->make('layouts.menu.left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-lg-9">
      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Top des Vendeurs</div>
      </div>
        <div class="row">
          <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-2">
            <a href="#">
            <div class="card mt-2">
              <div class="card-body">
                <?php if($item->vendor->user->picture == "default-avatar.png"): ?>
                  <img height="100" src="<?php echo e(asset('img/default-avatar.png')); ?>" class="vendor-profil-picture" />
                <?php else: ?>
                  <img height="100" src="<?php echo e(asset('storage/'.$item->vendor->user->picture)); ?>" class="vendor-profil-picture" />
                <?php endif; ?>
                <p class="text-center mb-0"><a href="<?php echo e(route('profil', $item->vendor->user->name)); ?>" class="badge bg-success text-decoration-none" ><?php echo e($item->vendor->user->name); ?></a></p>
              </div>
            </div>
            </a>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </diV>
      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Meilleures Offres</div>
      </div>
      <div class="row">
        <?php echo $__env->make('layouts.include.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div><?php echo e($products->links('pagination::simple-bootstrap-5')); ?></div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/index.blade.php ENDPATH**/ ?>