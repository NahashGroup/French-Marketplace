

<?php $__env->startSection('content'); ?>
  <div class="row">
    <?php echo $__env->make('layouts.menu.left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-lg-9">
      <div class="card mt-4">
        <div class="card-header bg-dark text-white"><p class="mb-0">Boutique de <?php echo e($user->name); ?></p></div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-3">
                  <?php if($user->picture == "default-avatar.png"): ?>
                    <img src="<?php echo e(asset('img/default-avatar.png')); ?>" width="200" />
                  <?php else: ?>
                    <img src="<?php echo e(asset('storage/'.$user->picture)); ?>" width="200" />
                  <?php endif; ?>
                </div>
                <div class="col-lg-3">
                    <h3 class="mb-0"><?php echo e($user->name); ?></h3>
                    <?php if($user->vendor): ?>
                      <p class="mb-4"><span class="badge bg-success">Vendeur</span></p>
                    <?php else: ?>
                      <?php if($user->admin): ?>
                        <p class="mb-4"><span class="badge bg-danger">Admin</span></p>
                      <?php else: ?>
                      <p class="mb-4"><span class="badge bg-success">Client</span></p>
                      <?php endif; ?>
                    <?php endif; ?>
                    <?php if(auth()->guard()->check()): ?>
                      <?php if(Auth::user()->id != $user->id): ?>
                        <a href="<?php echo e(route('profil.message.new', ['name' => $user->name])); ?>" class="btn btn-success mb-2 profil-button"><i class="fa-solid fa-paper-plane"></i> Envoyer un message</a><br>
                        <a href="<?php echo e(route('profil.ticket.new', ['subject' => 'report'])); ?>" class="btn btn-danger profil-button"><i class="fa-solid fa-flag"></i> Signaler l'utilisateur</a>
                      <?php endif; ?>
                    <?php endif; ?>
                </div>
                <?php if($user->vendor): ?>
                <div class="col-lg-5">
                  <h5>Statistiques du vendeur</h5>
                  <hr>
                  <div style="width:100%">
                    <p class="mb-0">Qualité</p>
                    <div class="progress" role="progressbar" aria-label="Example with label" aria-valuenow="<?php echo e($user->totalQualityUserSum($user->name)); ?>" aria-valuemin="0" aria-valuemax="100">
                      <div class="progress-bar" style="width: <?php echo e($user->totalQualityUserSum($user->name)); ?>%"><?php echo e($user->totalQualityUserSum($user->name)); ?>%</div>
                    </div>
                  </div>
                  <p class="mb-0">Communication</p>
                  <div class="progress" role="progressbar" aria-label="Example with label" aria-valuenow="<?php echo e($user->totalCommuUserSum($user->name)); ?>" aria-valuemin="0" aria-valuemax="100">
                    <div class="progress-bar" style="width: <?php echo e($user->totalCommuUserSum($user->name)); ?>%"><?php echo e($user->totalCommuUserSum($user->name)); ?>%</div>
                  </div>
                  <p class="mb-0">Livraison</p>
                  <div class="progress mb-4" role="progressbar" aria-label="Example with label" aria-valuenow="<?php echo e($user->totalDeliUserSum($user->name)); ?>" aria-valuemin="0" aria-valuemax="100">
                    <div class="progress-bar" style="width: <?php echo e($user->totalDeliUserSum($user->name)); ?>%"><?php echo e($user->totalDeliUserSum($user->name)); ?>%</div>
                  </div>
                  <a href="<?php echo e(route('profil', $user->name)); ?>" class="btn btn-success">Voir le profil</a>
                </div>
                <?php endif; ?>
            </div>
        </div>
      </div>
      <?php if($user->vendor): ?>
        <?php if($user->vendor->vacation == 1): ?>
          <div class="alert alert-danger mt-4"><?php echo e($user->name); ?> est actuellement en vacances, vous ne pouvez pas acheter de produits auprès de ce vendeur pour le moment.</div>
        <?php endif; ?>
      <?php endif; ?>
        <?php if(!empty($user->vendor->desc_shop)): ?>
        <div class="col-lg-12">
          <div class="card mt-4">
            <div class="card-header bg-dark text-white">Description de la boutique</div>
            <div class="card-body">
              <p class="desc-profil"><?php echo e($user->vendor->desc_shop); ?></div>
            </div>
          </div>
        </div>
        <?php endif; ?>
        <div class="card mt-4">
          <div class="card-header bg-dark text-white">Produits <?php echo e($user->name); ?></div>
        </div>
        <div class="row mb-4">
          <?php echo $__env->make('layouts.include.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
      <div><?php echo e($products->links('pagination::simple-bootstrap-5')); ?></div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/shop.blade.php ENDPATH**/ ?>