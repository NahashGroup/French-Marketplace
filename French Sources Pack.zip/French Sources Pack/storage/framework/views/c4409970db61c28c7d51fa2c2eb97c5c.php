

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-12">
      <div class="card mt-4">
        <div class="card-body">
            <div class="text-center">
                <h1 class="mb-0" style="font-family:impact;font-size: 100px;">404 Page non trouvée :(<h1>
                <a class="btn btn-success" href="<?php echo e(route('index')); ?>">Retour à l'accueil</a>
            </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/errors/404.blade.php ENDPATH**/ ?>