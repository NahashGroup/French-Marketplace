

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-3">
        <?php echo $__env->make('layouts.menu.profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-lg-9">
      <div class="card">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Messages</p> <a href="<?php echo e(route('profil.message.new')); ?>" class="btn btn-success float-end d-flex"><i class="fa-solid fa-plus"></i></a></div>
        <div class="card-body">
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">#ID</th>
                    <th scope="col">User</th>
                    <th scope="col">Last message</th>
                    <th scope="col">&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="align-middle"><?php echo e(\Illuminate\Support\Str::limit($item->token, 30, '...')); ?></td>
                      <?php if($item->from_id == Auth::user()->id): ?>
                        <td class="align-middle"><a href="<?php echo e(route('profil', $item->to->name)); ?>" class="badge bg-success text-decoration-none"><?php echo e($item->to->name); ?></a></td>
                      <?php else: ?>
                        <td class="align-middle"><a href="<?php echo e(route('profil', $item->from->name)); ?>" class="badge bg-success text-decoration-none"><?php echo e($item->from->name); ?></a> </td>
                      <?php endif; ?>
                      <td class="align-middle"><?php echo e(\Illuminate\Support\Str::limit($item->last_message, 30, '...')); ?></td>
                      <td class="align-middle"><a href="<?php echo e(route('profil.message.show', $item->token)); ?>" class="btn btn-success">View</a></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php if($messages->isEmpty()): ?>
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">No result</div></td>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>
              <div><?php echo e($messages->links('pagination::simple-bootstrap-5')); ?></div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\xmrproject\resources\views/profil/message/all.blade.php ENDPATH**/ ?>