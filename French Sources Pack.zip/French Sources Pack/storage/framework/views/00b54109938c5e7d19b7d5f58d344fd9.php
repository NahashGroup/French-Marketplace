

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-3">
        <?php echo $__env->make('layouts.menu.profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-lg-9">
      <?php if(App\Models\Settings::test() == 0): ?>
      <div class="card">
        <div class="card-header bg-dark text-white">Wallet</div>
        <div class="card-body">
              <label>Wallet amount</label>
              <?php if($balance['balance'] != 0): ?>
                <h3 class="mb-0"><i class="fa-solid fa-unlock text-success"></i> <?php echo e($monero->atomicToXMR($balance['unlocked_balance'])); ?></h3>
              <?php else: ?>
                <h3 class="mb-0"><i class="fa-solid fa-unlock text-success"></i> 0.000000000000</h3>
              <?php endif; ?>
              <?php if($balance['balance'] != 0): ?>
                <p><small> Total : <?php echo e($monero->atomicToXMR($balance['balance'])); ?></small></p>
              <?php else: ?>
                <p>Total : 0.000000000000</p>
              <?php endif; ?>
              <div class="form-floating mb-4">
                <input placeholder="Monero address" value="<?php echo e($address['address']); ?>" type="text" class="form-control" id="floatingInputGroup1" disabled>
                <label for="floatingInputGroup1">XMR Address <span style="color:red">*</span></label>
              </div>
        </div>
      </div>

      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Withdrawal</div>
        <div class="card-body">
          <form method="POST" action="<?php echo e(route('profil.wallet.withdrawal')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-floating mb-4">
              <input placeholder="Monero amount" type="text" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="amount" id="floatingInputGroup1">
              <label for="floatingInputGroup1">Amount <span style="color:red">*</span></label>
              <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-floating mb-4">
              <input placeholder="Monero address" type="text" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="address" id="floatingInputGroup1">
              <label for="floatingInputGroup1">Destination address <span style="color:red">*</span></label>
              <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn btn-success">Send</button>
          </form>
        </div>
      </div>

      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Last transactions - Received</div>
        <div class="card-body">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Confirmations</th>
                <th scope="col">Fee</th>
                <th scope="col">Amount</th>
                <th scope="col">Locked</th>
              </tr>
            </thead>
            <tbody>
            <?php if(array_key_exists('in', $trans)): ?>
              <?php $__currentLoopData = $trans['in']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><a target="__blank" href="http://explorer.monerotech.info:6001/tx/<?php echo e($item['txid']); ?>/1"><?php echo e(Str::limit($item['txid'], 15)); ?></a></td>
                  <td><?php echo e($item['confirmations']); ?></td>
                  <td><?php echo e(number_format($monero->atomicToXMR($item['fee']), 12)); ?></td>
                  <td><?php echo e(number_format($monero->atomicToXMR($item['amount']), 12)); ?></td>
                  <?php if($item['locked'] == true): ?>
                    <td><span class="badge bg-danger">Locked</span></td>
                  <?php else: ?>
                    <td><span class="badge bg-success">Unlocked</span></td>
                  <?php endif; ?>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <tr>
                <td colspan="5"><div class="alert alert-warning text-center">No 'In' transaction</div></td>
              </tr>
            <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Last transactions - Send</div>
        <div class="card-body">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Confirmations</th>
                <th scope="col">Fee</th>
                <th scope="col">Amount</th>
                <th scope="col">Locked</th>
              </tr>
            </thead>
            <tbody>
            <?php if(array_key_exists('out', $trans)): ?>
              <?php $__currentLoopData = $trans['out']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><a target="__blank" href="http://explorer.monerotech.info:6001/tx/<?php echo e($item['txid']); ?>/1"><?php echo e(Str::limit($item['txid'], 15)); ?></a></td>
                  <td><?php echo e($item['confirmations']); ?></td>
                  <td><?php echo e(number_format($monero->atomicToXMR($item['fee']), 12)); ?></td>
                  <td><?php echo e(number_format($monero->atomicToXMR($item['amount']), 12)); ?></td>
                  <?php if($item['locked'] == true): ?>
                    <td><span class="badge bg-danger">Locked</span></td>
                  <?php else: ?>
                    <td><span class="badge bg-success">Unlocked</span></td>
                  <?php endif; ?>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <tr>
                <td colspan="5"><div class="alert alert-warning text-center">No 'Out' transaction</div></td>
              </tr>
            <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>


      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Last transactions - Pending</div>
        <div class="card-body">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Confirmations</th>
                <th scope="col">Fee</th>
                <th scope="col">Amount</th>
                <th scope="col">Locked</th>
              </tr>
            </thead>
            <tbody>
            <?php if(array_key_exists('pending', $trans)): ?>
              <?php $__currentLoopData = $trans['pending']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><a target="__blank" href="http://explorer.monerotech.info:6001/tx/<?php echo e($item['txid']); ?>/1"><?php echo e(Str::limit($item['txid'], 15)); ?></a></td>
                  <td><?php echo e($item['confirmations']); ?></td>
                  <td><?php echo e(number_format($monero->atomicToXMR($item['fee']), 12)); ?></td>
                  <td><?php echo e(number_format($monero->atomicToXMR($item['amount']), 12)); ?></td>
                  <?php if($item['locked'] == true): ?>
                    <td><span class="badge bg-danger">Locked</span></td>
                  <?php else: ?>
                    <td><span class="badge bg-success">Unlocked</span></td>
                  <?php endif; ?>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <tr>
                <td colspan="5"><div class="alert alert-warning text-center">No 'Pending' transaction</div></td>
              </tr>
            <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php else: ?>
      <div class="card">
        <div class="card-header bg-dark text-white">Wallet</div>
        <div class="card-body">
          <div class="alert alert-warning">Wallet dont work on test mode !</div>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\xmrproject\resources\views/profil/wallet.blade.php ENDPATH**/ ?>