

<?php $__env->startSection('content'); ?>
  <div class="row">
    <?php echo $__env->make('layouts.menu.left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-lg-9">
      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Notification</div>
        <div class="card-body">
            <?php if($notifications->isEmpty()): ?>
                <div class="alert alert-warning">No notification.</div>
            <?php else: ?>
                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->order_token == NULL and $item->ticket_token == NULL): ?>
                        <div class="alert alert-info">
                            You receive a new message of <a class="text-dark text-decoration-none" href="<?php echo e(route('profil', $item->from->name)); ?>"><?php echo e($item->from->name); ?></a> on your conversation
                            
                            <form class="float-end" method="POST" action="<?php echo e(route('notification.message', $item->message_token)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <button type="submit" class="float-end button-send"><i class="fas fa-eye"></i></button>
                            </form>

                        </div>
                    <?php else: ?>
                        <?php if($item->order_token == NULL and $item->message_token == NULL): ?>
                            <div class="alert alert-info">
                                You receive a new message of <?php echo e($item->from->name); ?> on ticket #<?php echo e($item->ticket->token); ?>


                                <form class="float-end" method="POST" action="<?php echo e(route('notification.message', $item->ticket_token)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <button type="submit" class="float-end button-send"><i class="fas fa-eye"></i></button>
                                </form>

                            </div>
                        <?php else: ?>
                            <div class="alert alert-info">
                                You receive a new order from <?php echo e($item->from->name); ?> of <?php echo e($item->order->monero_price); ?> XMR
                                <form class="float-end" method="POST" action="<?php echo e(route('notification.message', $item->order_token)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <button type="submit" class="float-end button-send"><i class="fas fa-eye"></i></button>
                                </form>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div><?php echo e($notifications->links('pagination::simple-bootstrap-5')); ?></div>
            <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\xmrproject\resources\views/notification.blade.php ENDPATH**/ ?>