

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-3">
        <?php echo $__env->make('layouts.menu.profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Tableau de bord</p></div>
        <div class="card-body">
          <div class="row">
            <div class="col-lg-12">
              <div class="card bg-dark text-white mb-2">
                <div class="card-header pb-0">Total earnings <?php if(App\Models\Settings::test() == 1): ?> <span class="badge bg-warning">Mode test</span><?php endif; ?></div>
                <hr class="mb-2 mt-2">
                <div class="card-body pt-0">
                  <div class="row">
                    <div class="col-lg-6">
                      <p class="fs-3 mb-0 text-center"><?php if(App\Models\Settings::test() == 1): ?> <?php echo e($totalEurTest); ?> <?php else: ?> <?php echo e($totalEur); ?> <?php endif; ?> <small class="fs-6">EUR</small></p>
                    </div>
                    <div class="col-lg-6">
                      <p class="fs-3 mb-0 text-center"><?php if(App\Models\Settings::test() == 1): ?> <?php echo e($totalXmrTest); ?> <?php else: ?> <?php if($totalXmr != 0): ?> <?php echo e($totalXmr); ?> <?php else: ?> 0.000000000000 <?php endif; ?> <?php endif; ?> <small class="fs-6">XMR</small></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="card bg-dark text-white">
                <div class="card-body">
                  <p class="fs-3 mb-0 text-center"><?php if(App\Models\Settings::test() == 1): ?> <?php echo e($cSalesTest); ?> <?php else: ?> <?php echo e($cSales); ?> <?php endif; ?> <small class="fs-6">Ventes</small></p>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="card bg-dark text-white">
                <div class="card-body">
                  <p class="fs-3 mb-0 text-center"><?php echo e($cProducts); ?> <small class="fs-6">Produits</small></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="card mt-2">
        <div class="card-header bg-dark text-white">Dernières ventes</div>
        <div class="card-body">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">#ID</th>
                <th scope="col">Prix en XMR</th>
                <th scope="col">Statut</th>
                <th scope="col">&nbsp;</th>
              </tr>
            </thead>
            <tbody>
            <?php if(App\Models\Settings::test() == 1): ?>
              <?php $__currentLoopData = $salesTest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="align-middle"><?php echo e($item->token); ?></td>
                  <td class="align-middle"><?php echo e($item->monero_price); ?> XMR</td>
                  <?php if($item->status == 0): ?>
                  <td class="align-middle"><span class="badge bg-primary">Nouvelle commande</span></td>
                  <?php else: ?>
                  <?php if($item->status == 1): ?>
                  <td class="align-middle"><span class="badge bg-success">Adresse envoyée</span></td>
                  <?php else: ?>
                    <?php if($item->status == 2): ?>
                      <td class="align-middle"><span class="badge bg-success">Commande envoyée</span></td>
                    <?php else: ?>
                      <?php if($item->status == 3): ?>
                        <td class="align-middle"><span class="badge bg-success">Commande terminée</span></td>
                      <?php endif; ?>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php endif; ?>
                  <td class="align-middle"><a href="<?php echo e(route('sale.test.show', $item->token)); ?>" class="btn btn-success">Voir</a></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                  <td class="align-middle"><?php echo e($item->token); ?></td>
                  <td class="align-middle"><?php echo e($item->monero_price); ?> XMR</td>
                  <?php if($item->status == 0): ?>
                  <td class="align-middle"><span class="badge bg-primary">Nouvelle commande</span></td>
                  <?php else: ?>
                  <?php if($item->status == 1): ?>
                  <td class="align-middle"><span class="badge bg-success">Adresse envoyée</span></td>
                  <?php else: ?>
                    <?php if($item->status == 2): ?>
                      <td class="align-middle"><span class="badge bg-success">Commande envoyée</span></td>
                    <?php else: ?>
                      <?php if($item->status == 3): ?>
                        <td class="align-middle"><span class="badge bg-success">Commande terminée</span></td>
                      <?php endif; ?>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php endif; ?>
                    <td class="align-middle"><a href="<?php echo e(route('sale.show', $item->token)); ?>" class="btn btn-success">Voir</a></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="card mt-2">
        <div class="card-header bg-dark text-white">Derniers produits</div>
        <div class="card-body">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">Photo</th>
                <th scope="col">Titre</th>
                <th scope="col">Prix</th>
                <th scope="col">Catégorie</th>
                <th scope="col">Stock</th>
                <th scope="col">&nbsp;</th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="align-middle"><img class="mb-2" src="<?php echo e(asset('storage/'.$item->picture)); ?>" height="70" /></td>
                <td class="align-middle"><?php echo e($item->name); ?></td>
                <td class="align-middle"><?php echo e($item->price); ?></td>
                <td class="align-middle"><?php echo e($item->category_id); ?></td>
                <td class="align-middle"><?php echo e($item->stock); ?></td>
                <td class="align-middle"><a href="<?php echo e(route('product.edit', $item->token)); ?>" class="btn btn-success">Modifier</a> <a href="<?php echo e(route('product', $item->token)); ?>" class="btn btn-success">Voir</a></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/seller/dashboard.blade.php ENDPATH**/ ?>