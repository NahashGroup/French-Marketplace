

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-3">
        <?php echo $__env->make('layouts.menu.profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-lg-9">
      <div class="card">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Commande : <?php echo e($order->token); ?></p></div>
        <div class="card-body">
            <div class="row">
              <div class="col-lg-6">
                <p class="mb-0"><strong>Client</strong></p>
                <p class="mb-0">Nom d'utilisateur : <a target="__blank" href="<?php echo e(route('profil', $order->customer->name)); ?>" class="badge bg-success text-decoration-none"><?php echo e($order->customer->name); ?></a></p>
                <p class="mb-0">Création : <?php echo e(date('d-m-Y', strtotime($order->created_at))); ?></p>
                <p class="mb-0">Paiement : Monero (XMR) </p>
              </div>
              <div class="col-lg-6">
                <p class="mb-0"><strong>Vendeur</strong></p>
                <p class="mb-0">Nom d'utilisateur : 
                  <a target="__blank" href="<?php echo e(route('profil', $order->vendor->user->name)); ?>" class="badge bg-success text-decoration-none"><?php echo e($order->vendor->user->name); ?></a>
                  <a href="<?php echo e(route('profil.message.new', ['name' => $order->vendor->user->name])); ?>" class="badge bg-success"><i class="fa-solid fa-envelope"></i></a>
                  <a href="<?php echo e(route('profil.ticket.new', ['subject' => 'report'])); ?>" class="badge bg-danger"><i class="fa-solid fa-flag"></i></a>
                </p>
              </div>
            </div>
            <div class="mt-4">
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Photo</th>
                    <th scope="col">Titre</th>
                    <th scope="col">Prix en XMR</th>
                    <th scope="col">Statut</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="align-middle"><img class="mb-2" src="<?php echo e(asset('storage/'.$order->product_picture)); ?>" height="70" /></td>
                    <td class="align-middle"><?php echo e($order->product_name); ?></td>
                    <td class="align-middle"><?php echo e($order->monero_price); ?> XMR</td>
                    <?php if($order->status == 0): ?>
                      <td class="align-middle"><span class="badge bg-primary">Nouvelle commande</span></td>
                    <?php else: ?>
                      <?php if($order->status == 1): ?>
                        <td class="align-middle"><span class="badge bg-success">Adresse envoyée</span></td>
                        <?php else: ?>
                          <?php if($order->status == 2): ?>
                            <td class="align-middle"><span class="badge bg-success">Commande envoyée</span></td>
                          <?php else: ?>
                            <?php if($order->status == 3): ?>
                              <td class="align-middle"><span class="badge bg-success">Commande terminée</span></td>
                            <?php endif; ?>
                          <?php endif; ?>
                      <?php endif; ?>
                    <?php endif; ?>
                  </tr>
                </tbody>
              </table>
              <?php if($order->gps == 0): ?>
                <?php if(empty($order->address)): ?>
                <form method="POST" action="<?php echo e(route('order.address', $order->token)); ?>">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PUT'); ?>
                  <div class="form-floating mb-4">
                    <textarea style="height:280px" placeholder="Saisissez votre adresse de livraison" name="address" class="form-control mb-4"></textarea>
                    <label for="floatingInputGroup1">Adresse <span style="color:red">*</span></label>
                  </div>
                  <button type="submit" class="btn btn-success mb-4">Envoyer l'adresse</button>
                  <div class="alert alert-primary">Votre adresse sera chiffrée avec la clé PGP du vendeur !</div>
                </form>
                <?php else: ?>
                  <div class="form-floating mb-4">
                    <textarea style="height:280px" placeholder="Saisissez votre adresse de livraison" name="address" class="form-control mb-4" disabled><?php echo e($order->address); ?></textarea>
                    <label for="floatingInputGroup1">Adresse <span style="color:red">*</span></label>
                  </div>
                <?php endif; ?>
              <?php else: ?>
                <?php if($order->status == 2): ?>
                  <div class="form-floating mb-4">
                    <textarea style="height:280px" placeholder="Infos GPS" name="info" class="form-control mb-4" disabled><?php echo e($gps->info); ?></textarea>
                    <label for="floatingInputGroup1">Coordonnées GPS <span style="color:red">*</span></label>
                  </div>
                <?php else: ?>
                  <div class="alert alert-warning">Vous recevrez des instructions du vendeur, avec les coordonnées GPS de l'endroit où se trouve votre produit, ainsi que des informations supplémentaires pour vous aider à le trouver.</div>
                <?php endif; ?>
              <?php endif; ?>
              <?php if($order->status == 2): ?>
                <form method="POST" action="<?php echo e(route('order.confirm', $order->token)); ?>">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PUT'); ?>
                  <button type="submit" class="btn btn-success mb-2 float-start">J'ai reçu la commande</div>
                </form>
              <?php endif; ?>
              <a href="<?php echo e(route('profil.ticket.new', ['subject' => 'order', 'title' => $order->token])); ?>" class="btn btn-danger float-end"><i class="fa-solid fa-flag"></i> Signaler la commande</a>
            </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/profil/order/order.blade.php ENDPATH**/ ?>