

<?php $__env->startSection('content'); ?>
  <div class="row">
    <?php echo $__env->make('layouts.menu.left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-lg-9">
      <div class="card mt-4">
        <div class="card-header bg-dark text-white"><p class="mb-0">Boutiques</p></div>
      </div>
      <div class="row">
        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3">
            <div class="card mt-4">
                <div class="card-body text-center">
                    <?php if($item->user->picture == "default-avatar.png"): ?>
                        <img src="<?php echo e(asset('img/default-avatar.png')); ?>" class="vendor-profil-picture" />
                    <?php else: ?>
                        <img src="<?php echo e(asset('storage/'.$item->user->picture)); ?>" class="vendor-profil-picture" />
                    <?php endif; ?>
                    <p class="mb-0"><a class="mt-2" href="<?php echo e(route('profil', $item->user->name)); ?>" ><span class="badge bg-success"><?php echo e($item->user->name); ?></span></a></p>
                        <p class="mb-0">Qualité</p>
                        <div class="progress" role="progressbar" aria-label="Example with label" aria-valuenow="<?php echo e($item->user->totalQualityUserSum($item->user->name)); ?>" aria-valuemin="0" aria-valuemax="100">
                          <div class="progress-bar" style="width: <?php echo e($item->user->totalQualityUserSum($item->user->name)); ?>%"><?php echo e($item->user->totalQualityUserSum($item->user->name)); ?>%</div>
                        </div>
                      <p class="mb-0">Communication</p>
                      <div class="progress" role="progressbar" aria-label="Example with label" aria-valuenow="<?php echo e($item->user->totalCommuUserSum($item->user->name)); ?>" aria-valuemin="0" aria-valuemax="100">
                        <div class="progress-bar" style="width: <?php echo e($item->user->totalCommuUserSum($item->user->name)); ?>%"><?php echo e($item->user->totalCommuUserSum($item->user->name)); ?>%</div>
                      </div>
                      <p class="mb-0">Livraison</p>
                      <div class="progress mb-4" role="progressbar" aria-label="Example with label" aria-valuenow="<?php echo e($item->user->totalDeliUserSum($item->user->name)); ?>" aria-valuemin="0" aria-valuemax="100">
                        <div class="progress-bar" style="width: <?php echo e($item->user->totalDeliUserSum($item->user->name)); ?>%"><?php echo e($item->user->totalDeliUserSum($item->user->name)); ?>%</div>
                      </div>
                    <p class="mb-0"><a class="btn btn-success" href="<?php echo e(route('shop', $item->User->name)); ?>">Voir la boutique</a></p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/shops.blade.php ENDPATH**/ ?>