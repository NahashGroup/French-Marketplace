<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Admin Panel</title>
        <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="<?php echo e(route('index')); ?>"><?php echo e(env('APP_NAME')); ?></a>
            <!-- Navbar Search-->
            <a target="__blank" href="<?php echo e(route('index')); ?>" class="btn btn-success">Voir la place de marché</a>
            <span class="nav-link active ms-4 text-white">Url : <?php echo e($_SERVER['SERVER_NAME']); ?></span>
            <span class="nav-link active ms-4 text-white">Port : <?php echo e($_SERVER['SERVER_PORT']); ?></span>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading text-light">Général</div>
                            <a class="nav-link active" href="<?php echo e(route('admin.index')); ?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Tableau de bord
                            </a>
                            <a class="nav-link active" href="<?php echo e(route('admin.settings')); ?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-cog"></i></div>
                                Paramètres
                            </a>
                            <div class="sb-sidenav-menu-heading text-light">Utilisateurs</div>
                            <a class="nav-link active" href="<?php echo e(route('admin.customer.all')); ?>" >
                                <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                                Clients
                            </a>
                            <a class="nav-link active" href="<?php echo e(route('admin.vendor.all')); ?>" >
                                <div class="sb-nav-link-icon"><i class="fas fa-dollar-sign"></i></div>
                                Vendeurs
                            </a>
                            <a class="nav-link active" href="<?php echo e(route('admin.user.banned')); ?>" >
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-ban"></i></div>
                                Bannis
                            </a>
                            <div class="sb-sidenav-menu-heading text-light">Marché</div>
                            <a class="nav-link active" href="<?php echo e(route('admin.product.all')); ?>">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-cart-shopping"></i></div>
                                Produits
                            </a>
                            <a class="nav-link active" href="<?php echo e(route('admin.categories')); ?>">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-list"></i></div>
                                Catégories
                            </a>
                            <?php if(App\Models\Settings::test() == 1): ?>
                                <a class="nav-link active" href="<?php echo e(route('admin.orders.test')); ?>">
                                    <div class="sb-nav-link-icon"><i class="fa-solid fa-money-bill"></i></div>
                                    Orders <span class="badge bg-warning ms-2">Mode test</span>
                                </a>
                            <?php else: ?>
                                <a class="nav-link active" href="<?php echo e(route('admin.orders')); ?>">
                                    <div class="sb-nav-link-icon"><i class="fa-solid fa-money-bill"></i></div>
                                    Commandes
                                </a>
                            <?php endif; ?>
                            <a class="nav-link active" href="<?php echo e(route('admin.support.all')); ?>">
                                <div class="sb-nav-link-icon"><i class="fa-regular fa-life-ring"></i></div>
                                Support
                            </a>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-danger ms-2 me-2 mt-4"><i class="fa-solid fa-right-from-bracket"></i> Se déconnecter</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Connecté en tant que:</div>
                        <span class="badge bg-danger"><i class="fas fa-user"></i> <?php echo e(Auth::user()->name); ?></span>
                    </div>
                </nav>
            </div>

            <?php echo $__env->yieldContent('content-admin'); ?>

        </div>
    </body>
</html><?php /**PATH /var/www/nouvellevaguemarket/resources/views/layouts/admin/app.blade.php ENDPATH**/ ?>