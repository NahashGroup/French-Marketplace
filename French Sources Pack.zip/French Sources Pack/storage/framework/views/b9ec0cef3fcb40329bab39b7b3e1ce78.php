    <div class="p-2 bg-dark text-white">Profil</div>
    <ul class="list-group">
        <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('profil.my.dashboard')); ?>">Dashboard</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('profil.edit.profil')); ?>">Picture & Description</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('profil.settings')); ?>">Settings</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('profil.wallet')); ?>">Wallet</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('profil.wishlist.all')); ?>">Wishlist</a></li>
        <?php if(App\Models\Settings::test() == 1): ?>
            <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('order.test.all')); ?>">Orders <span class="badge bg-warning">Test mode</span></a></li>
        <?php else: ?>
            <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('order.all')); ?>">Orders</li>
        <?php endif; ?>
        <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('profil.review.all')); ?>">Reviews</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('profiL.message.all')); ?>">Messages</a></li>
        <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('profil.ticket.all')); ?>">Support</a></li>
    </ul>
    <?php if(Auth::user()->vendor): ?>
        <div class="p-2 bg-dark text-white mt-4">Vendor</div>
        <ul class="list-group">
            <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('vendor.dashboard')); ?>">Dashboard</a></li>
            <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('vendor.settings')); ?>">Settings</a></li>
            <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('product.all')); ?>">Products</a></li>
            <?php if(App\Models\Settings::test() == 1): ?>
                <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('sale.test.all')); ?>">Sales <span class="badge bg-warning">Test mode</span></a></li>
            <?php else: ?>
                <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('sale.all')); ?>">Sales</li>
            <?php endif; ?>
            <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('product.stock.all')); ?>">Stocks</a></li>
            <li class="list-group-item"><a class="text-decoration-none" href="<?php echo e(route('deliveries.all')); ?>">Delivery</a></li>
        </ul>
    <?php endif; ?><?php /**PATH C:\laragon\www\xmrproject\resources\views/layouts/menu/profil.blade.php ENDPATH**/ ?>