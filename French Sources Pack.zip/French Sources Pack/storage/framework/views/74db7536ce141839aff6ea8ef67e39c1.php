

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-3">
        <?php echo $__env->make('layouts.menu.profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white">Settings</div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('profil.settings.update')); ?>" >
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-floating mb-4">
                  <textarea placeholder="Enter your PGP" style="height:450px" name="pgp" class="form-control mb-4"><?php echo e($user->pgp); ?></textarea>
                  <label class="form-label">PGP <span style="color:red">*</span></label>
                </div>
                <div class="form-check form-switch mb-2">
                  <input <?php if($user->twofa == 1): ?> checked <?php endif; ?> class="form-check-input" type="checkbox" value="1" name="twofa" role="switch" id="flexSwitchCheckDefault">
                  <label class="form-check-label" for="flexSwitchCheckDefault">2FA</label>
                </div>
                <div class="alert alert-primary">With 2FA Login, you will have to use your PGP key to decrypt the code that will be hidden in the signed message</div>
                <button type="submit" class="btn btn-success">Update info</button>
            </form>
            <hr>
            <form method="POST" action="<?php echo e(route('profil.settings.password.update')); ?>" >
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <div class="form-floating mb-4">
                <input placeholder="Password" type="password" name="password" class="form-control mb-4" />
                <label class="form-label">Password <span style="color:red">*</span></label>
              </div>
              <div class="form-floating mb-4">
                <input placeholder="Confirm password" type="password" name="password_confirmation" class="form-control mb-4" />
                <label class="form-label">Password confirmation <span style="color:red">*</span></label>
              </div>
              <button type="submit" class="btn btn-success">Update password</button>
            </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\xmrproject\resources\views/profil/settings.blade.php ENDPATH**/ ?>