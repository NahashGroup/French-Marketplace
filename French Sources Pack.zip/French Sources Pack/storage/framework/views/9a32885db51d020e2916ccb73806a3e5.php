

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-3">
        <?php echo $__env->make('layouts.menu.profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white">Paramètres</div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('profil.settings.update')); ?>" >
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-floating mb-4">
                  <textarea placeholder="Saisissez votre PGP" style="height:450px" name="pgp" class="form-control mb-4 <?php $__errorArgs = ['pgp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e($user->pgp); ?></textarea>
                  <label class="form-label">PGP <span style="color:red">*</span></label>
                  <?php $__errorArgs = ['pgp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-check form-switch mb-2">
                  <input <?php if($user->twofa == 1): ?> checked <?php endif; ?> class="form-check-input" type="checkbox" value="1" name="twofa" role="switch" id="flexSwitchCheckDefault">
                  <label class="form-check-label" for="flexSwitchCheckDefault">2FA</label>
                </div>
                <div class="alert alert-primary">Avec la connexion 2FA, vous devrez utiliser votre clé PGP pour déchiffrer le code qui sera caché dans le message signé</div>
                <button type="submit" class="btn btn-success">Mettre à jour les informations</button>
            </form>
            <hr>
            <form method="POST" action="<?php echo e(route('profil.settings.password.update')); ?>" >
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <div class="form-floating mb-4">
                <input placeholder="Mot de passe" type="password" name="password" class="form-control mb-4 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                <label class="form-label">Mot de passe <span style="color:red">*</span></label>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-floating mb-4">
                <input placeholder="Confirmer le mot de passe" type="password" name="password_confirmation" class="form-control mb-4" />
                <label class="form-label">Confirmer le mot de passe <span style="color:red">*</span></label>
              </div>
              <button type="submit" class="btn btn-success">Mettre à jour le mot de passe</button>
            </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/profil/settings.blade.php ENDPATH**/ ?>