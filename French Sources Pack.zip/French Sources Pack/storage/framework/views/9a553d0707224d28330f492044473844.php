

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-3">
        <?php echo $__env->make('layouts.menu.profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-lg-9">
      <div class="card">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Order : <?php echo e($order->token); ?></p></div>
        <div class="card-body">
            <div class="row">
              <div class="col-lg-6">
                <p class="mb-0"><strong>Customer</strong></p>
                <p class="mb-0">Name : <a target="__blank" href="<?php echo e(route('profil', $order->customer->name)); ?>" class="badge bg-success text-decoration-none"><?php echo e($order->customer->name); ?></a></p>
                <p class="mb-0">Created : <?php echo e(date('d-m-Y', strtotime($order->created_at))); ?></p>
                <p class="mb-0">Payment : <span class="badge bg-warning">Test mode</span></p>
              </div>
              <div class="col-lg-6">
                <p class="mb-0"><strong>Vendor</strong></p>
                <p class="mb-0">Name : 
                  <a target="__blank" href="<?php echo e(route('profil', $order->vendor->user->name)); ?>" class="badge bg-success text-decoration-none"><?php echo e($order->vendor->user->name); ?></a>
                  <a href="<?php echo e(route('profil.message.new', ['name' => $order->vendor->user->name])); ?>" class="badge bg-success"><i class="fa-solid fa-envelope"></i></a>
                  <a href="<?php echo e(route('profil.ticket.new', ['subject' => 'report'])); ?>" class="badge bg-danger"><i class="fa-solid fa-flag"></i></a>
                </p>
              </div>
            </div>
            <div class="mt-4">
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Picture</th>
                    <th scope="col">Name</th>
                    <th scope="col">Price in XMR</th>
                    <th scope="col">Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="align-middle"><img class="mb-2" src="<?php echo e(asset('storage/'.$order->product_picture)); ?>" height="70" /></td>
                    <td class="align-middle"><?php echo e($order->product_name); ?></td>
                    <td class="align-middle"><?php echo e($order->monero_price); ?> XMR</td>
                    <?php if($order->status == 0): ?>
                      <td class="align-middle"><span class="badge bg-primary">New order</span></td>
                    <?php else: ?>
                      <?php if($order->status == 1): ?>
                        <td class="align-middle"><span class="badge bg-success">Address send</span></td>
                        <?php else: ?>
                          <?php if($order->status == 2): ?>
                            <td class="align-middle"><span class="badge bg-success">Order send</span></td>
                          <?php else: ?>
                            <?php if($order->status == 3): ?>
                              <td class="align-middle"><span class="badge bg-success">Order compeleted</span></td>
                            <?php endif; ?>
                          <?php endif; ?>
                      <?php endif; ?>
                    <?php endif; ?>
                  </tr>
                </tbody>
              </table>
              <?php if($order->gps == 0): ?>
                <?php if(empty($order->address)): ?>
                <form method="POST" action="<?php echo e(route('order.test.address', $order->token)); ?>">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PUT'); ?>
                  <div class="form-floating mb-4">
                    <textarea style="height:280px" placeholder="Enter your delivery address" name="address" class="form-control mb-4"></textarea>
                    <label for="floatingInputGroup1">Address <span style="color:red">*</span></label>
                  </div>
                  <button type="submit" class="btn btn-success mb-4">Send address</button>
                  <div class="alert alert-primary">Your address will be encrypted with PGP key of vendor !</div>
                </form>
                <?php else: ?>
                  <div class="form-floating mb-4">
                    <textarea style="height:280px" placeholder="Enter your delivery address" name="address" class="form-control mb-4" disabled><?php echo e($order->address); ?></textarea>
                    <label for="floatingInputGroup1">Address <span style="color:red">*</span></label>
                  </div>
                <?php endif; ?>
              <?php else: ?>
                <?php if($order->status == 2): ?>
                  <div class="form-floating mb-4">
                    <textarea style="height:280px" placeholder="GPS info" name="info" class="form-control mb-4" disabled><?php echo e($gps->info); ?></textarea>
                    <label for="floatingInputGroup1">GPS Coordinate <span style="color:red">*</span></label>
                  </div>
                <?php else: ?>
                  <div class="alert alert-warning">You will receive instructions from the seller, with GPS coordinates of where your product is located, and additional information to help you find it.</div>
                <?php endif; ?>
              <?php endif; ?>
              <?php if($order->status == 2): ?>
                <form method="POST" action="<?php echo e(route('order.test.confirm', $order->token)); ?>">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PUT'); ?>
                  <button type="submit" class="btn btn-success mb-2 float-start">I have received order</div>
                </form>
              <?php endif; ?>
              <a href="<?php echo e(route('profil.ticket.new', ['subject' => 'order', 'title' => $order->token])); ?>" class="btn btn-danger float-end"><i class="fa-solid fa-flag"></i> Report order</a>
            </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\xmrproject\resources\views/profil/order/order-test.blade.php ENDPATH**/ ?>