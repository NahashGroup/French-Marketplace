

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-3">
        <?php echo $__env->make('layouts.menu.profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-lg-9">
      <div class="card">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Commandes</p></div>
        <div class="card-body">
          <form class="d-none d-md-inline-block form-inline w-100" method="GET">
            <div class="input-group">
                <input class="form-control" name="query" type="text" placeholder="Rechercher..." aria-label="Rechercher..." aria-describedby="btnNavbarSearch" />
                <button class="btn btn-success" id="btnNavbarSearch" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
            </div>
          </form>
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">#ID</th>
                    <th scope="col">Prix en XMR</th>
                    <th scope="col">Statut</th>
                    <th scope="col">&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                <?php if(request()->input('query')): ?>
                  <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="align-middle"><?php echo e($item->token); ?></td>
                    <td class="align-middle"><?php echo e($item->monero_price); ?> XMR</td>
                    <?php if($item->status == 0): ?>
                      <td class="align-middle"><span class="badge bg-primary">Nouvelle commande</span></td>
                    <?php else: ?>
                      <td class="align-middle"><span class="badge bg-success">Adresse envoyée</span></td>
                    <?php endif; ?>
                    <td class="align-middle"><a href="<?php echo e(route('order.test.show', $item->token)); ?>" class="btn btn-success">Voir</a></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php if($orders->isEmpty()): ?>
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">Aucun résultat</div></td>
                    </tr>
                  <?php endif; ?>
                <?php else: ?>
                  <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="align-middle"><?php echo e($item->token); ?></td>
                      <td class="align-middle"><?php echo e($item->monero_price); ?> XMR</td>
                      <?php if($item->status == 0): ?>
                        <td class="align-middle"><span class="badge bg-primary">Nouvelle commande</span></td>
                      <?php else: ?>
                        <?php if($item->status == 1): ?>
                        <td class="align-middle"><span class="badge bg-success">Adresse envoyée</span></td>
                        <?php else: ?>
                          <?php if($item->status == 2): ?>
                            <td class="align-middle"><span class="badge bg-success">Commande envoyée</span></td>
                          <?php else: ?>
                            <?php if($item->status == 3): ?>
                              <td class="align-middle"><span class="badge bg-success">Commande terminée</span></td>
                            <?php endif; ?>
                          <?php endif; ?>
                        <?php endif; ?>
                      <?php endif; ?>
                      <td class="align-middle"><a href="<?php echo e(route('order.test.show', $item->token)); ?>" class="btn btn-success">Voir</a></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php if($all->isEmpty()): ?>
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">Aucun résultat</div></td>
                    </tr>
                  <?php endif; ?>
                <?php endif; ?>
                </tbody>
              </table>
              <?php if(request()->input('query')): ?>
                <div><?php echo e($orders->links('pagination::simple-bootstrap-5')); ?></div>
              <?php else: ?>
                <div><?php echo e($all->links('pagination::simple-bootstrap-5')); ?></div>
              <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/profil/order/all-test.blade.php ENDPATH**/ ?>