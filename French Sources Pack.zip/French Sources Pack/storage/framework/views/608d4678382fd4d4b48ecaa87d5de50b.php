


<?php $__env->startSection('content-admin'); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <?php echo $__env->make('layouts.include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <h1 class="mt-4">Paramètres</h1>
                        <div class="card">
                            <div class="card-header bg-dark text-white">Paramètres</div>
                            <div class="card-body">
                                <form action="<?php echo e(route('admin.settings.update')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="input-group">
                                        <div class="form-floating me-4">
                                            <input type="number" value="<?php echo e($settings->commission); ?>" name="commission" class="form-control <?php $__errorArgs = ['commission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingInputGroup1" placeholder="Commission">
                                            <label for="floatingInputGroup1">Commission (en %) <span style="color:red">*</span></label>
                                            <?php $__errorArgs = ['commission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-floating">
                                            <input type="number" value="<?php echo e($settings->fee_vendor); ?>" name="fee_vendor" class="form-control <?php $__errorArgs = ['fee_vendor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingInputGroup1" placeholder="Frais Vendeur">
                                            <label for="floatingInputGroup1">Frais Vendeur <span style="color:red">*</span></label>
                                            <?php $__errorArgs = ['fee_vendor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>                               
                                    </div>
                                    <hr>
                                    <div class="input-group mb-4">
                                        <div class="form-check form-switch me-4">
                                            <input class="form-check-input" type="checkbox" name="active_test" value="1" role="switch" id="flexSwitchCheckDefault" <?php if($settings->active_test == 1): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Mode test</label>
                                        </div>
                                        <div class="form-check form-switch me-4">
                                            <input class="form-check-input" type="checkbox" name="lock_become_vendor" value="1" role="switch" id="flexSwitchCheckDefault" <?php if($settings->lock_become_vendor == 1): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="flexSwitchCheckDefault">Devenir vendeur</label>
                                        </div>
                                    </div>
                                    <div class="form-floating me-4">
                                        <textarea style="min-height:280px" name="information_index" class="form-control <?php $__errorArgs = ['information_index'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingInputGroup1"><?php echo e($settings->information_index); ?></textarea>
                                        <label for="floatingInputGroup1">Index des informations <span style="color:red">*</span></label>
                                        <?php $__errorArgs = ['information_index'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      </div>
                                      <div class="form-floating me-4 mt-4">
                                        <textarea style="min-height:280px" name="become_page" class="form-control <?php $__errorArgs = ['information_index'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingInputGroup1"><?php echo e($settings->become_page); ?></textarea>
                                        <label for="floatingInputGroup1">Page devenir vendeur<span style="color:red">*</span></label>
                                        <?php $__errorArgs = ['information_index'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      </div>
                                    <button type="submit" class="btn btn-success mt-4">Mettre à jour les paramètres</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/admin/settings.blade.php ENDPATH**/ ?>