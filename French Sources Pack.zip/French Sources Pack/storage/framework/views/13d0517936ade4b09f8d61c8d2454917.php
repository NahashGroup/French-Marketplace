

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-3">
        <?php echo $__env->make('layouts.menu.profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-lg-9">
      <div class="card">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Liste de souhaits</p></div>
        <div class="card-body">
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Titre</th>
                    <th scope="col">Prix</th>
                    <th scope="col">&nbsp;</th>
                    <th scope="col">&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="align-middle"><?php echo e($item->product->name); ?></td>
                    <td class="align-middle"><?php echo e($item->product->price); ?> EUR</td>
                    <td class="align-middle"><a href="<?php echo e(route('product', $item->product_token)); ?>" class="btn btn-success"><i class="fa-solid fa-eye"></i></a></td>
                    <td class="align-middle">
                        <form method="POST" action="<?php echo e(route('wishlist.remove', $item->token)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger"><i class="fa-solid fa-trash"></i></button>
                        </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php if($wishlists->isEmpty()): ?>
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">Aucun résultat</div></td>
                    </tr>
                  <?php endif; ?>
                </tbody>
            </table>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/profil/wishlist.blade.php ENDPATH**/ ?>