

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-3">
        <?php echo $__env->make('layouts.menu.profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-lg-9">
      <?php if(App\Models\Settings::test() == 0): ?>
      <div class="card">
        <div class="card-header bg-dark text-white">Portefeuille</div>
        <div class="card-body">
              <label>Montant du portefeuille</label>
              <?php if($balance['balance'] != 0): ?>
                <h3 class="mb-0"><i class="fa-solid fa-unlock text-success"></i> <?php echo e($monero->atomicToXMRminusFees($balance['unlocked_balance'])); ?></h3>
              <?php else: ?>
                <h3 class="mb-0"><i class="fa-solid fa-unlock text-success"></i> 0.000000000000</h3>
              <?php endif; ?>
              <?php if($balance['balance'] != 0): ?>
                <p><small> Total : <?php echo e($monero->atomicToXMRminusFees($balance['balance'])); ?></small></p>
              <?php else: ?>
                <p>Total : 0.000000000000</p>
              <?php endif; ?>
              <div class="form-floating mb-4">
                <input placeholder="Adresse Monero" value="<?php echo e($address['address']); ?>" type="text" class="form-control" id="floatingInputGroup1" disabled>
                <label for="floatingInputGroup1">Adresse XMR <span style="color:red">*</span></label>
              </div>
        </div>
      </div>

      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Retrait</div>
        <div class="card-body">
          <form method="POST" action="<?php echo e(route('profil.wallet.withdrawal')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-floating mb-4">
              <input placeholder="Montant en Monero" type="text" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="amount" id="floatingInputGroup1">
              <label for="floatingInputGroup1">Montant <span style="color:red">*</span></label>
              <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-floating mb-4">
              <input placeholder="Adresse Monero" type="text" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="address" id="floatingInputGroup1">
              <label for="floatingInputGroup1">Adresse de Destination <span style="color:red">*</span></label>
              <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn btn-success">Envoyer</button>
          </form>
        </div>
      </div>

      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Dernières transactions - Reçues</div>
        <div class="card-body">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Confirmations</th>
                <th scope="col">Frais</th>
                <th scope="col">Montant</th>
                <th scope="col">Bloqué</th>
              </tr>
            </thead>
            <tbody>
            <?php if(array_key_exists('in', $trans)): ?>
              <?php $__currentLoopData = $trans['in']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><a target="__blank" href="http://explorer.monerotech.info:6001/tx/<?php echo e($item['txid']); ?>/1"><?php echo e(Str::limit($item['txid'], 15)); ?></a></td>
                  <?php if(isset($item['confirmations'])): ?>
                  <td><?php echo e($item['confirmations']); ?></td>
                  <?php else: ?>
                  <td>Aucune confirmation</td>
                  <?php endif; ?>
                  <td><?php echo e(number_format($monero->atomicToXMR($item['fee']), 12)); ?></td>
                  <td><?php echo e(number_format($monero->atomicToXMR($item['amount']), 12)); ?></td>
                  <?php if($item['locked'] == true): ?>
                    <td><span class="badge bg-danger">Bloqué</span></td>
                  <?php else: ?>
                    <td><span class="badge bg-success">Débloqué</span></td>
                  <?php endif; ?>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <tr>
                <td colspan="5"><div class="alert alert-warning text-center">Aucune transaction reçue</div></td>
              </tr>
            <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Dernières transactions - Envoyées</div>
        <div class="card-body">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Confirmations</th>
                <th scope="col">Frais</th>
                <th scope="col">Montant</th>
                <th scope="col">Bloqué</th>
              </tr>
            </thead>
            <tbody>
            <?php if(array_key_exists('out', $trans)): ?>
              <?php $__currentLoopData = $trans['out']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><a target="__blank" href="http://explorer.monerotech.info:6001/tx/<?php echo e($item['txid']); ?>/1"><?php echo e(Str::limit($item['txid'], 15)); ?></a></td>
                  <?php if(isset($item['confirmations'])): ?>
                  <td><?php echo e($item['confirmations']); ?></td>
                  <?php else: ?>
                  <td>Aucune confirmation</td>
                  <?php endif; ?>
                  <td><?php echo e(number_format($monero->atomicToXMR($item['fee']), 12)); ?></td>
                  <td><?php echo e(number_format($monero->atomicToXMR($item['amount']), 12)); ?></td>
                  <?php if($item['locked'] == true): ?>
                    <td><span class="badge bg-danger">Bloqué</span></td>
                  <?php else: ?>
                    <td><span class="badge bg-success">Débloqué</span></td>
                  <?php endif; ?>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <tr>
                <td colspan="5"><div class="alert alert-warning text-center">Aucune transaction envoyée</div></td>
              </tr>
            <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>


      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Dernières transactions - En attentes</div>
        <div class="card-body">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Confirmations</th>
                <th scope="col">Frais</th>
                <th scope="col">Montant</th>
                <th scope="col">Bloqué</th>
              </tr>
            </thead>
            <tbody>
            <?php if(array_key_exists('pending', $trans)): ?>
              <?php $__currentLoopData = $trans['pending']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><a target="__blank" href="http://explorer.monerotech.info:6001/tx/<?php echo e($item['txid']); ?>/1"><?php echo e(Str::limit($item['txid'], 15)); ?></a></td>
                  <?php if(isset($item['confirmations'])): ?>
                  <td><?php echo e($item['confirmations']); ?></td>
                  <?php else: ?>
                  <td>Aucune confirmation</td>
                  <?php endif; ?>
                  <td><?php echo e(number_format($monero->atomicToXMR($item['fee']), 12)); ?></td>
                  <td><?php echo e(number_format($monero->atomicToXMR($item['amount']), 12)); ?></td>
                  <?php if($item['locked'] == true): ?>
                    <td><span class="badge bg-danger">Bloqué</span></td>
                  <?php else: ?>
                    <td><span class="badge bg-success">Débloqué</span></td>
                  <?php endif; ?>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <tr>
                <td colspan="5"><div class="alert alert-warning text-center">Aucune transaction en attente</div></td>
              </tr>
            <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php else: ?>
      <div class="card">
        <div class="card-header bg-dark text-white">Portefeuille</div>
        <div class="card-body">
          <div class="alert alert-warning">Le portefeuille ne fonctionne pas en mode test !</div>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/profil/wallet.blade.php ENDPATH**/ ?>