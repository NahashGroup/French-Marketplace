

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-3">
        <?php echo $__env->make('layouts.menu.profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Sales</p></div>
        <div class="card-body">
          <form class="d-none d-md-inline-block form-inline w-100" method="GET">
            <div class="input-group">
                <input class="form-control" value="<?php echo e(request()->input('query')); ?>" name="query" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                <button class="btn btn-success" id="btnNavbarSearch" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
            </div>
          </form>
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">#ID</th>
                    <th scope="col">Price in XMR</th>
                    <th scope="col">Status</th>
                    <th scope="col">&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                <?php if(request()->has('query')): ?>
                  <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="align-middle"><?php echo e($item->token); ?></td>
                    <td class="align-middle"><?php echo e($item->monero_price); ?> XMR</td>
                    <?php if($item->status == 0): ?>
                      <td class="align-middle"><span class="badge bg-primary">New order</span></td>
                    <?php else: ?>
                      <td class="align-middle"><span class="badge bg-success">Address send</span></td>
                    <?php endif; ?>
                    <td class="align-middle"><a href="<?php echo e(route('sale.test.show', $item->token)); ?>" class="btn btn-success">View</a></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php if($sales->isEmpty()): ?>
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">No result</div></td>
                    </tr>
                  <?php endif; ?>
                <?php else: ?>
                  <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="align-middle"><?php echo e($item->token); ?></td>
                      <td class="align-middle"><?php echo e($item->monero_price); ?> XMR</td>
                      <?php if($item->status == 0): ?>
                        <td class="align-middle"><span class="badge bg-primary">New order</span></td>
                      <?php else: ?>
                      <?php if($item->status == 1): ?>
                      <td class="align-middle"><span class="badge bg-success">Address send</span></td>
                      <?php else: ?>
                        <?php if($item->status == 2): ?>
                          <td class="align-middle"><span class="badge bg-success">Order send</span></td>
                        <?php else: ?>
                          <?php if($item->status == 3): ?>
                            <td class="align-middle"><span class="badge bg-success">Order completed</span></td>
                          <?php endif; ?>
                        <?php endif; ?>
                      <?php endif; ?>
                      <?php endif; ?>
                      <td class="align-middle"><a href="<?php echo e(route('sale.test.show', $item->token)); ?>" class="btn btn-success">View</a></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php if($all->isEmpty()): ?>
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">No result</div></td>
                    </tr>
                  <?php endif; ?>
                <?php endif; ?>
                </tbody>
              </table>
              <?php if(request()->has('query')): ?>
                <div><?php echo e($sales->links('pagination::simple-bootstrap-5')); ?></div>
              <?php else: ?>
                <div><?php echo e($all->links('pagination::simple-bootstrap-5')); ?></div>
              <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\xmrproject\resources\views/seller/sale/all-test.blade.php ENDPATH**/ ?>