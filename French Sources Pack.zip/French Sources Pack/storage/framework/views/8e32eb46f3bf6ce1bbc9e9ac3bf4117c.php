

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-3">
        <?php echo $__env->make('layouts.menu.profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-lg-9">
      <div class="card">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Avis</p></div>
        <div class="card-body">
        <?php if(App\Models\Settings::test() == 1): ?>
          <div class="alert alert-warning">Le système de notation est désactivé en mode test !</div>
        <?php else: ?>
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Titre</th>
                    <th scope="col">Prix</th>
                    <th scope="col">&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="align-middle"><?php echo e($item->product->name); ?></td>
                    <td class="align-middle"><?php echo e($item->product->price); ?></td>
                    <td class="align-middle"><a href="<?php echo e(route('profil.review.new', $item->token)); ?>" class="btn btn-success">Ajouter l'avis</a></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php if($reviews->isEmpty()): ?>
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">Aucun résultat</div></td>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>
        <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/profil/review/all.blade.php ENDPATH**/ ?>