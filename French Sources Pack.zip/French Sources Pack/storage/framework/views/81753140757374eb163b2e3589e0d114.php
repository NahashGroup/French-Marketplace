

<?php $__env->startSection('content'); ?>
  <div class="row">
    <?php echo $__env->make('layouts.menu.left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-lg-9">
      <div class="card mt-4">
        <div class="card-header bg-dark text-white">Filtre de recherche
        </div>
      </div>
      <div class="row">
        <?php echo $__env->make('layouts.include.productfilter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div><?php echo e($products->links('pagination::simple-bootstrap-5')); ?></div>
      </div>
      <div></div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/searchfilter.blade.php ENDPATH**/ ?>