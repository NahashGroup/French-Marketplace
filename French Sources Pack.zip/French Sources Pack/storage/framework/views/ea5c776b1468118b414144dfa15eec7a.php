<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="../assets/js/color-modes.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(env('APP_NAME')); ?> - XMR Marketplace Multi-vendor</title>
	  <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

  </head>
  <body> 
<nav class="navbar navbar-expand-md navbar-dark bg-dark mb-4">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?php echo e(route('index')); ?>"><?php echo e(env('APP_NAME')); ?></a>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="navbar-nav me-auto mb-2 mb-md-0">
        <li class="nav-item">
          <a class="nav-link active" href="<?php echo e(route('index')); ?>"><i class="fa-solid fa-house"></i> Index</a>
        </li>
        <li class="nav-item me-2">
          <a class="btn btn-success" href="<?php echo e(route('become.seller')); ?>"><i class="fa-solid fa-dollar"></i> Become vendor</a>
        </li>
        <li class="nav-item me-2">
          <a class="btn btn-success" href="<?php echo e(route('shop.all')); ?>"><i class="fa-solid fa-shop"></i> Shops</a>
        </li>
      </ul>
      <?php if(auth()->guard()->guest()): ?>
        <a href="<?php echo e(route('login')); ?>" class="d-flex btn btn-outline-success me-2">Login</a>
        <a href="<?php echo e(route('register')); ?>" class="d-flex btn btn-success me-4">Register</a>
      <?php endif; ?>
      <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->admin): ?>
          <a href="<?php echo e(route('admin.index')); ?>" class="btn btn-danger me-2"><i class="fa-solid fa-crown"></i></a>
        <?php endif; ?>
        <a href="<?php echo e(route('notification')); ?>" class="btn btn-success me-2"><i class="fa-solid fa-bell"></i> 
          <span class="badge <?php if(App\Models\Notification::unread() != 0): ?> bg-primary <?php else: ?> bg-dark <?php endif; ?>"><?php echo e(App\Models\Notification::unread()); ?></span>
        </a>
        <!--a href="" class="btn btn-success me-2"></a-->
        <li id="account" class="nav-item dropdown me-2">
            <a class="btn btn-success dropdown-toggle" href="<?php echo e(route('profil', Auth::user()->name)); ?>" role="button" data-bs-toggle="dropdown" aria-expanded="true"><?php echo e(Auth::user()->name); ?></a>
            <ul class="dropdown-menu-dark dropdown-menu" id="account-menu" aria-labelledby="navbarDropdown" data-bs-popper="static">
              <li><a class="dropdown-item" href="<?php echo e(route('profil.my.dashboard')); ?>">Dashboard</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('profil.edit.profil')); ?>">Picture & Description</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('profil.settings')); ?>">Settings</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('profil.wallet')); ?>">Wallet</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('profil.wishlist.all')); ?>">Wishlist</a></li>
              <?php if(App\Models\Settings::test() == 1): ?>
                <li><a class="dropdown-item" href="<?php echo e(route('order.test.all')); ?>">Orders <span class="badge bg-warning">Test mode</span></a></li>
              <?php else: ?>
                <li><a class="dropdown-item" href="<?php echo e(route('order.all')); ?>">Orders</a></li>
              <?php endif; ?>
              <li><a class="dropdown-item" href="<?php echo e(route('profil.review.all')); ?>">Reviews</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('profiL.message.all')); ?>">Messages</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('profil.ticket.all')); ?>">Support</a></li>
              <?php if(Auth::user()->vendor): ?>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="<?php echo e(route('vendor.dashboard')); ?>">Dashboard</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('vendor.settings')); ?>">Settings</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('product.all')); ?>">Products</a></li>
                <?php if(App\Models\Settings::test() == 1): ?>
                  <li><a class="dropdown-item" href="<?php echo e(route('sale.test.all')); ?>">Sales <span class="badge bg-warning">Test mode</span></a></li>
                <?php else: ?>
                  <li><a class="dropdown-item" href="<?php echo e(route('sale.all')); ?>">Sales</a></li>
                <?php endif; ?>
                <li><a class="dropdown-item" href="<?php echo e(route('product.stock.all')); ?>">Stocks</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('deliveries.all')); ?>">Delivery</a></li>
              <?php endif; ?>
            </ul>
          </li>
          <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger me-2"><i class="fa-solid fa-right-from-bracket"></i></button>
          </form>
      <?php endif; ?>
    </div>
  </div>
</nav>

<main class="container">
  <?php if(App\Models\Settings::test() == 1): ?>
    <div class="alert alert-warning mt-2">
      <i class="fa-solid fa-triangle-exclamation"></i> Test mode activated, no real payment will be possible ! Do not activate this feature, on a site in production ! 
    </div>
  <?php endif; ?>
  <?php if(session()->has('success')): ?>
    <div class="alert alert-success mt-2">
        <?php echo e(session()->get('success')); ?>

    </div>
  <?php endif; ?>
  <?php if(session()->has('error')): ?>
    <div class="alert alert-danger mt-2">
        <?php echo e(session()->get('error')); ?>

    </div>
  <?php endif; ?>

<?php echo $__env->yieldContent('content'); ?>

</main>
</body>
</html><?php /**PATH C:\laragon\www\xmrproject\resources\views/layouts/app.blade.php ENDPATH**/ ?>