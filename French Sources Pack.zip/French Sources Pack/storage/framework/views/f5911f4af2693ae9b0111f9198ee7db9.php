

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-3">
        <?php echo $__env->make('layouts.menu.profil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-lg-9">
      <div class="card mb-4">
        <div class="card-header bg-dark text-white"><p class="mb-0 float-start">Stocks</div>
        <div class="card-body">
          <form class="d-none d-md-inline-block form-inline w-100" method="GET">
            <div class="input-group">
                <input class="form-control" name="query" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                <button class="btn btn-success" id="btnNavbarSearch" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
            </div>
          </form>
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Picture</th>
                    <th scope="col">Name</th>
                    <th scope="col">Stock</th>
                    <th scope="col">&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                <?php if(request()->has('query')): ?>
                  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="align-middle"><img class="mb-2" src="<?php echo e(asset('storage/'.$item->picture)); ?>" height="70" /></td>
                      <td class="align-middle"><?php echo e($item->name); ?></td>
                      <td class="align-middle">
                          <form method="POST" action="<?php echo e(route('product.add.stock', $item->token)); ?>">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('PUT'); ?>
                              <div class="input-group">
                                  <input class="form-control" name="stock" type="number" value="<?php echo e($item->stock); ?>" />
                                  <button class="btn btn-success" type="submit"><i class="fa-solid fa-check"></i></button>
                              </div>
                          </form>
                      </td>
                      <td class="align-middle"><a href="<?php echo e(route('product.edit', $item->token)); ?>" class="btn btn-success">Edit</a> <a href="<?php echo e(route('product', $item->token)); ?>" class="btn btn-success">View</a></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php if($products->isEmpty()): ?>
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">No result</div></td>
                    </tr>
                  <?php endif; ?>
                <?php else: ?>
                  <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="align-middle"><img class="mb-2" src="<?php echo e(asset('storage/'.$item->picture)); ?>" height="70" /></td>
                      <td class="align-middle"><?php echo e($item->name); ?></td>
                      <td class="align-middle">
                          <form method="POST" action="<?php echo e(route('product.add.stock', $item->token)); ?>">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('PUT'); ?>
                              <div class="input-group">
                                  <input class="form-control" name="stock" type="number" value="<?php echo e($item->stock); ?>" />
                                  <button class="btn btn-success" type="submit"><i class="fa-solid fa-check"></i></button>
                              </div>
                          </form>
                      </td>
                      <td class="align-middle"><a href="<?php echo e(route('product.edit', $item->token)); ?>" class="btn btn-success">Edit</a> <a href="<?php echo e(route('product', $item->token)); ?>" class="btn btn-success">View</a></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php if($all->isEmpty()): ?>
                    <tr>
                      <td colspan="4"><div class="alert alert-warning text-center">No result</div></td>
                    </tr>
                  <?php endif; ?>
                <?php endif; ?>
                </tbody>
              </table>
              <?php if(request()->has('query')): ?>
                <div><?php echo e($products->links('pagination::simple-bootstrap-5')); ?></div>
              <?php else: ?>
                <div><?php echo e($all->links('pagination::simple-bootstrap-5')); ?></div>
              <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\xmrproject\resources\views/seller/stock/all.blade.php ENDPATH**/ ?>