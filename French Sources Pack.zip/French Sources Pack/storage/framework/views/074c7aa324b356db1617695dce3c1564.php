


<?php $__env->startSection('content-admin'); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <?php echo $__env->make('layouts.include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <h1 class="mt-4">Orders</h1>
                        <div class="card">
                            <div class="card-header bg-dark text-white">Orders</div>
                            <div class="card-body">
                                <form class="d-none d-md-inline-block form-inline w-100" method="GET">
                                    <div class="input-group">
                                        <input class="form-control" value="<?php echo e(request()->input('query')); ?>" name="query" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                                        <button class="btn btn-success" id="btnNavbarSearch" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </div>
                                </form>
                                <table class="table">
                                    <thead>
                                      <tr>
                                        <th scope="col">#ID</th>
                                        <th scope="col">Price in XMR</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">&nbsp;</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(request()->has('query')): ?>
                                      <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                        <td class="align-middle"><?php echo e($item->token); ?></td>
                                        <td class="align-middle"><?php echo e($item->monero_price); ?> XMR</td>
                                        <?php if($item->status == 0): ?>
                                          <td class="align-middle"><span class="badge bg-primary">New order</span></td>
                                        <?php else: ?>
                                          <td class="align-middle"><span class="badge bg-success">Address send</span></td>
                                        <?php endif; ?>
                                        <td class="align-middle"><a href="<?php echo e(route('admin.order.test', $item->token)); ?>" class="btn btn-success">View</a></td>
                                      </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                      <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                          <td class="align-middle"><?php echo e($item->token); ?></td>
                                          <td class="align-middle"><?php echo e($item->monero_price); ?> XMR</td>
                                          <?php if($item->status == 0): ?>
                                            <td class="align-middle"><span class="badge bg-primary">New order</span></td>
                                          <?php else: ?>
                                            <td class="align-middle"><span class="badge bg-success">Address send</span></td>
                                          <?php endif; ?>
                                          <td class="align-middle"><a href="<?php echo e(route('admin.order.test', $item->token)); ?>" class="btn btn-success">View</a></td>
                                        </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    </tbody>
                                  </table>
                            </div>
                        </div>
                        <?php if(request()->has('query')): ?>
                          <div><?php echo e($orders->links('pagination::simple-bootstrap-5')); ?></div>
                        <?php else: ?>
                          <div><?php echo e($all->links('pagination::simple-bootstrap-5')); ?></div>
                        <?php endif; ?>
                    </div>
                </main>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\xmrproject\resources\views/admin/market/orders/all-test.blade.php ENDPATH**/ ?>