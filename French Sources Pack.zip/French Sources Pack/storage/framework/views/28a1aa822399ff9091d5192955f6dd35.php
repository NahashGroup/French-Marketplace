


<?php $__env->startSection('content-admin'); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <?php echo $__env->make('layouts.include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <h1 class="mt-4">Produits</h1>
                        <div class="card">
                            <div class="card-header bg-dark text-white">Produits</div>
                            <div class="card-body">
                                <form class="d-none d-md-inline-block form-inline w-100" method="GET">
                                    <div class="input-group">
                                        <input class="form-control" value="<?php echo e(request()->input('query')); ?>" value="" name="query" type="text" placeholder="Rechercher..." aria-label="Rechercher..." aria-describedby="btnNavbarSearch" />
                                        <button class="btn btn-success" id="btnNavbarSearch" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </div>
                                </form>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Photo</th>
                                            <th>Titre</th>
                                            <th>Prix</th>
                                            <th>Stock</th>
                                            <th>Expédition à</th>
                                            <th>&nbsp;</th>
                                            <th>&nbsp;</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(request()->has('query')): ?>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><img src="<?php echo e(asset('storage/'.$item->picture)); ?>" height="50" /></td>
                                                <td><?php echo e($item->name); ?></td>
                                                <td><?php echo e($item->price); ?></td>
                                                <td><?php echo e($item->stock); ?></td>
                                                <td><?php echo e($item->delivery->country->nicename); ?></td>
                                                <td><a target="__blank" class="btn btn-success" href="<?php echo e(route('product', $item->token)); ?>">Voir</a></td>
                                                <td><a class="btn btn-warning" href="#">Verrouiller</a></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><img src="<?php echo e(asset('storage/'.$item->picture)); ?>" height="50" /></td>
                                                <td><?php echo e($item->name); ?></td>
                                                <td><?php echo e($item->price); ?></td>
                                                <td><?php echo e($item->stock); ?></td>
                                                <td><?php echo e($item->delivery->country->nicename); ?></td>
                                                <td><a target="__blank" class="btn btn-success" href="<?php echo e(route('product', $item->token)); ?>">Voir</a></td>
                                                <td>
                                                <?php if($item->locked == 0): ?>
                                                    <form method="POST" action="<?php echo e(route('admin.product.locked', $item->token)); ?>" >
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?>
                                                        <button type="submit" class="btn btn-warning"><i class="fa-solid fa-lock"></i></button>
                                                    </form>
                                                <?php else: ?>
                                                    <form method="POST" action="<?php echo e(route('admin.product.unlocked', $item->token)); ?>" >
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?>
                                                        <button type="submit" class="btn btn-warning"><i class="fa-solid fa-unlock"></i></button>
                                                    </form>
                                                <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    </tbody>
                                </table>
                                <?php if(request()->has('query')): ?>
                                    <div><?php echo e($products->links('pagination::simple-bootstrap-5')); ?></div>
                                <?php else: ?>
                                    <div><?php echo e($all->links('pagination::simple-bootstrap-5')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/admin/market/products.blade.php ENDPATH**/ ?>