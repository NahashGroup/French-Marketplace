


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card mt-4">
        <div class="card-header bg-dark text-white">2FA - Confirmez votre clé PGP</div>
        <div class="card-body">
            <div class="form-group">
                <div class="form-floating mb-4">
                    <textarea style="min-height:300px" placeholder="Déchiffrez ce message" name="decrypt_message" id="decrypt_message" class="form-control" rows="10" style="resize: none;"  readonly><?php echo e(session()->get('message')); ?></textarea>
                    <label for="floatingInputGroup1">Déchiffrez ce message <span style="color:red">*</span></label>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>                
                <div class="alert alert-primary">Déchiffrez ce message et obtenez le numéro de validation.</div>
            </div>
            <form method="POST" action="<?php echo e(route('verif.pgp')); ?>">
                <?php echo csrf_field(); ?>
                    <div class="form-floating mb-4">
                        <input placeholder="Numéro de validation" type="number" value="<?php echo e(old('validation_number')); ?>" class="form-control <?php $__errorArgs = ['validation_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required name="validation_number" id="validation_number"/>
                        <label for="floatingInputGroup1">Numéro de validation <span style="color:red">*</span></label>
                        <?php $__errorArgs = ['validation_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mr-2 mb-2"><?php echo captcha_img(); ?></div>
                    <div class="form-floating mb-4">
                        <input type="text" class="form-control <?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required name="captcha" placeholder="Captcha ici">
                        <label for="floatingInputGroup1">Captcha <span style="color:red">*</span></label>
                        <?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <button class="btn btn-dark">Confirmer le 2FA</button>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.start', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/pgp2fa.blade.php ENDPATH**/ ?>