


<?php $__env->startSection('content-admin'); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <?php echo $__env->make('layouts.include.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <h1 class="mt-4">Support</h1>
                        <div class="card">
                            <div class="card-header bg-dark text-white"><p class="mb-0 float-start">ID : <?php echo e($ticket->token); ?></p></div>
                            <div class="card-body">
                                <div class="card div-messenger mb-4">
                                    <div class="card-body">
                                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="d-flex text-white mb-2">
                                                    <div class="flex-shrink-0 me-2">
                                                            <a target="__blank" href="<?php echo e(route('profil', $item->user->name)); ?>">
                                                                <?php if($item->user->picture == "default-avatar.png"): ?>
                                                                    <img class="rounded-circle" height="50" src="<?php echo e(asset('img/default-avatar.png')); ?>" alt="...">
                                                                <?php else: ?>
                                                                    <img class="rounded-circle" height="50" src="<?php echo e(asset('storage/'.$item->user->picture)); ?>" alt="...">
                                                                <?php endif; ?>
                                                            </a>
                                                    </div>
                                                    <div class="p-3 w-100 <?php if($item->user_id == Auth::user()->id): ?> <?php if($item->admin): ?> bg-danger div-message-admin <?php else: ?> bg-success div-message-me <?php endif; ?> <?php else: ?> div-message-not-me bg-dark <?php endif; ?>">
                                                        <div class="ms-3">
                                                            <div class="">
                                                                <a target="__blank" class="text-decoration-none text-white" href="<?php echo e(route('profil', $item->user->name)); ?>"><p class="mb-2"><?php echo e($item->user->name); ?></p></a>
                                                            </div>
                                                            <p style="clear:both" class="mb-0"><?php echo e($item->message); ?></p>
                                                        </div>
                                                        <div class="float-end">
                                                            <span class="badge <?php if($item->user_id == Auth::user()->id): ?> bg-dark <?php else: ?> <?php if($item->admin): ?> bg-dark <?php else: ?> bg-success <?php endif; ?> <?php endif; ?>"><small><?php echo e(\Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?></small></span>
                                                        </div>
                                                    </div>
                                                </div>              
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <?php if($ticket->status == 0): ?>
                                    <form method="POST" action="<?php echo e(route('admin.support.send', $ticket->token)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-floating mb-4">
                                            <textarea placeholder="Saisissez votre message" style="height:100px" name="message" class="form-control mb-4 <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                                            <label class="form-label">Message <span style="color:red">*</span></label>
                                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <button type="submit" class="btn btn-success float-start">Envoyer</button>
                                    </form>
                                    <form method="POST" class="float-end" action="<?php echo e(route('admin.support.status', $ticket->token)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <button type="submit" class="btn btn-danger">Résolu</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/admin/support/ticket.blade.php ENDPATH**/ ?>