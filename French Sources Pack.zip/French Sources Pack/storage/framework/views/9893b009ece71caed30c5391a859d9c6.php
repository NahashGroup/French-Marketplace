<?php if(session()->has('success')): ?>
<div class="alert alert-success mt-2">
    <?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <div class="alert alert-danger mt-2">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/layouts/include/alert.blade.php ENDPATH**/ ?>