<div class="col-lg-3">
    <div class="card mt-4">
        <div class="card-header bg-dark text-white">Categories</div>
        <ul class="list-group">
          <?php $__currentLoopData = App\Models\Market\Category::allCategorie(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!empty($item['children'])): ?>
              <a href="<?php echo e(route('category', $item['token'])); ?>" class="list-group-item mt-0"><i class="fas fa-caret-down"></i> <?php echo e($item['name']); ?> </a>
              <?php $__currentLoopData = $item['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('category', $children['token'])); ?>" class="list-group-item mt-0">&nbsp; &nbsp; &nbsp; <i class="fas fa-caret-right"></i> <?php echo e($children['name']); ?></a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <a href="<?php echo e(route('category', $item['token'])); ?>" class="list-group-item mt-0"><i class="fas fa-caret-right"></i> <?php echo e($item['name']); ?></a>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <div class="card mt-4 mb-4">
      <div class="card-header bg-dark text-white">Search filter</div>
      <div class="card-body">
        <form method="GET" action="<?php echo e(route('search.filter.get')); ?>">

          <div class="form-floating mb-4 me-2">
            <input placeholder="Search..." value="<?php echo e(request()->input('query')); ?>" name="query" type="text" value="" class="form-control" id="floatingInputGroup1" >
            <label for="floatingInputGroup1">Search <span style="color:red">*</span></label>
          </div>

          <div class="form-floating mt-2">
            <select name="vendor" class="form-select">
              <option value="all" selected>All</option>
              <?php $__currentLoopData = App\Models\Market\Vendor::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php if(request()->input('vendor') == $item->user->name): ?> selected <?php endif; ?> value="<?php echo e($item->user->name); ?>"><?php echo e($item->user->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="floatingInputGroup1">Vendor <span style="color:red">*</span></label>
            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="mt-4">
            <label class="mb-2">Price</label>
            <div class="input-group">
              <div class="form-floating mb-4 me-2">
                <input type="text" <?php if(request()->input('pmin')): ?> value="<?php echo e(request()->input('pmin')); ?>"  <?php else: ?> value="0" <?php endif; ?> name="pmin" class="form-control" id="floatingInputGroup1" >
                <label for="floatingInputGroup1">Min</label>
              </div>
              <div class="form-floating mb-4">
                <input type="text" <?php if(request()->input('pmax')): ?> value="<?php echo e(request()->input('pmax')); ?>"  <?php else: ?> value="500000" <?php endif; ?> name="pmax" class="form-control" id="floatingInputGroup1" >
                <label for="floatingInputGroup1">Max</label>
              </div>
            </div>
          </div>
          <div class="form-floating mt-4">
            <select class="form-control mb-4 <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cat">
              <option value="all" selected>All</option>
                <?php $__currentLoopData = App\Models\Market\Category::allCategorie(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!empty($item['children'])): ?>
                    <option <?php if(request()->input('cat') == $item['token'] ): ?> selected <?php endif; ?> value="<?php echo e($item['token']); ?>" ><?php echo e($item['name']); ?> </option>
                        <?php $__currentLoopData = $item['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(request()->input('cat') == $children['token'] ): ?> selected <?php endif; ?> value="<?php echo e($children['token']); ?>" >-- <?php echo e($children['name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <option <?php if(request()->input('cat') == $item['token'] ): ?> selected <?php endif; ?> value="<?php echo e($item['token']); ?>" ><?php echo e($item['name']); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="floatingInputGroup1">Category <span style="color:red">*</span></label>
            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-floating mt-4 mb-4">
            <select class="form-select" name="sto">
              <option value="all">World</option>
              <?php $__currentLoopData = App\Models\Country::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php if(request()->input('sto') == $item->id ): ?> selected <?php endif; ?> value="<?php echo e($item->id); ?>"><?php echo e($item->nicename); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="floatingInputGroup1">Shipping to <span style="color:red">*</span></label>
            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="d-grid gap-2">
            <button type="submit" class="btn btn-success">Search</button>
          </div>
        </form>
      </div>
    </div>
  </div><?php /**PATH C:\laragon\www\xmrproject\resources\views/layouts/menu/left.blade.php ENDPATH**/ ?>