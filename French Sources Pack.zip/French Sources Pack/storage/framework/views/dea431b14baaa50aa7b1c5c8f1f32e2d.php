

<?php $__env->startSection('content'); ?>
  <div class="row">
    <?php echo $__env->make('layouts.menu.left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-lg-9">
      <div class="card mt-4">
        <div class="card-header bg-dark text-white"><?php if($product->category->parent_id == 0): ?> <?php echo e($product->category->name); ?> > <?php else: ?> <?php echo e($product->category->parent->name); ?> > <?php echo e($product->category->name); ?> > <?php endif; ?> <?php echo e($product->name); ?></div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-4">
                    <div class="slider">
                      <span id="slide-1"></span>
                      <span id="slide-2"></span>
                      <span id="slide-3"></span>
                      <span id="slide-4"></span>
                      <div class="image-container">
                        <div class="image-div"><img class="img-supp picture slide" src="<?php echo e(asset('storage/'.$product->picture)); ?>" height="300" /></div>
                      <?php if($product->picsupp1 != ''): ?>
                        <div class="image-div"><img class="img-supp img-supp1 slide" src="<?php echo e(asset('storage/'.$product->picsupp1)); ?>" height="300" /></div>
                      <?php endif; ?>
                      <?php if($product->picsupp2 != ''): ?>
                        <div class="image-div"><img class="img-supp img-supp2 slide" src="<?php echo e(asset('storage/'.$product->picsupp2)); ?>" height="300" /></div>
                      <?php endif; ?>
                      <?php if($product->picsupp3 != ''): ?>
                        <div class="image-div"><img class="img-supp img-supp3 slide" src="<?php echo e(asset('storage/'.$product->picsupp3)); ?>" height="300" /></div>
                      <?php endif; ?>
                      </div>
                      <div class="buttons">
                        <a href="#slide-1"></a>
                        <?php if($product->picsupp1 != ''): ?>
                          <a href="#slide-2"></a>
                        <?php endif; ?>
                        <?php if($product->picsupp2 != ''): ?>
                          <a href="#slide-3"></a>
                        <?php endif; ?>
                        <?php if($product->picsupp3 != ''): ?>                    
                          <a href="#slide-4"></a>
                        <?php endif; ?>
                      </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <h3 class="mb-4"><?php echo e($product->name); ?></h3>
                    <div class="float-start">
                        <h4>Infos</h4>
                        <hr>
                        <p class="mb-0"><strong>- Vendeur :</strong> <a href="<?php echo e(route('profil', $product->vendor->user->name)); ?>" class="badge bg-success text-decoration-none"><?php echo e($product->vendor->user->name); ?></a></p>
                        <p class="mb-0"><strong>- Stock :</strong>
                          <?php if($product->stock != 0): ?>
                            <span class="badge bg-success">En stock</span>
                          <?php else: ?>
                            <span class="badge bg-danger">En rupture de stock</span>
                          <?php endif; ?>
                        </p>
                        <p class="mb-0"><strong>- Vendu :</strong> <?php echo e($cOrder); ?></p>
                        <p class="mb-0"><strong>- Expédition :</strong> <?php echo e($product->delivery->country->nicename); ?></p>
                        <p class="mb-0"><strong>- Délai :</strong> <?php echo e($product->delivery->delay); ?> jours</p>
                        <?php if($product->delivery->gps == 1): ?>
                          <p class="mb-0"><strong>- Coordonnées GPS : <span class="badge bg-success">Actif</span></strong> </p>
                        <?php else: ?>
                          <p class="mb-0"><strong>- Coordonnées GPS : <span class="badge bg-primary">Inactif</span></strong> </p>
                        <?php endif; ?>
                        <?php if(Auth::user()->id != $product->vendor_id): ?>
                          <?php if(!$wishlist): ?>
                            <form method="POST" action="<?php echo e(route('product.wishlist.add', $product->token)); ?>">                        
                              <?php echo csrf_field(); ?>
                              <button class="btn btn-success mt-3" ><i class="fa-solid fa-plus"></i> Ajouter à la liste de souhaits</button>
                            </form>
                          <?php else: ?>
                            <form method="POST" action="<?php echo e(route('wishlist.remove', $wishlist->token)); ?>">                        
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>
                              <button class="btn btn-danger mt-3" ><i class="fa-solid fa-minus"></i> Supprimer de la liste de souhaits</button>
                            </form>
                          <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="float-end product-card-right">
                        <h3 class="mb-0"><?php echo e($product->price); ?> EUR</h3>
                        <?php if($product->vendor->vacation == 0): ?>
                            <?php if($product->stock): ?>
                              <?php if(App\Models\Settings::test() == 0): ?>
                                  <?php if(Auth::user()->id != $product->vendor_id): ?>
                                    <form method="POST" action="<?php echo e(route('order.prod.new', $product->token)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-success w-100">Acheter</button>
                                    </form>
                                  <?php endif; ?>
                                <?php else: ?>
                                  <?php if(Auth::user()->id != $product->vendor_id): ?>
                                    <form method="POST" action="<?php echo e(route('order.test.new', $product->token)); ?>">
                                      <?php echo csrf_field(); ?>
                                      <button type="submit" class="btn btn-success w-100">Acheter</button>
                                      <span class="badge bg-warning w-100">Mode test</span>
                                    </form>
                                  <?php endif; ?>
                              <?php endif; ?>
                            <?php else: ?>
                              <div class="alert alert-danger">En rupture de stock</div>
                            <?php endif; ?>
                        <?php else: ?>
                          <div class="alert alert-danger">Le vendeur est en vacances</div>
                        <?php endif; ?>
                        <p class="mt-4 mb-0">Qualité :</p>
                          <div class="progress" role="progressbar" aria-label="Example with label" aria-valuenow="<?php echo e($product->qualityReviewSum($product->token)); ?>" aria-valuemin="0" aria-valuemax="100">
                            <div class="progress-bar" style="width: <?php echo e($product->qualityReviewSum($product->token)); ?>%"><?php echo e($product->qualityReviewSum($product->token)); ?>%</div>
                          </div>
                        <p class="mb-0">Communication :</p>
                          <div class="progress mb-0" role="progressbar" aria-label="Example with label" aria-valuenow="<?php echo e($product->commuReviewSum($product->token)); ?>" aria-valuemin="0" aria-valuemax="100">
                            <div class="progress-bar" style="width: <?php echo e($product->commuReviewSum($product->token)); ?>%"><?php echo e($product->commuReviewSum($product->token)); ?>%</div>
                          </div>
                        <p class="mb-0">Livraison :</p>
                          <div class="progress" role="progressbar" aria-label="Example with label" aria-valuenow="<?php echo e($product->deliReviewSum($product->token)); ?>" aria-valuemin="0" aria-valuemax="100">
                            <div class="progress-bar" style="width: <?php echo e($product->deliReviewSum($product->token)); ?>%"><?php echo e($product->deliReviewSum($product->token)); ?>%</div>
                          </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <div class="card mt-2">
        <div class="card-header bg-dark text-white">Description</div>
        <div class="card-body"><p class="desc-product"><?php echo e($product->description); ?></p></div>
      </div>

      <div class="card mt-2 mb-4">
        <div class="card-header bg-dark text-white">Avis</div>
        <div class="card-body">
          <?php if($reviews->isEmpty()): ?>
          <div class="alert alert-warning">Aucun avis sous ce produit.</div>
        <?php else: ?>
          <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="review-card">
                  <p class="mb-0"><strong><?php echo preg_replace("/(?!^).(?!$)/", "*", $item->user->name) ?></strong> - <span class="fs-4"><?php echo e($item->numberTotalReview($item->token)); ?></span>/5 - <i><?php echo e(\Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?></i></p>
                  <div class="w-25">
                    <div class="progress mb-0" role="progressbar" aria-label="Example with label" aria-valuenow="<?php echo e($item->purcentTotalReview($item->token)); ?>" aria-valuemin="0" aria-valuemax="100">
                      <div class="progress-bar" style="width: <?php echo e($item->purcentTotalReview($item->token)); ?>%"><?php echo e($item->purcentTotalReview($item->token)); ?>%</div>
                    </div>
                  </div>
              <p class="float-none"><?php echo e($item->message); ?></p>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <div><?php echo e($reviews->links('pagination::simple-bootstrap-5')); ?></div>
        <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/nouvellevaguemarket/resources/views/product.blade.php ENDPATH**/ ?>