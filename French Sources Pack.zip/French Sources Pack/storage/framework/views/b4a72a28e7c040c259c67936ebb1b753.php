<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="../assets/js/color-modes.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(env('APP_NAME')); ?></title>
	  <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

  </head>
  <body> 
<nav class="navbar navbar-expand-md navbar-dark bg-dark mb-4">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?php echo e(route('index')); ?>"><?php echo e(env('APP_NAME')); ?></a>
    <div class="collapse navbar-collapse" id="navbarCollapse">

    </div>
  </div>
</nav>

<main class="container">
  <?php if(App\Models\Settings::test() == 1): ?>
    <div class="alert alert-warning mt-2">
      <i class="fa-solid fa-triangle-exclamation"></i> Mode test activé, aucun paiement réel ne sera possible ! N'activez pas cette fonctionnalité sur un site en production ! 
    </div>
  <?php endif; ?>
  <?php if(session()->has('success')): ?>
    <div class="alert alert-success mt-2">
        <?php echo e(session()->get('success')); ?>

    </div>
  <?php endif; ?>
  <?php if(session()->has('error')): ?>
    <div class="alert alert-danger mt-2">
        <?php echo e(session()->get('error')); ?>

    </div>
  <?php endif; ?>

<?php echo $__env->yieldContent('content'); ?>

</main>
</body>
</html><?php /**PATH /var/www/nouvellevaguemarket/resources/views/layouts/start.blade.php ENDPATH**/ ?>