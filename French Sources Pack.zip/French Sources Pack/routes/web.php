<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/confirm/2fa', function(){return view('pgp2fa');})->name('confirm.pgp');
Route::post('/confirm/2fa/verif', [App\Http\Controllers\Auth\PGPController::class, 'verif'])->name('verif.pgp');

Route::group( ['middleware' => 'auth'], function() {

    Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('index');

    Route::get('/search/filter', [App\Http\Controllers\SearchController::class, 'searchFilter'])->name('search.filter.get');
    Route::get('/shop/all', [App\Http\Controllers\Market\SellerController::class, 'vendorAll'])->name('shop.all');

    //

    Route::get('/profil/{name}', [App\Http\Controllers\UserController::class, 'user'])->name('profil');
    Route::get('/shop/{name}',  [App\Http\Controllers\UserController::class, 'shop'])->name('shop');
    Route::get('/category/{token}', [App\Http\Controllers\Market\CategoryController::class, 'catProduct'])->name('category');
    Route::get('/product/{token}', [App\Http\Controllers\Market\ProductController::class, 'show'])->name('product');

    Route::group( ['middleware' => 'become'], function() {

        Route::get('/become/seller', [App\Http\Controllers\Market\SellerController::class, 'becomeForm'])->name('become.seller');
        Route::post('/become/new/seller', [App\Http\Controllers\Market\SellerController::class, 'becomeSeller'])->name('become.new.seller');

    });

    Route::group( ['middleware' => 'test'], function() {

        Route::post('/order/test/new/{token}', [App\Http\Controllers\Market\OrderController::class, 'orderTestMode'])->name('order.test.new');
        Route::get('/orders/test/all', [App\Http\Controllers\Market\OrderController::class, 'allOrderTestMode'])->name('order.test.all');
        Route::get('/order/test/{token}', [App\Http\Controllers\Market\OrderController::class, 'showOrderTestMode'])->name('order.test.show');
        Route::put('/order/test/add/address/{token}', [App\Http\Controllers\Market\OrderController::class, 'sendAddressTest'])->name('order.test.address');
        Route::put('/order/test/confirm/{token}', [App\Http\Controllers\Market\OrderController::class, 'receivedProductTest'])->name('order.test.confirm');
    });

    Route::post('/order/new/{token}', [App\Http\Controllers\Market\OrderController::class, 'orderProdMode'])->name('order.prod.new');
    Route::get('/orders/all', [App\Http\Controllers\Market\OrderController::class, 'allOrderProdMode'])->name('order.all');
    Route::get('/order/{token}', [App\Http\Controllers\Market\OrderController::class, 'showOrderProdMode'])->name('order.show');
    Route::put('/order/add/address/{token}', [App\Http\Controllers\Market\OrderController::class, 'sendAddressProd'])->name('order.address');
    Route::put('/order/confirm/{token}', [App\Http\Controllers\Market\OrderController::class, 'receivedProductProd'])->name('order.confirm');

    Route::get('/profil/settings/edit', [App\Http\Controllers\UserController::class, 'settingsForm'])->name('profil.settings');
    Route::put('/profil/settings/update', [App\Http\Controllers\UserController::class, 'settings'])->name('profil.settings.update');
    Route::put('/profil/settings/password/update', [App\Http\Controllers\UserController::class, 'updatePassword'])->name('profil.settings.password.update');

    Route::get('/profil/wallet/xmr', [App\Http\Controllers\Market\WalletController::class, 'index'])->name('profil.wallet');
    Route::post('/profil/wallet/withdrawal', [App\Http\Controllers\Market\WalletController::class, 'withdrawal'])->name('profil.wallet.withdrawal');

    Route::put('/profil/pic/add', [App\Http\Controllers\UserController::class, 'updatePic'])->name('profil.pic.add');
    Route::put('/profil/desc/update', [App\Http\Controllers\UserController::class, 'updateDesc'])->name('profil.desc.update');

    Route::get('/profil/all/message', [App\Http\Controllers\MessageController::class, 'all'])->name('profiL.message.all');
    Route::get('/profil/new/message', function(){ return view('profil.message.new'); })->name('profil.message.new');
    Route::post('/profil/start/message', [App\Http\Controllers\MessageController::class, 'start'])->name('profil.message.start');
    Route::get('/profil/message/{token}', [App\Http\Controllers\MessageController::class, 'show'])->name('profil.message.show');
    Route::post('/profil/send/message/{token}', [App\Http\Controllers\MessageController::class, 'add'])->name('profil.message.send');

    Route::get('/profil/my/dashboard/', [App\Http\Controllers\UserController::class, 'dashboard'])->name('profil.my.dashboard');
    Route::get('/profil/edit/profil', [App\Http\Controllers\UserController::class, 'editPage'])->name('profil.edit.profil');

    Route::get('/profil/new/ticket', function(){ return view('profil.ticket.new'); })->name('profil.ticket.new');
    Route::get('/profil/all/ticket', [App\Http\Controllers\Market\TicketController::class, 'all'])->name('profil.ticket.all');
    Route::post('/profil/add/ticket', [App\Http\Controllers\Market\TicketController::class, 'sendTicket'])->name('profil.ticket.add');
    Route::get('/profil/ticket/{token}', [App\Http\Controllers\Market\TicketController::class, 'show'])->name('profil.ticket.show');
    Route::post('/profil/ticket/send/{token}', [App\Http\Controllers\Market\TicketController::class, 'send'])->name('profil.ticket.send');

    Route::get('/notification', [App\Http\Controllers\NotificationController::class, 'unread'])->name('notification');
    Route::put('/notification/message/{token}', [App\Http\Controllers\NotificationController::class, 'readMessage'])->name('notification.message');

    Route::get('/profil/review/all', [App\Http\Controllers\Market\ReviewController::class, 'all'])->name('profil.review.all');
    Route::get('/profil/review/new/{token}', [App\Http\Controllers\Market\ReviewController::class, 'new'])->name('profil.review.new');
    Route::put('/profil/review/add/{token}', [App\Http\Controllers\Market\ReviewController::class, 'add'])->name('profil.review.add');

    Route::get('/profil/wishlist/all', [App\Http\Controllers\Market\WishlistController::class, 'wishlistAll'])->name('profil.wishlist.all');

    Route::post('/product/wishlist/add/{token}', [App\Http\Controllers\Market\WishlistController::class, 'add'])->name('product.wishlist.add');
    Route::delete('/wishlist/remove/{token}', [App\Http\Controllers\Market\WishlistController::class, 'remove'])->name('wishlist.remove');

    Route::group( ['middleware' => 'vendor'], function() {

        Route::group( ['middleware' => 'test'], function() {

            Route::get('/sales/test/all', [App\Http\Controllers\Market\SalesController::class, 'allSalesTestMode'])->name('sale.test.all');
            Route::get('/sale/test/{token}', [App\Http\Controllers\Market\SalesController::class, 'showSaleTestMode'])->name('sale.test.show');
            Route::post('/sale/test/order/send/gps/{token}', [App\Http\Controllers\Market\SalesController::class, 'orderSendTestModeGPS'])->name('sale.test.gps.send');
            //Route::put('/sale/test/canceled/{token}', [App\Http\Controllers\Market\SalesController::class, 'canceledOrderTestMode'])->name('sale.test.canceled');
            Route::put('/sale/test/order/send/{token}', [App\Http\Controllers\Market\SalesController::class, 'orderSendTestMode'])->name('sale.test.order.send');

        });

        Route::get('/sales/all', [App\Http\Controllers\Market\SalesController::class, 'allSalesProdMode'])->name('sale.all');
        Route::get('/sale/{token}', [App\Http\Controllers\Market\SalesController::class, 'showSaleProdMode'])->name('sale.show');
        //Route::put('/sale/canceled/{token}', [App\Http\Controllers\Market\SalesController::class, 'canceledOrderProdMode'])->name('sale.canceled');
        Route::put('/sale/order/send/{token}', [App\Http\Controllers\Market\SalesController::class, 'orderSendProdMode'])->name('sale.order.send');
        Route::post('/sale/order/send/gps/{token}', [App\Http\Controllers\Market\SalesController::class, 'orderSendProdModeGPS'])->name('sale.gps.send');

        Route::get('/vendor/dashboard', [App\Http\Controllers\Market\SellerController::class, 'dashboardSeller'])->name('vendor.dashboard');
        Route::get('/vendor/settings', [App\Http\Controllers\Market\SellerController::class, 'settingsForm'])->name('vendor.settings');
        Route::put('/vendor/settings/update', [App\Http\Controllers\Market\SellerController::class, 'settings'])->name('vendor.settings.update');

        Route::get('/vendor/product/new', function(){return view('seller.product.newproduct');})->name('product.new');
        Route::post('/vendor/product/action/new', [App\Http\Controllers\Market\ProductController::class, 'new'])->name('product.action.new');
        Route::get('/vendor/product/edit/{token}', [App\Http\Controllers\Market\ProductController::class, 'edit'])->name('product.edit');
        Route::get('/vendor/product/all', [App\Http\Controllers\Market\ProductController::class, 'index'])->name('product.all');
        Route::put('/vendor/product/action/update/{token}', [App\Http\Controllers\Market\ProductController::class, 'update'])->name('product.action.update');

        Route::put('/vendor/add/stock/product/{token}', [App\Http\Controllers\Market\ProductController::class, 'addStock'])->name('product.add.stock');
        Route::get('/vendor/stock/all', [App\Http\Controllers\Market\ProductController::class, 'stocks'])->name('product.stock.all');

        Route::get('/vendor/delivery/new', function(){ return view('seller.delivery.newdelivery'); })->name('delivery.new');
        Route::post('/vendor/delivery/add', [App\Http\Controllers\Market\DeliveryController::class, 'add'])->name('delivery.add');
        Route::get('/vendor/delivery/all', [App\Http\Controllers\Market\DeliveryController::class, 'all'])->name('deliveries.all');
        Route::get('/vendor/delivery/edit/{token}', [App\Http\Controllers\Market\DeliveryController::class, 'formEdit'])->name('delivery.edit');
        Route::put('/vendor/delivery/update/{token}', [App\Http\Controllers\Market\DeliveryController::class, 'edit'])->name('delivery.update');

    });

    Route::group( ['middleware' => 'admin'], function() {

        Route::group( ['middleware' => 'test'], function() {

            Route::get('/mastermind/orders/test/all', [App\Http\Controllers\Market\Admin\OrderController::class, 'allOrdersTest'])->name('admin.orders.test');
            Route::get('/mastermind/order/test/{token}', [App\Http\Controllers\Market\Admin\OrderController::class, 'showorderTest'])->name('admin.order.test');

        });

        // Route admin order
        Route::get('/mastermind/orders/all', [App\Http\Controllers\Market\Admin\OrderController::class, 'allOrdersProd'])->name('admin.orders');
        Route::get('/mastermind/order/{token}', [App\Http\Controllers\Market\Admin\OrderController::class, 'showorderProd'])->name('admin.order');

        // Route admin global
        Route::get('/mastermind', [App\Http\Controllers\Market\Admin\DashboardController::class, 'dashboard'])->name('admin.index');

        Route::get('/mastermind/product/all', [App\Http\Controllers\Market\Admin\ProductController::class, 'all'])->name('admin.product.all');
        Route::put('/mastermind/product/locked/{token}', [App\Http\Controllers\Market\Admin\ProductController::class, 'locked'])->name('admin.product.locked');
        Route::put('/mastermind/product/unlocked/{token}', [App\Http\Controllers\Market\Admin\ProductController::class, 'unlocked'])->name('admin.product.unlocked');

        Route::get('/mastermind/customer/all', [App\Http\Controllers\Market\Admin\UserController::class, 'customer'])->name('admin.customer.all');

        Route::put('/mastermind/user/ban/{name}', [App\Http\Controllers\Market\Admin\UserController::class, 'ban'])->name('admin.user.ban');
        Route::put('/mastermind/user/unban/{name}', [App\Http\Controllers\Market\Admin\UserController::class, 'unban'])->name('admin.user.unban');
        Route::get('/mastermind/user/all/banned', [App\Http\Controllers\Market\Admin\UserController::class, 'banned'])->name('admin.user.banned');

        Route::get('/mastermind/vendor/all', [App\Http\Controllers\Market\Admin\UserController::class, 'vendor'])->name('admin.vendor.all');
        Route::get('/mastermind/settings', [App\Http\Controllers\Market\Admin\SettingsController::class, 'settingsForm'])->name('admin.settings');
        Route::put('/mastermind/settings/update', [App\Http\Controllers\Market\Admin\SettingsController::class, 'settingsUpdate'])->name('admin.settings.update');

        // Route admin category
        Route::get('/mastermind/categories', [App\Http\Controllers\Market\Admin\CategoryController::class, 'all'])->name('admin.categories');
        Route::get('/mastermind/category/{id}', [App\Http\Controllers\Market\Admin\CategoryController::class, 'subCatAll'])->name('admin.category.sub');
        Route::get('/mastermind/new/category', function(){ return view('admin.category.new'); })->name('admin.category.new');
        Route::post('/mastermind/add/category', [App\Http\Controllers\Market\Admin\CategoryController::class, 'add'])->name('admin.category.add');
        Route::get('/mastermind/edit/category/{id}', [App\Http\Controllers\Market\Admin\CategoryController::class, 'editForm'])->name('admin.category.edit');
        Route::put('/mastermind/update/category/{id}', [App\Http\Controllers\Market\Admin\CategoryController::class, 'update'])->name('admin.category.update');
        Route::delete('/mastermind/category/delete/{id}', [App\Http\Controllers\Market\Admin\CategoryController::class, 'delete'])->name('admin.category.delete');

        Route::get('/mastermind/support/all', [App\Http\Controllers\Market\Admin\TicketController::class, 'all'])->name('admin.support.all');
        Route::get('/mastermind/support/ticket/{token}', [App\Http\Controllers\Market\Admin\TicketController::class, 'show'])->name('admin.support.show');
        Route::post('/mastermind/support/ticket/send/{token}', [App\Http\Controllers\Market\Admin\TicketController::class, 'send'])->name('admin.support.send');
        Route::put('/mastermind/support/ticket/status/{token}', [App\Http\Controllers\Market\Admin\TicketController::class, 'resolve'])->name('admin.support.status');

        //Route::get('/mastermind/payment/all', function(){ return view('admin.payment.all'); })->name('admin.payment.all');
        //Route::get('/mastermind/payment/monero', function(){ return view('admin.payment.monero'); })->name('admin.payment.monero');

    });

});


Auth::routes();

