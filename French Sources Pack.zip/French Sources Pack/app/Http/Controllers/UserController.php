<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\User;
use App\Models\Market\Product;
use App\Models\Market\Order;
use App\Models\Market\Ticket;
use App\Models\Market\Wishlist;
use App\Models\Settings;


use Auth;
use Hash;

class UserController extends Controller
{

    public function dashboard()
    {

        if (Settings::test() == 1) {

            $cOrder = Order::where('user_id', Auth::user()->id)->where('test', '1')->count();
            $orders = Order::where('user_id', Auth::user()->id)->where('test', '1')->orderBy('id', 'DESC')->paginate(6);

        } else {

            $cOrder = Order::where('user_id', Auth::user()->id)->where('test', '0')->count();
            $orders = Order::where('user_id', Auth::user()->id)->where('test', '0')->orderBy('id', 'DESC')->paginate(6);

        }

        $tickets = Ticket::where('user_id', Auth::user()->id)->orderBy('id', 'DESC')->paginate(6);
        $wishlists = Wishlist::where('user_id', Auth::user()->id)->orderBy('id', 'DESC')->paginate(6);

        $cWishlist = Wishlist::where('user_id', Auth::user()->id)->count();
        $cTicket = Ticket::where('user_id', Auth::user()->id)->count();

        return view('profil.dashboard')->with(compact('cOrder', 'cWishlist', 'cTicket', 'orders', 'tickets', 'wishlists'));

    }

    public function user($name)
    {

        $user = User::where('name', $name)->firstOrFail();

        return view('profil.profil')->with(compact('user'));

    }

    public function editPage()
    {

        $user = User::where('id', Auth::user()->id)->firstOrFail();

        return view('profil.edit')->with(compact('user'));

    }

    public function settingsForm()
    {

        $user = User::where('id', Auth::user()->id)->firstOrFail();

        return view('profil.settings')->with(compact('user'));

    }

    public function settings(Request $request)
    {

        $user = User::where('id', Auth::user()->id)->firstOrFail();

        $request->validate([
            'pgp' => 'required|min:2|max:5000|string',
            'twofa' => 'nullable|integer|between:0,1',
        ]);

        if ($request->input('pgp') != '') {

            if (preg_match('/^-----BEGIN PGP PUBLIC KEY BLOCK-----.*?-----END PGP PUBLIC KEY BLOCK-----$/s', $request->input('pgp'))) {

                $data = [
                    'pgp' => $request->input('pgp'),
                    'twofa' => $request->input('twofa'),
                ];

            } else {
                return redirect()->back()->with('error', 'Invalid public PGP key !');
            }

        } else {

            return redirect()->back()->with('error', 'You need PGP key with 2FA system !');

        }

        User::where('id', Auth::user()->id)->update($data);

        return redirect(route('profil.settings'))->with('success', 'Settings updated with success !');

    }

    public function updatePassword(Request $request)
    {

        $request->validate([
            'password' => 'required|min:6|max:65|string|confirmed',
        ]);

        $data = [
            'password' => Hash::make($request->input('password')),
        ];

        User::where('id', Auth::user()->id)->update($data);

        return redirect(route('profil.settings'))->with('success', 'Password updated with success !');

    }

    public function updatePic(Request $request)
    {

        $request->validate([
            'picture' => 'required|file|mimes:png,jpg|dimensions:width=225,height=225|max:4096',
        ]);

        if (request('picture')) {
            User::whereId(Auth::user()->id)->update([
                'picture' => request('picture')->store('users', 'public'),
            ]);

            return redirect(route('profil.edit.profil'))->with('success', 'Picture added with success !');
        }

    }

    public function updateDesc(Request $request)
    {

        $request->validate([
            'description' => 'required|string|min:20|max:3000',
        ]);

        $data = [
            'description' => $request->input('description'),
        ];

        user::where('id', Auth::user()->id)->update($data);

        return redirect(route('profil.edit.profil'))->with('success', 'Description updated with success !');

    }

    public function shop($name)
    {

        $verif = User::where('name', $name)->firstOrFail();

        if ($verif->vendor) {

            $user = User::where('name', $name)->firstOrFail();
            $products = Product::where('vendor_id', $user->id)->paginate(15);

            return view('shop')->with(compact('user', 'products'));

        } else {

            return redirect(route('become.seller'))->with('success', 'You must be a seller to have a "shop" !');

        }

    }
}
