<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Market\Product;
use App\Models\User;
use App\Models\Market\Delivery;

use Auth;

class SearchController extends Controller
{

    public function searchFilter(Request $request)
    {

        $request->validate([
            'query' => 'nullable|string|max:120',
            'pmin' => 'nullable|numeric',
            'pmax' => 'nullable|numeric',
            'vendor' => 'nullable|string',
            'cat' => 'nullable|string',
            'sto' => 'nullable|string',
        ]);

        $products = Product::where('locked', '0')->orderBy('id', 'DESC');

        if ($request->has('query') and $request->input('query') != NULL) {

            $query = request()->input('query');

            $products->where('name', 'like', "%$query%")->orWhere('description', 'like', "%$query%");
        }

        if ($request->has('pmin')) {

            $pmin = request()->input('pmin');

            $products->where('price', '>=', $pmin);

        }

        if ($request->has('pmax')) {

            $pmax = request()->input('pmax');

            $products->where('price', '<=', $pmax);
        }

        if ($request->has('vendor') and $request->input('vendor') != "all") {

            $vendor = request()->input('vendor');

            $user = User::where('name', $vendor)->firstOrFail();

            $products->where('vendor_id', $user->id);

        }

        if ($request->has('cat') and $request->input('cat') != "all") {

            $cat = request()->input('cat');

            $products->where('category_token', $cat);

        }

        if ($request->has('sto') and $request->input('sto') != "all") {

            $sto = request()->input('sto');

            $delivery = Delivery::where('country_id', $sto)->firstOrFail();

            $products->where('delivery_token', $delivery->token);

        }

        $products = $products->paginate(10);

        return view('searchfilter')->with(compact('products'));


    }
}
