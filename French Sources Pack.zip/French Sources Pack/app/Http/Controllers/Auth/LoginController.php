<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

use Auth;
use OpenPGP;
use OpenPGP_Crypt_RSA;
use OpenPGP_Crypt_Symmetric;
use OpenPGP_LiteralDataPacket;
use OpenPGP_Message;
use OpenPGP_SecretKeyPacket;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    use AuthenticatesUsers;


    public function login(Request $request)
    {
        $input = $request->all();

        $this->validate($request, [
            'name' => 'required|string|between:3,25',
            'password' => 'required|string|between:6,65',
            'captcha' => 'required|captcha',
        ]);

        $fieldType = filter_var($request->username, FILTER_VALIDATE_EMAIL) ? 'email' : 'name';

        if (auth()->attempt(array($fieldType => $input['name'], 'password' => $input['password']))) {
            if (Auth::user()->twofa == 1) {

                $newUsersPGP = Auth::user()->pgp;
                $validationNumber = rand(100000000000, 999999999999);
                $decryptedMessage = "Vous avez bien déchiffré le texte.\nPour valider votre connexion, veuillez réécrire le numéro de validation ci-dessous dans le champ en question sur le site.\nNuméro de validation : " . $validationNumber;

                $pubkey = $newUsersPGP;
                $key = OpenPGP_Message::parse(
                    OpenPGP::unarmor($pubkey, 'PGP PUBLIC KEY BLOCK')
                );

                $data = new OpenPGP_LiteralDataPacket($decryptedMessage, ['format' => 'u']);
                $encrypted = OpenPGP_Crypt_Symmetric::encrypt(
                    $key,
                    new OpenPGP_Message(array($data))
                );
                $armored = OpenPGP::enarmor($encrypted->to_bytes(), 'PGP MESSAGE');

                session()->put('validation', $validationNumber);
                session()->put('PGP', $newUsersPGP);
                session()->put('message', $armored);
                session()->put('block', '1');

                session()->put('name', $request->input('name'));
                session()->put('password', $request->input('password'));

                auth()->logout();

                return redirect()->route('confirm.pgp');

            } else {
                return redirect()->route('index');
            }

        } else {
            return redirect()->route('login')
                ->with('error', 'Username And Password Are Wrong. Try again!');
        }

    }

}
