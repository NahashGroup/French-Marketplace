<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Auth;

class PGPController extends Controller
{
    public function verif(Request $request)
    {
        $request->validate([
            'validation_number' => 'required|integer|digits:12',
            'captcha' => 'required|captcha',
        ]);

        if ($request->input('validation_number') == session()->get('validation')) {

            $fieldType = filter_var(session()->get('name'), FILTER_VALIDATE_EMAIL) ? 'email' : 'name';

            if (auth()->attempt(array($fieldType => session()->get('name'), 'password' => session()->get('password')))) {

                session()->forget('validation');
                session()->forget('PGP');
                session()->forget('message');
                session()->forget('block');
                session()->forget('name');
                session()->forget('password');

                return redirect(route('index'));

            }

        } else {
            return redirect(route('confirm.pgp'))->with('error', 'Not valid number ! Try again !');
        }
    }
}
