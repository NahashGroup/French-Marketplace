<?php

namespace App\Http\Controllers\Market;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Market\Category;
use App\Models\Market\Product;
use DB;

class CategoryController extends Controller
{

    public function catProduct($token){

        $category = Category::where('token', $token)->firstOrFail();
        $products = Product::where('category_token', $token)->where('locked','0')->paginate(12);

        return view('category')->with(compact('category','products'));

    }

}
