<?php

namespace App\Http\Controllers\Market;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Auth;

use App\Models\Market\Order;
use App\Models\Market\GpsCoordinate;
use App\Models\Market\Monero;
use App\Models\Market\Product;
use App\Models\Market\Vendor;
use App\Models\Market\Review;
use App\Models\User;
use App\Models\Notification;
use App\Models\Settings;
use App\Models\Admin;

use OpenPGP;
use OpenPGP_Crypt_RSA;
use OpenPGP_Crypt_Symmetric;
use OpenPGP_LiteralDataPacket;
use OpenPGP_Message;
use OpenPGP_SecretKeyPacket;

class OrderController extends Controller
{

    /* TEST MODE */

    public function orderTestMode($token)
    {

        $product = Product::where('token', $token)->where('locked', '0')->first();
        $vendor = Vendor::where('user_id', $product->vendor_id)->where('vacation', '0')->first();
        $vendor_pgp = User::where('id', $product->vendor_id)->where('pgp', '!=', '')->first();

        if ($product) {

            if ($vendor) {

                if ($vendor_pgp) {

                    if ($product->stock > 0) {

                        if (Auth::user()->pgp != '' || $product->delivery->gps == 0) {

                            if (Auth::user()->id != $product->vendor_id) {

                                $crypt = openssl_random_pseudo_bytes(20);
                                $order_token = 'order_test_' . bin2hex($crypt);

                                $settings = Settings::first();

                                $amount_admin = $product->price * $settings->commission / 100;
                                $amount_seller = $product->price - $amount_admin;

                                $order = new Order();

                                $order->product_picture = $product->picture;
                                $order->product_name = $product->name;
                                $order->product_price = $amount_seller;
                                $order->monero_price = Product::priceXMR($product->token);
                                $order->product_token = $product->token;
                                $order->vendor_id = $product->vendor_id;
                                $order->user_id = Auth::user()->id;
                                $order->address = '';
                                $order->status = 0;
                                $order->delivery_id = $product->delivery->id;
                                $order->token = $order_token;
                                $order->test = 1;
                                $order->gps = $product->delivery->gps;

                                $notification = new Notification();
                                $notification->order_token = $order_token;
                                $notification->from_id = Auth::user()->id;
                                $notification->user_id = $product->vendor_id;
                                $notification->read = '0';

                                $notification->save();
                                $order->save();

                                $stock = $product->stock - 1;

                                $data = [
                                    'stock' => $stock,
                                ];

                                Product::where('token', $token)->update($data);

                                return redirect(route('order.test.all'))->with('success', 'Order test passed successfully !');

                            } else {

                                return redirect(route('product', $token))->with('error', 'You cant buy your own product !');

                            }

                        } else {

                            return redirect()->back()->with('error', 'You need a PGP Key for buy!');

                        }

                    } else {

                        return redirect(route('product', $token))->with('error', 'Out of stock for this product !');

                    }

                } else {

                    return redirect(route('product', $token))->with('error', 'The vendor does not have a PGP key.');

                }


            } else {

                return redirect(route('product', $token))->with('error', 'Vendor in vacation !');

            }


        } else {

            return redirect(route('product', $token))->with('error', 'Product locked !');

        }
    }

    public function sendAddressTest(Request $request, $token)
    {

        $request->validate([
            'address' => 'required|min:8|max:5000|string',
        ]);

        $order = Order::where('token', $token)->where('user_id', Auth::user()->id)->firstOrFail();

        $pubkey = $order->vendor->user->pgp;
        $key = OpenPGP_Message::parse(
            OpenPGP::unarmor($pubkey, 'PGP PUBLIC KEY BLOCK')
        );

        $address = $request->input('address');

        if (strpos($address, "-----BEGIN PGP MESSAGE-----") === false) {
            $data = new OpenPGP_LiteralDataPacket($address, ['format' => 'u']);
            $encrypted = OpenPGP_Crypt_Symmetric::encrypt(
                $key,
                new OpenPGP_Message(array($data))
            );
            $armored = OpenPGP::enarmor($encrypted->to_bytes(), 'PGP MESSAGE');
        } else {
            $armored = $address;
        }



        $data = [
            'address' => $armored,
            'status' => 1,
        ];

        Order::where('token', $token)->where('user_id', Auth::user()->id)->update($data);

        return redirect(route('order.test.show', $token))->with('success', 'Address added with success !');

    }

    public function allOrderTestMode()
    {

        if (request()->has('query')) {

            request()->validate([
                'query' => 'required|min:3|max:255|string',
            ]);

            $query = request()->input('query');

            $orders = Order::where('user_id', Auth::user()->id)->where('test', 1)->where('token', 'like', "%$query%")->orderBy('id', 'DESC')->paginate(20);

            return view('profil.order.all-test')->with(compact('orders'));

        } else {

            $all = Order::where('user_id', Auth::user()->id)->where('test', 1)->orderBy('id', 'DESC')->paginate(12);

            return view('profil.order.all-test')->with(compact('all'));
        }

    }

    public function receivedProductTest($token)
    {

        $order = Order::where('token', $token)->where('user_id', Auth::user()->id)->where('test', 1)->firstOrFail();

        $data = [
            'status' => 3,
        ];

        $crypt = openssl_random_pseudo_bytes(15);
        $review_token = 'review_' . bin2hex($crypt);

        $review = new Review();
        $review->user_id = $order->user_id;
        $review->product_token = $order->product->token;
        $review->order_token = $order->token;
        $review->status = 0;
        $review->token = $review_token;

        $review->save();

        Order::where('token', $token)->where('user_id', Auth::user()->id)->update($data);

        return redirect(route('order.test.show', $token))->with('success', 'Order test is now completed !');

    }

    public function showOrderTestMode($token)
    {

        $order = Order::where('token', $token)->where('user_id', Auth::user()->id)->where('test', 1)->firstOrFail();

        if ($order->gps == 1) {

            if ($order->status == 2) {

                $gps = GpsCoordinate::where('order_token', $order->token)->first();

                return view('profil.order.order-test')->with(compact('order', 'gps'));

            } else {

                return view('profil.order.order-test')->with(compact('order'));

            }

        } else {

            return view('profil.order.order-test')->with(compact('order'));

        }

    }

    /* END TEST MODE */


    /* _____________________________________________________________________ */


    /* PRODUCTION MODE */

    public function orderProdMode($token)
    {

        $product = Product::where('token', $token)->where('locked', '0')->first();
        $vendor = Vendor::where('user_id', $product->vendor_id)->where('vacation', '0')->first();
        $vendor_pgp = User::where('id', $product->vendor_id)->where('pgp', '!=', '')->first();


        if ($product) {

            if ($vendor) {

                if ($vendor_pgp) {

                    if ($product->stock > 0) {


                        if (Auth::user()->pgp != '' || $product->delivery->gps == 0) {

                            if (Auth::user()->id != $product->vendor_id) {

                                $crypt = openssl_random_pseudo_bytes(20);
                                $order_token = 'order_' . bin2hex($crypt);

                                $settings = Settings::first();

                                $amount_admin = $product->price * $settings->commission / 100;
                                $amount_seller = $product->price - $amount_admin;

                                $x_seller = Settings::eurToXMR($amount_seller);
                                $x_admin = Settings::eurToXMR($amount_admin);

                                $order = new Order();

                                $order->product_picture = $product->picture;
                                $order->product_name = $product->name;
                                $order->product_price = $amount_seller;
                                $order->monero_price = $x_seller;
                                $order->product_token = $product->token;
                                $order->vendor_id = $product->vendor_id;
                                $order->user_id = Auth::user()->id;
                                $order->address = '';
                                $order->status = 0;
                                $order->delivery_id = $product->delivery->id;
                                $order->token = $order_token;
                                $order->test = 0;
                                $order->gps = $product->delivery->gps;

                                $notification = new Notification();
                                $notification->order_token = $order_token;
                                $notification->from_id = Auth::user()->id;
                                $notification->user_id = $product->vendor_id;
                                $notification->read = '0';


                                $stock = $product->stock - 1;

                                $data = [
                                    'stock' => $stock,
                                ];

                                $w_customer = User::where('id', Auth::user()->id)->firstOrFail();
                                $w_seller = User::where('id', $product->vendor_id)->firstOrFail();
                                $w_admin = Admin::where('role', 1)->firstOrFail();

                                $m = new Monero();
                                $t = $m->walletRPC();

                                $a_seller = $t->get_address($w_seller->monero_index);
                                $a_admin = $t->get_address($w_admin->user->monero_index);
                                $i_customer = $t->get_balance($w_customer->monero_index);

                                if ($m->atomicToXMR($i_customer['unlocked_balance']) > Product::priceXMR($product->token)) {

                                    $transfer = $t->transfer(['destinations' => [['address' => $a_seller['address'], 'amount' => $x_seller], ['address' => $a_admin['address'], 'amount' => $x_admin]], 'account_index' => $w_customer->monero_index, 'priority' => 1]);

                                    $order->save();
                                    $notification->save();
                                    Product::where('token', $token)->update($data);

                                    return redirect(route('profil.my.dashboard'))->with('success', 'Order of ' . Product::priceXMR($product->token) . ' XMR passed successfully !');

                                } else {

                                    return redirect(route('product', $token))->with('error', 'You have not enough monero unlocked !');

                                }

                            } else {

                                return redirect(route('product', $token))->with('error', 'You cant buy your own product !');

                            }

                        } else {

                            return redirect()->back()->with('error', 'You need a PGP Key for buy!');

                        }

                    } else {

                        return redirect(route('product', $token))->with('error', 'Out of stock for this product !');

                    }

                } else {

                    return redirect(route('product', $token))->with('error', 'The vendor does not have a PGP key.');

                }

            } else {

                return redirect(route('product', $token))->with('error', 'Vendor in vacation !');

            }

        } else {

            return redirect(route('product', $token))->with('error', 'Product locked !');

        }
    }


    public function sendAddressProd(Request $request, $token)
    {

        $request->validate([
            'address' => 'required|min:8|max:5000|string',
        ]);

        $order = Order::where('token', $token)->where('user_id', Auth::user()->id)->firstOrFail();

        $pubkey = $order->vendor->user->pgp;
        $key = OpenPGP_Message::parse(
            OpenPGP::unarmor($pubkey, 'PGP PUBLIC KEY BLOCK')
        );

        $address = $request->input('address');

        if (strpos($address, "-----BEGIN PGP MESSAGE-----") === false) {
            $data = new OpenPGP_LiteralDataPacket($address, ['format' => 'u']);
            $encrypted = OpenPGP_Crypt_Symmetric::encrypt(
                $key,
                new OpenPGP_Message(array($data))
            );
            $armored = OpenPGP::enarmor($encrypted->to_bytes(), 'PGP MESSAGE');
        } else {
            $armored = $address;
        }



        $data = [
            'address' => $armored,
            'status' => 1,
        ];

        Order::where('token', $token)->where('user_id', Auth::user()->id)->update($data);

        return redirect(route('order.show', $token))->with('success', 'Address added with success ! Order status updated !');

    }

    public function receivedProductProd($token)
    {

        $order = Order::where('token', $token)->where('user_id', Auth::user()->id)->where('test', 0)->firstOrFail();

        $data = [
            'status' => 3,
        ];

        $crypt = openssl_random_pseudo_bytes(15);
        $review_token = 'review_' . bin2hex($crypt);

        $review = new Review();
        $review->user_id = $order->user_id;
        $review->product_token = $order->product->token;
        $review->order_token = $order->token;
        $review->status = 0;
        $review->token = $review_token;

        $review->save();

        Order::where('token', $token)->where('user_id', Auth::user()->id)->update($data);

        return redirect(route('order.show', $token))->with('success', 'Order is now completed !');

    }

    public function allOrderProdMode()
    {

        if (request()->has('query')) {

            request()->validate([
                'query' => 'required|min:3|max:255|string',
            ]);

            $query = request()->input('query');

            $orders = Order::where('user_id', Auth::user()->id)->where('test', 0)->where('token', 'like', "%$query%")->orderBy('id', 'DESC')->paginate(20);

            return view('profil.order.all')->with(compact('orders'));

        } else {

            $all = Order::where('user_id', Auth::user()->id)->where('test', 0)->orderBy('id', 'DESC')->paginate(12);

            return view('profil.order.all')->with(compact('all'));
        }

    }

    public function showOrderProdMode($token)
    {

        $order = Order::where('token', $token)->where('user_id', Auth::user()->id)->where('test', '0')->firstOrFail();

        if ($order->gps == 1) {

            if ($order->status == 2) {

                $gps = GpsCoordinate::where('order_token', $order->token)->first();

                return view('profil.order.order')->with(compact('order', 'gps'));

            } else {

                return view('profil.order.order')->with(compact('order'));

            }

        } else {

            return view('profil.order.order')->with(compact('order'));

        }

    }

    /* END PRODUCTION MODE */
}
