<?php

namespace App\Http\Controllers\Market;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Auth;

use App\Models\Market\Vendor;
use App\Models\Market\Order;
use App\Models\Market\Review;
use App\Models\Market\GpsCoordinate;

use OpenPGP;
use OpenPGP_Crypt_RSA;
use OpenPGP_Crypt_Symmetric;
use OpenPGP_LiteralDataPacket;
use OpenPGP_Message;
use OpenPGP_SecretKeyPacket;

class SalesController extends Controller
{

    /* TEST MODE */

    public function allSalesTestMode()
    {

        if (request()->has('query')) {

            request()->validate([
                'query' => 'required|min:3|max:255|string',
            ]);

            $query = request()->input('query');

            $sales = Order::where('vendor_id', Auth::user()->id)->where('test', 1)->where('token', 'like', "%$query%")->orderBy('id', 'DESC')->paginate(15);

            return view('seller.sale.all-test')->with(compact('sales'));

        } else {

            $all = Order::where('vendor_id', Auth::user()->id)->where('test', 1)->orderBy('id', 'DESC')->paginate(15);

            return view('seller.sale.all-test')->with(compact('all'));
        }
    }

    public function showSaleTestMode($token)
    {

        $sale = Order::where('token', $token)->where('vendor_id', Auth::user()->id)->where('test', 1)->firstOrFail();

        if ($sale->gps == 1) {

            if ($sale->status == 2) {

                $gps = GpsCoordinate::where('order_token', $sale->token)->first();

                return view('seller.sale.sale-test')->with(compact('sale', 'gps'));

            } else {

                return view('seller.sale.sale-test')->with(compact('sale'));

            }

        } else {

            return view('seller.sale.sale-test')->with(compact('sale'));

        }
    }

    public function canceledOrderTestMode($token)
    {

        $order = Order::where('vendor_id', Auth::user()->id)->where('token', $token)->where('test', 1)->firstOrFail();

        $data = [
            'status' => '4',
        ];

        Order::where('vendor_id', Auth::user()->id)->where('token', $order->token)->where('test', 1)->update($data);

        return redirect()->back()->with('success', 'Order test status updated !');
    }

    public function orderSendTestMode($token)
    {

        $order = Order::where('vendor_id', Auth::user()->id)->where('token', $token)->where('test', 1)->firstOrFail();

        $data = [
            'status' => '2',
        ];

        Order::where('vendor_id', Auth::user()->id)->where('token', $order->token)->update($data);

        return redirect()->back()->with('success', 'Order test status updated !');

    }

    public function orderSendTestModeGPS(Request $request, $token)
    {

        $order = Order::where('vendor_id', Auth::user()->id)->where('token', $token)->where('test', 1)->firstOrFail();

        if ($order->gps == 1) {

            $request->validate([
                'lat' => 'required|string|min:8|max:255',
                'lon' => 'required|string|min:8|max:255',
                'info' => 'string|max:5000',
            ]);

            $information = " Latitude: " . $request->input('lat') . " -> Longitude: " . $request->input('lon') . " Additional info: " . $request->input('info') . "";

            // Generate PGP MESSAGE with the pgp key of customer
            $pubkey = $order->customer->pgp;
            $key = OpenPGP_Message::parse(
                OpenPGP::unarmor($pubkey, 'PGP PUBLIC KEY BLOCK')
            );

            $data = new OpenPGP_LiteralDataPacket($information, ['format' => 'u']);
            $encrypted = OpenPGP_Crypt_Symmetric::encrypt(
                $key,
                new OpenPGP_Message(array($data))
            );
            $armored = OpenPGP::enarmor($encrypted->to_bytes(), 'PGP MESSAGE');

            // Add GPS Coordinate
            $gps = new GpsCoordinate();

            $gps->info = $armored;
            $gps->order_token = $order->token;

            $gps->save();

            // Order updated with "Order send"
            $data = [
                'status' => '2',
            ];

            Order::where('vendor_id', Auth::user()->id)->where('token', $order->token)->update($data);

            return redirect()->back()->with('success', 'GPS Coordinate send with success !');

        } else {

            return redirect()->back()->with('error', 'Error contact admin !');

        }
    }

    /* END TEST MODE */


    /* _____________________________________________________________________ */


    /* PRODUCTION MODE */


    public function allSalesProdMode()
    {

        if (request()->has('query')) {

            request()->validate([
                'query' => 'required|min:3|max:255|string',
            ]);

            $query = request()->input('query');

            $sales = Order::where('vendor_id', Auth::user()->id)->where('test', 0)->where('token', 'like', "%$query%")->orderBy('id', 'DESC')->paginate(15);

            return view('seller.sale.all')->with(compact('sales'));

        } else {

            $all = Order::where('vendor_id', Auth::user()->id)->where('test', 0)->orderBy('id', 'DESC')->paginate(15);

            return view('seller.sale.all')->with(compact('all'));
        }
    }


    public function showSaleProdMode($token)
    {

        $sale = Order::where('token', $token)->where('vendor_id', Auth::user()->id)->where('test', 0)->firstOrFail();

        if ($sale->gps == 1) {

            if ($sale->status == 2) {

                $gps = GpsCoordinate::where('order_token', $sale->token)->first();

                return view('seller.sale.sale')->with(compact('sale', 'gps'));

            } else {

                return view('seller.sale.sale')->with(compact('sale'));

            }

        } else {

            return view('seller.sale.sale')->with(compact('sale'));

        }

    }

    public function canceledOrderProdMode($token)
    {

        $order = Order::where('vendor_id', Auth::user()->id)->where('token', $token)->firstOrFail();

        $data = [
            'status' => '4',
        ];

        Order::where('vendor_id', Auth::user()->id)->where('token', $order->token)->update($data);

        return redirect()->back()->with('success', 'Order status updated !');
    }


    public function orderSendProdMode($token)
    {

        $order = Order::where('vendor_id', Auth::user()->id)->where('token', $token)->firstOrFail();

        $data = [
            'status' => '2',
        ];

        Order::where('vendor_id', Auth::user()->id)->where('token', $order->token)->update($data);

        return redirect()->back()->with('success', 'Order status updated !');

    }

    public function orderSendProdModeGPS(Request $request, $token)
    {

        $order = Order::where('vendor_id', Auth::user()->id)->where('token', $token)->firstOrFail();

        if ($order->gps == 1) {

            $request->validate([
                'lat' => 'required|string|min:8|max:255',
                'lon' => 'required|string|min:8|max:255',
                'info' => 'string|max:5000',
            ]);

            $information = " Latitude: " . $request->input('lat') . " -> Longitude: " . $request->input('lon') . " Additional info: " . $request->input('info') . "";

            // Generate PGP MESSAGE with the pgp key of customer
            $pubkey = $order->customer->pgp;
            $key = OpenPGP_Message::parse(
                OpenPGP::unarmor($pubkey, 'PGP PUBLIC KEY BLOCK')
            );

            $data = new OpenPGP_LiteralDataPacket($information, ['format' => 'u']);
            $encrypted = OpenPGP_Crypt_Symmetric::encrypt(
                $key,
                new OpenPGP_Message(array($data))
            );
            $armored = OpenPGP::enarmor($encrypted->to_bytes(), 'PGP MESSAGE');

            // Add GPS Coordinate
            $gps = new GpsCoordinate();

            $gps->info = $armored;
            $gps->order_token = $order->token;

            $gps->save();

            // Order updated with "Order send"
            $data = [
                'status' => '2',
            ];

            Order::where('vendor_id', Auth::user()->id)->where('token', $order->token)->update($data);

            return redirect()->back()->with('success', 'GPS Coordinate send with success !');

        } else {

            return redirect()->back()->with('error', 'Error contact admin !');

        }
    }


    /* END PRODUCTION MODE */

}
