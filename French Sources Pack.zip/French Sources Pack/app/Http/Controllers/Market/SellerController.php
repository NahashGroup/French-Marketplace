<?php

namespace App\Http\Controllers\Market;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Auth;

use App\Models\Market\Monero;
use App\Models\Market\Vendor;
use App\Models\Market\Order;
use App\Models\Market\Product;
use App\Models\Settings;
use App\Models\Admin;
use App\Models\User;


class SellerController extends Controller
{

    public function becomeForm()
    {

        $settings = Settings::first();

        return view('become')->with(compact('settings'));

    }

    public function settings(Request $request)
    {

        $request->validate([
            'vacation' => 'integer|between:0,1',
            'desc_shop' => 'required|min:20|max:5000|string',
        ]);

        $data = [
            'vacation' => $request->input('vacation'),
            'desc_shop' => $request->input('desc_shop'),
        ];

        Vendor::where('user_id', Auth::user()->id)->update($data);

        return redirect()->back()->with('success', 'Settings updated with success !');

    }

    public function settingsForm()
    {

        $vendor = Vendor::where('user_id', Auth::user()->id)->firstOrFail();

        return view('seller.settings')->with(compact('vendor'));

    }

    public function becomeSeller()
    {

        $settings = Settings::first();
        $fee_vendor = Settings::eurToXMR($settings->fee_vendor);

        if (Settings::test() == 1) {

            $vendor = new Vendor();
            $vendor->user_id = Auth::user()->id;
            $vendor->vacation = '0';
            $vendor->desc_shop = '';
            $vendor->save();

            return redirect(route('index'))->with('success', 'You are now vendor!');

        } else {

            $w_customer = User::where('id', Auth::user()->id)->firstOrFail();
            $w_admin = Admin::where('role', 1)->firstOrFail();

            $m = new Monero();
            $t = $m->walletRPC();

            $a_admin = $t->get_address($w_admin->user->monero_index);
            $i_customer = $t->get_balance($w_customer->monero_index);

            if ($m->atomicToXMR($i_customer['unlocked_balance']) > Settings::eurToXMR($settings->fee_vendor)) {

                $transfer = $t->transfer(['destinations' => [['address' => $a_admin['address'], 'amount' => $fee_vendor]], 'account_index' => $w_customer->monero_index, 'priority' => 1]);

                $vendor = new Vendor();
                $vendor->user_id = Auth::user()->id;
                $vendor->vacation = '0';
                $vendor->desc_shop = '';
                $vendor->save();

                return redirect(route('vendor.dashboard'))->with('success', 'You are now vendor !');

            } else {

                return redirect()->back()->with('error', 'You have not enough monero unlocked !');

            }

        }

    }

    public function dashboardSeller()
    {

        if (Settings::test() == 1) {

            $cSalesTest = Order::where('vendor_id', Auth::user()->id)->where('test', 1)->count();
            $salesTest = Order::where('vendor_id', Auth::user()->id)->where('test', 1)->orderBy('id', 'DESC')->paginate(6);

            $totalEurTest = Order::where('vendor_id', AUth::user()->id)->where('test', 1)->sum('product_price');
            $totalXmrTest = Order::where('vendor_id', AUth::user()->id)->where('test', 1)->sum('monero_price');

            $products = Product::where('vendor_id', Auth::user()->id)->orderBy('id', 'DESC')->paginate(6);
            $cProducts = Product::where('vendor_id', Auth::user()->id)->count();

            return view('seller.dashboard')->with(compact('salesTest', 'products', 'cSalesTest', 'cProducts', 'totalEurTest', 'totalXmrTest'));

        } else {

            $cSales = Order::where('vendor_id', Auth::user()->id)->where('test', 0)->count();
            $sales = Order::where('vendor_id', Auth::user()->id)->where('test', 0)->orderBy('id', 'DESC')->paginate(6);

            $totalEur = Order::where('vendor_id', AUth::user()->id)->where('test', 0)->sum('product_price');
            $totalXmr = Order::where('vendor_id', AUth::user()->id)->where('test', 0)->sum('monero_price');

            $products = Product::where('vendor_id', Auth::user()->id)->orderBy('id', 'DESC')->paginate(6);
            $cProducts = Product::where('vendor_id', Auth::user()->id)->count();

            return view('seller.dashboard')->with(compact('sales', 'products', 'cSales', 'cProducts', 'totalXmr', 'totalEur'));
        }

    }

    public function vendorAll()
    {

        $vendors = Vendor::paginate(12);

        return view('shops')->with(compact('vendors'));

    }
}
