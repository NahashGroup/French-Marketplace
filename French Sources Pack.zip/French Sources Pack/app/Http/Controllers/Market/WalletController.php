<?php

namespace App\Http\Controllers\Market;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Auth;
use App\Models\Market\Monero;
use App\Models\Market\Order;
use App\Models\Settings;
use App\Models\User;
use Illuminate\Support\Str;

class WalletController extends Controller
{
    public function index()
    {

        if (Settings::test() == 0) {

            $monero = new Monero();
            $wallet = $monero->walletRPC();

            if (Auth::user()->monero_index != NULL) {

                $balance = $wallet->get_balance(Auth::user()->monero_index);
                $address = $wallet->get_address(Auth::user()->monero_index);
                $trans = $wallet->get_transfers('all', Auth::user()->monero_index);

                return view('profil.wallet')->with(compact('balance', 'address', 'trans', 'monero'));

            } else {

                $create_acc = $wallet->create_account(Auth::user()->name);

                $data = [
                    'monero_index' => intval($create_acc['account_index']),
                ];

                User::where('id', Auth::user()->id)->update($data);

                return redirect(route('profil.wallet'));
            }

        } else {

            return view('profil.wallet');

        }
    }

    public function withdrawal(Request $request)
    {

        $cOrder = Order::where('vendor_id', Auth::user()->id)->where('status', '0')->orWhere('status', '1')->where('test', '0')->count();

        if ($cOrder == 0) {

            $request->validate([
                'amount' => 'required|regex:/^[0-9]*\.?[0-9]{0,12}/|gt:0',
                'address' => 'required|string|min:95',
            ]);

            $wallet = User::where('id', Auth::user()->id)->firstOrFail();

            $m = new Monero();
            $t = $m->walletRPC();

            // Récupérer le solde actuel du portefeuille
            $balance = $t->get_balance($wallet->monero_index);

            // Vérifier si le montant demandé est inférieur ou égal au solde disponible
            if ($request->input('amount') <= $m->atomicToXMRminusFees($balance['unlocked_balance'])) {
                // Si oui, procéder au retrait

                $transfer = $t->transfer([
                    'address' => $request->input('address'),
                    'amount' => $request->input('amount'),
                    'account_index' => $wallet->monero_index,
                    'priority' => 1
                ]);

                return redirect(route('profil.wallet'))->with('success', 'You have sent ' . $request->input('amount') . ' Transaction key: ' . $transfer['tx_key']);

            } else {
                // Si le montant demandé dépasse le solde disponible, renvoyer un message d'erreur
                return redirect()->back()->with('error', 'Insufficient funds. Please enter a lower amount.');
            }

        } else {
            return redirect()->back()->with('error', 'You have orders in progress !');
        }
    }

}
