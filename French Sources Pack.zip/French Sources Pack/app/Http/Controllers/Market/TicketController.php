<?php

namespace App\Http\Controllers\Market;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Auth;

use App\Models\Market\Ticket;
use App\Models\Market\TicketMessage;
use App\Models\User;
use App\Models\Notification;
use App\Models\Admin;

class TicketController extends Controller
{
    public function all()
    {

        $tickets = Ticket::where('user_id', Auth::user()->id)->paginate(15);

        return view('profil.ticket.all')->with(compact('tickets'));

    }

    public function sendTicket(Request $request)
    {

        $request->validate([
            'title' => 'required|min:3|max:250|string',
            'subject' => 'required|string',
            'message' => 'required|min:8|max:5000|string',
            'captcha' => 'required|captcha',
        ]);

        $crypt = openssl_random_pseudo_bytes(20);
        $token = 'ticket_' . bin2hex($crypt);

        $ticket = new Ticket();

        $ticket->title = $request->input('title');
        $ticket->subject = $request->input('subject');
        $ticket->user_id = Auth::user()->id;
        $ticket->token = $token;
        $ticket->status = 0;

        $ticket_message = new TicketMessage();

        $ticket_message->message = $request->input('message');
        $ticket_message->user_id = Auth::user()->id;
        $ticket_message->ticket_token = $token;

        $admin = Admin::firstOrFail();

        $notification = new Notification();
        $notification->user_id = $admin->user_id;
        $notification->ticket_token = $token;
        $notification->from_id = Auth::user()->id;
        $notification->read = '0';

        $ticket->save();
        $ticket_message->save();
        $notification->save();

        return redirect(route('profil.ticket.all'))->with('success', 'Ticket created with success !');

    }

    public function show($token)
    {

        $ticket = Ticket::where('token', $token)->where('user_id', Auth::user()->id)->firstOrFail();

        $messages = TicketMessage::where('ticket_token', $token)->orderBy('id', 'DESC')->get();

        return view('profil.ticket.ticket')->with(compact('ticket', 'messages'));

    }

    public function send(Request $request, $token)
    {

        $request->validate([
            'message' => 'required|min:8|max:5000|string',
        ]);

        $ticket = Ticket::where('token', $token)->where('user_id', Auth::user()->id)->where('status', 0)->first();

        if (!is_null($ticket)) {

            $admin = Admin::first();

            $message = new TicketMessage();

            $message->user_id = Auth::user()->id;
            $message->message = $request->input('message');
            $message->ticket_token = $ticket->token;

            $notification = new Notification();
            $notification->user_id = $admin->user_id;
            $notification->ticket_token = $ticket->token;
            $notification->from_id = Auth::user()->id;
            $notification->read = 0;

            $notification->save();
            $message->save();

            return redirect(route('profil.ticket.show', $token))->with('success', 'Message send with success !');

        } else {

            return redirect()->back()->with('error', 'Ticket solved!');

        }

    }
}
