<?php

namespace App\Http\Controllers\Market;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Auth;
use App\Models\Market\Product;
use App\Models\Market\Order;
use App\Models\Market\Review;
use App\Models\Market\Wishlist;

class ProductController extends Controller
{
    public function index()
    {

        if (request()->has('query')) {

            request()->validate([
                'query' => 'required|min:3|max:255|string',
            ]);

            $query = request()->input('query');

            $products = Product::where('vendor_id', Auth::user()->vendor->user_id)->orderBy('id', 'DESC')->where('name', 'like', "%$query%")->where('locked', '0')->paginate(15);

            return view('seller.product.products')->with(compact('products'));

        } else {

            $all = Product::where('vendor_id', Auth::user()->vendor->user_id)->where('locked', '0')->paginate(15);

            return view('seller.product.products')->with(compact('all'));
        }

    }


    public function new(Request $request)
    {

        $request->validate([
            'name' => 'required|min:5|max:255|string',
            'price' => 'required|numeric|max:255|gt:0',
            'stock' => 'required|numeric|max:10000|gte:0',
            'description' => 'required|min:50|max:5000|string',
            'picture' => 'required|image|max:4096',
            'picsupp1' => 'image|max:4096',
            'picsupp2' => 'image|max:4096',
            'picsupp3' => 'image|max:4096',
            'delivery' => 'required|string',
            'category' => 'required|string',
        ]);

        $crypt = openssl_random_pseudo_bytes(30);
        $token = bin2hex($crypt);

        $product = new Product;
        $product->name = $request->input('name');
        $product->price = $request->input('price');
        $product->stock = $request->input('stock');
        $product->description = $request->input('description');
        $product->picture = request('picture')->store('articles', 'public');
        $product->locked = 0;
        if (request('picsupp1')) {
            $product->picsupp1 = request('picsupp1')->store('articles', 'public');
        } else {
            $product->picsupp1 = '';
        }
        if (request('picsupp2')) {
            $product->picsupp2 = request('picsupp2')->store('articles', 'public');
        } else {
            $product->picsupp2 = '';
        }
        if (request('picsupp3')) {
            $product->picsupp3 = request('picsupp3')->store('articles', 'public');
        } else {
            $product->picsupp3 = '';
        }
        $product->delivery_token = $request->input('delivery');
        $product->category_token = $request->input('category');
        $product->vendor_id = Auth::user()->id;
        $product->token = $token;

        $product->save();

        return redirect(route('index'))->with('success', 'Product added with success !');

    }

    public function edit($token)
    {

        $product = Product::where('token', $token)->where('vendor_id', Auth::user()->vendor->user_id)->where('locked', '0')->firstOrFail();

        return view('seller.product.editproduct')->with(compact('product'));

    }

    public function show($token)
    {

        $product = Product::where('token', $token)->where('locked', '0')->firstOrFail();
        $reviews = Review::where('product_token', $token)->where('status', '1')->orderBy('id', 'DESC')->paginate(10);
        $wishlist = Wishlist::where('product_token', $token)->where('user_id', Auth::user()->id)->first();

        $cOrder = Order::where('product_token', $token)->count();

        return view('product')->with(compact('product', 'cOrder', 'reviews', 'wishlist'));
    }

    public function update(Request $request, $token)
    {

        $request->validate([
            'name' => 'required|min:5|max:255|string',
            'price' => 'required|numeric|max:255|gt:0',
            'stock' => 'required|numeric|max:10000|gte:0',
            'description' => 'required|min:50|max:5000|string',
            'picture' => 'image|max:4096',
            'picsupp1' => 'image|max:4096',
            'picsupp2' => 'image|max:4096',
            'picsupp3' => 'image|max:4096',
            'delivery' => 'required|string',
            'category' => 'required|string',
        ]);


        $data = [
            'name' => $request->input('name'),
            'price' => $request->input('price'),
            'stock' => $request->input('stock'),
            'description' => $request->input('description'),
            'delivery_token' => $request->input('delivery'),
            'category_token' => $request->input('category'),
        ];

        if (request('picture')) {
            Product::where('token', $token)->where('vendor_id', Auth::user()->vendor->user_id)->update([
                'picture' => request('picture')->store('articles', 'public'),
            ]);
        }
        if (request('picsupp1')) {
            Product::where('token', $token)->where('vendor_id', Auth::user()->vendor->user_id)->update([
                'picsupp1' => request('picsupp1')->store('articles', 'public'),
            ]);
        }
        if (request('picsupp2')) {
            Product::where('token', $token)->where('vendor_id', Auth::user()->vendor->user_id)->update([
                'picsupp2' => request('picsupp2')->store('articles', 'public'),
            ]);
        }
        if (request('picsupp3')) {
            Product::where('token', $token)->where('vendor_id', Auth::user()->vendor->user_id)->update([
                'picsupp3' => request('picsupp3')->store('articles', 'public'),
            ]);
        }

        Product::where('token', $token)->where('locked', '0')->where('vendor_id', Auth::user()->vendor->user_id)->update($data);

        return redirect(route('product.all'))->with('success', 'Product updated with success !');


    }

    public function stocks()
    {

        if (request()->has('query')) {

            request()->validate([
                'query' => 'required|min:3|max:255|string',
            ]);

            $query = request()->input('query');

            $products = Product::where('vendor_id', Auth::user()->vendor->user_id)->where('locked', '0')->orderBy('id', 'DESC')->where('name', 'like', "%$query%")->orWhere('token', 'like', "%$query%")->paginate(15);

            return view('seller.stock.all')->with(compact('products'));

        } else {

            $all = Product::where('vendor_id', Auth::user()->vendor->user_id)->where('locked', '0')->paginate(15);

            return view('seller.stock.all')->with(compact('all'));
        }

    }

    public function addStock(Request $request, $token)
    {

        $request->validate([
            'stock' => 'required|numeric|max:10000|gte:0',
        ]);

        $product = Product::where('token', $token)->where('locked', '0')->firstOrFail();

        $data = [
            'stock' => $request->input('stock'),
        ];

        if ($product->vendor->user_id == Auth::user()->id) {

            Product::where('token', $token)->where('locked', '0')->update($data);

            return redirect()->back()->with('success', 'Stock added with success for ' . $product->name . ' !');

        } else {

            return redirect()->back()->with('error', 'Contact admin !');
        }
    }

}
