<?php

namespace App\Http\Controllers\Market\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Market\Category;

class CategoryController extends Controller
{
    public function all()
    {

        $categories = Category::where('parent_id', '0')->orderBy('id', 'DESC')->get();

        return view('admin.category.all')->with(compact('categories'));

    }

    public function subCatAll($id)
    {

        $subCat = Category::where('parent_id', $id)->orderBy('id', 'DESC')->get();

        $category = Category::where('id', $id)->firstOrFail();

        return view('admin.category.subcat')->with(compact('subCat', 'category'));

    }

    public function add(Request $request)
    {

        $request->validate([

            'name' => 'required|string|min:3|max:30',

        ]);

        $crypt = openssl_random_pseudo_bytes(15);
        $token = 'cat_' . bin2hex($crypt);

        $category = new Category();
        $category->name = $request->input('name');
        $category->parent_id = $request->input('category');
        $category->token = $token;

        $category->save();

        return redirect(route('admin.categories'))->with('success', 'Category added with success !');

    }

    public function editForm($id)
    {

        $category = Category::where('id', $id)->firstOrFail();

        return view('admin.category.edit')->with(compact('category'));

    }

    public function update(Request $request, $id)
    {

        $request->validate([
            'name' => 'required|min:3|max:30|string',
        ]);

        $data = [
            'name' => $request->input('name'),
        ];

        Category::where('id', $id)->update($data);

        return redirect(route('admin.categories'))->with('success', 'Category edited with success !');

    }

    public function delete($id)
    {

        Category::where('id', $id)->delete();

        return redirect()->back()->with('success', 'Category removed with success !');

    }
}
