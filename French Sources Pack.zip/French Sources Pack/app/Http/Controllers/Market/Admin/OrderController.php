<?php

namespace App\Http\Controllers\Market\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Auth;

use App\Models\Market\Order;
use App\Models\Market\GpsCoordinate;

class OrderController extends Controller
{

    /* TEST */

    public function allOrdersTest()
    {

        if (request()->has('query')) {

            request()->validate([
                'query' => 'required|min:3|max:255|string',
            ]);

            $query = request()->input('query');
            

            $orders = Order::where('test', 1)->orderBy('id', 'DESC')->where('token', 'like', "%$query%")->paginate(15);

            return view('admin.market.orders.all-test')->with(compact('orders'));

        } else {

            $all = Order::where('test', 1)->orderBy('id', 'DESC')->paginate(15);

            return view('admin.market.orders.all-test')->with(compact('all'));
        }

    }

    public function showorderTest($token)
    {

        $order = Order::where('token', $token)->where('test', 1)->firstOrFail();

        if ($order->gps == 1) {

            if ($order->status == 2) {

                $gps = GpsCoordinate::where('order_token', $order->token)->first();

                return view('admin.market.orders.order-test')->with(compact('order', 'gps'));

            } else {

                return view('admin.market.orders.order-test')->with(compact('order'));
            }

        } else {

            return view('admin.market.orders.order-test')->with(compact('order'));

        }

    }


    /* PRODUCTION */


    public function allOrdersProd()
    {

        if (request()->has('query')) {

            request()->validate([
                'query' => 'required|min:3|max:255|string',
            ]);

            $query = request()->input('query');

            $orders = Order::where('test', 0)->orderBy('id', 'DESC')->where('token', 'like', "%$query%")->paginate(15);

            return view('admin.market.orders.all')->with(compact('orders'));

        } else {

            $all = Order::where('test', 0)->orderBy('id', 'DESC')->paginate(15);

            return view('admin.market.orders.all')->with(compact('all'));
        }

    }

    public function showorderProd($token)
    {

        $order = Order::where('token', $token)->where('test', 0)->firstOrFail();

        if ($order->gps == 1) {

            if ($order->status == 2) {

                $gps = GpsCoordinate::where('order_token', $order->token)->first();

                return view('admin.market.orders.order')->with(compact('order', 'gps'));

            } else {

                return view('admin.market.orders.order')->with(compact('order'));
            }

        } else {

            return view('admin.market.orders.order')->with(compact('order'));
        }

    }
}
