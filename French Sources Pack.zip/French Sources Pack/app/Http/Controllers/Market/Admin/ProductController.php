<?php

namespace App\Http\Controllers\Market\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Market\Product;

class ProductController extends Controller
{
    public function all()
    {

        if (request()->has('query')) {

            request()->validate([
                'query' => 'required|min:3|max:255|string',
            ]);

            $query = request()->input('query');

            $products = Product::orderBy('id', 'DESC')->where('name', 'like', "%$query%")->paginate(20);

            return view('admin.market.products')->with(compact('products'));

        } else {

            $all = Product::orderBy('id', 'DESC')->paginate(20);

            return view('admin.market.products')->with(compact('all'));
        }

    }

    public function locked($token)
    {

        $product = Product::where('token', $token)->where('locked', '0')->firstOrFail();

        $data = [
            'locked' => '1',
        ];

        Product::where('token', $token)->update($data);

        return redirect()->back()->with('success', 'Product locked with success !');

    }

    public function unlocked($token)
    {

        $product = Product::where('token', $token)->where('locked', '1')->firstOrFail();

        $data = [
            'locked' => '0',
        ];

        Product::where('token', $token)->update($data);

        return redirect()->back()->with('success', 'Product unlocked with success !');

    }

}
