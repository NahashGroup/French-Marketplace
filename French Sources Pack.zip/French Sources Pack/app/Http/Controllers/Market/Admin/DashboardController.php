<?php

namespace App\Http\Controllers\Market\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\User;
use App\Models\Admin;
use App\Models\Settings;

use App\Models\Market\Ticket;
use App\Models\Market\Order;
use App\Models\Market\Product;
use App\Models\Market\Vendor;
use App\Models\Market\Monero;

class DashboardController extends Controller
{
    public function dashboard()
    {

        $m = new Monero();
        $b = $m->walletRPC();

        $get_amount = $b->get_accounts();
        $get_addr_first = $b->get_address();

        $unlock_amount = $m->atomicToXMR($get_amount['total_unlocked_balance']);
        $total_amount = $m->atomicToXMR($get_amount['total_balance']);

        $admin = Admin::get()->count(); // Total Admin
        $user = User::get()->count(); // Total Users (Admin/Vendor/Customer etc...)

        $cVendor = Vendor::get()->count(); // Total Vendor
        $cProducts = Product::get()->count(); // Total Product
        $cTickets = Ticket::where('status', '0')->get()->count();

        $products = Product::orderBy('id', 'DESC')->paginate(12); // Last 12 products 
        $users = User::orderBy('id', 'DESC')->paginate(12); // Last 12 users

        $cCustomers = $user - $admin - $cVendor; // Calcul for only customer count

        if (Settings::test() == 1) {

            $cOrdersTest = Order::where('test', '1')->get()->count();
            $cTotalXmrTest = Order::where('test', '1')->get()->sum('monero_price');
            $cTotalAmountTest = Order::where('test', '1')->get()->sum('product_price');

            return view('admin.index')->with(compact('cVendor', 'cCustomers', 'cProducts', 'users', 'products', 'cTickets', 'get_amount', 'unlock_amount', 'total_amount', 'cOrdersTest', 'cTotalXmrTest', 'cTotalAmountTest', 'get_addr_first'));

        } else {

            $cOrdersProd = Order::where('test', '0')->get()->count();
            $cTotalXmrProd = Order::where('test', '0')->get()->sum('monero_price');
            $cTotalAmountProd = Order::where('test', '0')->get()->sum('product_price');

            return view('admin.index')->with(compact('cVendor', 'cCustomers', 'cProducts', 'users', 'products', 'cTickets', 'get_amount', 'unlock_amount', 'total_amount', 'cOrdersProd', 'cTotalXmrProd', 'cTotalAmountProd', 'get_addr_first'));

        }

    }
}
