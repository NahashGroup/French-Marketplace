<?php

namespace App\Http\Controllers\Market\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Settings;

class SettingsController extends Controller
{
    public function settingsForm()
    {

        $settings = Settings::where('id', 1)->firstOrFail();

        return view('admin.settings')->with(compact('settings'));

    }

    public function settingsUpdate(Request $request)
    {

        $request->validate([
            'information_index' => 'required|min:20|max:1000|string',
            'commission' => 'required|numeric',
            'fee_vendor' => 'required|numeric',
            'become_page' => 'required|string|min:20|max:5000',
        ]);

        $data = [
            'information_index' => $request->input('information_index'),
            'fee_vendor' => $request->input('fee_vendor'),
            'commission' => $request->input('commission'),
            'active_test' => $request->input('active_test'),
            'multi_vendor' => $request->input('multi_vendor'),
            'lock_become_vendor' => $request->input('lock_become_vendor'),
            'become_page' => $request->input('become_page'),
        ];

        Settings::where('id', 1)->update($data);

        return redirect(route('admin.settings'))->with('success', 'Settins updated with success !');

    }
}
