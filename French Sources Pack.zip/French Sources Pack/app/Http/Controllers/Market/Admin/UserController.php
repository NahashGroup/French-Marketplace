<?php

namespace App\Http\Controllers\Market\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Auth;
use App\Models\User;

class UserController extends Controller
{
    public function customer()
    {

        if (request()->has('query')) {

            request()->validate([
                'query' => 'required|min:3|max:255|string',
            ]);

            $query = request()->input('query');

            $users = User::orderBy('id', 'DESC')->where('ban', 0)->where('name', 'like', "%$query%")->paginate(20);

            return view('admin.users.customers')->with(compact('users'));

        } else {

            $all = User::where('ban', 0)->paginate(20);

            return view('admin.users.customers')->with(compact('all'));
        }

    }

    public function vendor()
    {

        if (request()->has('query')) {

            request()->validate([
                'query' => 'required|min:3|max:255|string',
            ]);

            $query = request()->input('query');

            $users = User::orderBy('id', 'DESC')->where('ban', 0)->where('name', 'like', "%$query%")->paginate(20);

            return view('admin.users.vendors')->with(compact('users'));

        } else {

            $all = User::where('ban', 0)->paginate(20);

            return view('admin.users.vendors')->with(compact('all'));
        }

    }

    public function banned()
    {

        if (request()->has('query')) {

            request()->validate([
                'query' => 'required|min:3|max:255|string',
            ]);

            $query = request()->input('query');

            $users = User::orderBy('id', 'DESC')->where('ban', 1)->where('name', 'like', "%$query%")->paginate(20);

            return view('admin.users.banned')->with(compact('users'));

        } else {

            $all = User::where('ban', 1)->paginate(20);

            return view('admin.users.banned')->with(compact('all'));
        }

    }

    public function ban($name)
    {

        $data = [
            'ban' => '1',
        ];

        User::where('name', $name)->update($data);

        return redirect(route('admin.user.banned'))->with('success', 'User banned with success !');

    }

    public function unban($name)
    {

        $data = [
            'ban' => '0',
        ];

        User::where('name', $name)->update($data);

        return redirect(route('admin.user.banned'))->with('success', 'User unbanned with success !');

    }
}
