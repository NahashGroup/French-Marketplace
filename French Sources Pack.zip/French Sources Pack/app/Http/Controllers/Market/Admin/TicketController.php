<?php

namespace App\Http\Controllers\Market\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Market\Ticket;
use App\Models\Market\TicketMessage;
use App\Models\Notification;

use Auth;

class TicketController extends Controller
{
    public function all()
    {

        if (request()->has('query')) {

            request()->validate([
                'query' => 'required|min:3|max:255|string',
            ]);

            $query = request()->input('query');

            $tickets = Ticket::orderBy('id', 'DESC')->where('token', 'like', "%$query%")->paginate(20);

            return view('admin.support.all')->with(compact('tickets'));

        } else {

            $all = Ticket::orderBy('id', 'DESC')->paginate(20);

            return view('admin.support.all')->with(compact('all'));
        }

    }

    public function show($token)
    {

        $ticket = Ticket::where('token', $token)->firstOrFail();

        $messages = TicketMessage::where('ticket_token', $token)->orderBy('id', 'DESC')->get();

        return view('admin.support.ticket')->with(compact('ticket', 'messages'));

    }

    public function send(Request $request, $token)
    {

        $request->validate([
            'message' => 'required|min:8|max:5000|string',
        ]);

        $ticket = Ticket::where('token', $token)->where('status', 0)->firstOrFail();

        $message = new TicketMessage();

        $message->user_id = Auth::user()->id;
        $message->message = $request->input('message');
        $message->ticket_token = $ticket->token;

        $notification = new Notification();
        $notification->user_id = $ticket->user_id;
        $notification->ticket_token = $ticket->token;
        $notification->from_id = Auth::user()->id;
        $notification->read = 0;

        $notification->save();
        $message->save();

        return redirect(route('admin.support.show', $token))->with('success', 'Message send with success !');

    }

    public function resolve($token)
    {

        Ticket::where('token', $token)->where('status', 0)->firstOrFail();

        $data = [
            'status' => 1,
        ];

        Ticket::where('token', $token)->update($data);

        return redirect(route('admin.support.all'))->with('success', 'Ticket resolved !');

    }
}
