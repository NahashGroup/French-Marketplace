<?php

namespace App\Http\Controllers\Market;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Market\Wishlist;

use Auth;

class WishlistController extends Controller
{
    public function add($product_token)
    {

        $crypt = openssl_random_pseudo_bytes(15);
        $wishlist_token = 'wishlist_' . bin2hex($crypt);

        $wishlist = new Wishlist();

        $wishlist->token = $wishlist_token;
        $wishlist->product_token = $product_token;
        $wishlist->user_id = Auth::user()->id;

        $wishlist->save();

        return redirect()->back()->with('success', 'Product added to your wishlist!');

    }

    public function remove($token)
    {

        Wishlist::where('token', $token)->delete();

        return redirect()->back()->with('success', 'Product removed to your wishlist!');

    }

    public function wishlistAll()
    {

        $wishlists = Wishlist::where('user_id', Auth::user()->id)->get();

        return view('profil.wishlist')->with(compact('wishlists'));

    }
}
