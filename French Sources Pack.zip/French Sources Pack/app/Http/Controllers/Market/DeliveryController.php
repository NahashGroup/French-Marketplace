<?php

namespace App\Http\Controllers\Market;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Auth;
use App\Models\Market\Delivery;

class DeliveryController extends Controller
{
    public function add(Request $request)
    {

        $request->validate([
            'name' => 'required|min:3|max:255|string',
            'delay' => 'required|integer|gt:0',
            'shippingto' => 'required|integer|gt:0',
            'price' => 'required|numeric|gte:0',
        ]);

        $crypt = openssl_random_pseudo_bytes(15);
        $token = 'shipping_' . bin2hex($crypt);

        $delivery = new Delivery();

        $delivery->name = $request->input('name');
        $delivery->delay = $request->input('delay');
        $delivery->country_id = $request->input('shippingto');
        $delivery->user_id = Auth::user()->id;
        $delivery->price = $request->input('price');
        $delivery->token = $token;
        $delivery->gps = $request->input('gps');

        $delivery->save();

        return redirect(route('deliveries.all'))->with('success', 'Delivery added with success !');

    }

    public function all()
    {

        if (request()->has('query')) {

            request()->validate([
                'query' => 'required|min:3|max:255|string',
            ]);

            $query = request()->input('query');

            $deliveries = Delivery::where('user_id', Auth::user()->id)->orderBy('id', 'DESC')->where('name', 'like', "%$query%")->paginate(15);

            return view('seller.delivery.deliveries')->with(compact('deliveries'));

        } else {

            $all = Delivery::where('user_id', Auth::user()->id)->orderBy('id', 'DESC')->paginate(15);

            return view('seller.delivery.deliveries')->with(compact('all'));
        }

    }

    public function formEdit($token)
    {

        $delivery = Delivery::where('token', $token)->where('user_id', Auth::user()->id)->firstOrFail();

        return view('seller.delivery.editdelivery')->with(compact('delivery'));

    }

    public function edit(Request $request, $token)
    {

        $verif = Delivery::where('user_id', Auth::user()->id)->firstOrFail();

        if (Auth::user()->id == $verif->user_id) {

            $request->validate([
                'name' => 'required|min:3|max:255|string',
                'delay' => 'required|integer|gt:0',
                'shippingto' => 'required|integer|gt:0',
                'price' => 'required|numeric|gte:0',
            ]);

            $data = [
                'name' => $request->input('name'),
                'delay' => $request->input('delay'),
                'country_id' => $request->input('shippingto'),
                'user_id' => Auth::user()->id,
                'price' => $request->input('price'),
                'gps' => $request->input('gps'),

            ];


            Delivery::where('token', $token)->update($data);

            return redirect(route('deliveries.all'))->with('success', 'Delivery updated with success !');

        } else {

            return redirect(route('deliveries.all'))->with('error', 'Error request ! Contact admin !');

        }

    }
}
