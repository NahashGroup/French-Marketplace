<?php

namespace App\Http\Controllers\Market;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Auth;

use App\Models\Market\Review;

class ReviewController extends Controller
{
    public function all()
    {

        $reviews = Review::where('user_id', Auth::user()->id)->where('status', 0)->paginate(10);

        return view('profil.review.all')->with(compact('reviews'));

    }

    public function new($token)
    {

        $review = Review::where('token', $token)->where('user_id', Auth::user()->id)->firstOrFail();

        return view('profil.review.add')->with(compact('review'));
    }

    public function add(Request $request, $token)
    {

        $review = Review::where('token', $token)->where('user_id', Auth::user()->id)->firstOrFail();

        $request->validate([
            'message' => 'required|min:8|max:1000|string',
            'rating_qual' => 'required|numeric|gte:0|max:5',
            'rating_com' => 'required|numeric|gte:0|max:5',
            'rating_deli' => 'required|numeric|gte:0|max:5',
        ]);

        $data = [
            'message' => $request->input('message'),
            'rating_qual' => $request->input('rating_qual'),
            'rating_com' => $request->input('rating_com'),
            'rating_deli' => $request->input('rating_deli'),
            'status' => 1,
        ];

        Review::where('token', $review->token)->where('user_id', Auth::user()->id)->update($data);

        return redirect(route('profil.review.all'))->with('success', 'Review added with success !');

    }
}
