<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\User;
use App\Models\Market\Vendor;
use App\Models\Market\Order;
use App\Models\Market\Product;
use App\Models\Settings;

use DB;
use Auth;

class HomeController extends Controller
{
    public function index()
    {

        $settings = Settings::firstOrFail();
        $products = Product::where('locked', '0')->paginate(10);

        $cVendor = Vendor::count();
        $vendors = Vendor::get();

        $vendors = Order::where('status', '2')->select('vendor_id', DB::raw('count(*) as total'))->groupBy('vendor_id')->orderBy('total', 'DESC')->get();

        return view('index')->with(compact('products', 'settings', 'vendors', 'cVendor'));

    }
}
