<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Auth;

use App\Models\User;
use App\Models\Notification;
use App\Models\Message\Message;
use App\Models\Message\Conversation;

class MessageController extends Controller
{
    public function start(Request $request)
    {

        $request->validate([
            'name' => 'required|string|min:3|max:25',
            'message' => 'required|string|min:8|max:5000',
        ]);

        $user = Message::where('from_id', $request->input('name'))
            ->where('to_id', Auth::user()->id)
            ->orWhere('to_id', $request->input('name'))
            ->orWhere('from_id', Auth::user()->id)->first();

        if (!$user) {

            $name = User::where('name', $request->input('name'))->first();

            if ($name) {

                $crypt = openssl_random_pseudo_bytes(25);
                $token = 'msg_' . bin2hex($crypt);

                $message = new Message();
                $message->token = $token;
                $message->from_id = Auth::user()->id;
                $message->to_id = $name->id;
                $message->last_message = $request->input('message');

                $message->save();

                $conv = new Conversation();
                $conv->user_id = Auth::user()->id;
                $conv->message_token = $token;
                $conv->message = $request->input('message');

                $conv->save();

                return redirect(route('profiL.message.all'))->with('success', 'Message send with success !');

            } else {

                return redirect()->back()->with('error', 'User dont exist !');

            }

        } else {

            return redirect()->back()->with('error', 'User already in conversation with you !');

        }

    }

    public function add(Request $request, $token)
    {

        $message = Message::where('token', $token)->where('from_id', Auth::user()->id)->orWhere('to_id', Auth::user()->id)->firstOrFail();

        if ($message) {

            $request->validate([
                'message' => 'required|string|min:8|max:5000',
            ]);

            $conv = new Conversation();

            $conv->user_id = Auth::user()->id;
            $conv->message_token = $token;
            $conv->message = $request->input('message');

            $notification = new Notification();
            if ($message->from_id != Auth::user()->id) {
                $notification->user_id = $message->from_id;
            }
            if ($message->to_id != Auth::user()->id) {
                $notification->user_id = $message->to_id;
            }
            $notification->from_id = Auth::user()->id;
            $notification->message_token = $message->token;
            $notification->read = 0;

            $notification->save();
            $conv->save();


            $data = [
                'last_message' => $request->input('message'),
            ];

            Message::where('token', $token)->where('from_id', Auth::user()->id)->orWhere('to_id', Auth::user()->id)->update($data);

            $message->touch();

            return redirect(route('profil.message.show', $token))->with('success', 'Message send with success !');

        } else {

            return redirect()->back();

        }

    }

    public function all()
    {

        $messages = Message::where('from_id', Auth::user()->id)->orWhere('to_id', Auth::user()->id)->paginate(15);

        return view('profil.message.all')->with(compact('messages'));

    }

    public function show($token)
    {


        $messages = Conversation::where('message_token', $token)->orderBy('id', 'DESC')->get();

        $message = Message::where('from_id', Auth::user()->id)->where('token', $token)->orWhere('to_id', Auth::user()->id)->where('token', $token)->firstOrFail();

        return view('profil.message.message')->with(compact('message', 'messages'));

    }
}
