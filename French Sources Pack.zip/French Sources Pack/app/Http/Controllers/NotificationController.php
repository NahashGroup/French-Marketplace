<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Auth;

use App\Models\Notification;
use App\Models\Admin;
use App\Models\Settings;

class NotificationController extends Controller
{
    public function unread()
    {

        $notifications = Notification::where('user_id', Auth::user()->id)->where('read', 0)->paginate(20);

        $notifications_read = Notification::where('user_id', Auth::user()->id)->where('read', 1)->paginate(20);

        return view('notification')->with(compact('notifications', 'notifications_read'));

    }

    public function readMessage($token)
    {

        $data = [
            'read' => 1,
        ];

        $notification = Notification::where('user_id', Auth::user()->id)->where('read', 0)->get();

        foreach ($notification as $item) {

            $admin = Admin::first();

            if ($item->message_token != NULL) {

                Notification::where('message_token', $item->message_token)->where('user_id', Auth::user()->id)->update($data);

                return redirect(route('profil.message.show', $item->message_token));
            }

            if ($item->ticket_token != NULL) {

                Notification::where('ticket_token', $item->ticket_token)->where('user_id', Auth::user()->id)->update($data);

                if ($admin->user_id != Auth::user()->id) {

                    return redirect(route('profil.ticket.show', $item->ticket_token));

                } else {

                    return redirect(route('admin.support.show', $item->ticket_token));

                }

            }

            if ($item->order_token != NULL) {

                Notification::where('order_token', $item->order_token)->where('user_id', Auth::user()->id)->update($data);
                if (Settings::test() == 0) {

                    return redirect(route('sale.show', $item->order_token));

                } else {

                    return redirect(route('sale.test.show', $item->order_token));

                }

            }

        }

    }

}
