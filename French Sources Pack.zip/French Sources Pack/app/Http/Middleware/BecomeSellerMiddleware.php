<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

use App\Models\Settings;

class BecomeSellerMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $settings = Settings::firstOrFail();

        if($settings->lock_become_vendor != NULL){

            return $next($request);

        }else{

            return redirect()->back()->with('error','Become seller is locked for moment !');
        }
    }
}
