<?php

namespace App\Models\Market;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
    use HasFactory;

    protected $fillable = [
        'message',
        'rating_qual',
        'rating_com',
        'rating_deli',
        'product_token',
        'order_token',
        'user_id',
        'status',
        'token',
    ];

    public function product(){
        return $this->belongsTo('App\Models\Market\Product','product_token','token');
    }
    public function order(){
        return $this->belongsTo('App\Models\Market\Order','order_token','token');
    }
    public function user(){
        return $this->belongsTo('App\Models\User','user_id','id');
    }

    public function purcentTotalReview($token){

        $exists = Review::where('token', $token)->exists();

        if($exists == true){

            $rating = Review::where('token', $token)->first();

            $total = $rating->rating_qual + $rating->rating_com + $rating->rating_deli;

            $review = round($total / 3, 2);

            $purcent = ($review / 5) * 100;

            return $purcent;
        }
    }

    public function numberTotalReview($token){

        $exists = Review::where('token', $token)->exists();

        if($exists == true){

            $rating = Review::where('token', $token)->first();

            $total = $rating->rating_qual + $rating->rating_com + $rating->rating_deli;

            $review = round($total / 3, 2);

            return $review;
        }
    }
}
