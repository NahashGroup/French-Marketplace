<?php

namespace App\Models\Market;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TicketMessage extends Model
{
    use HasFactory;

    protected $fillable = [
        'message',
        'user_id',
        'ticket_token',
    ];

    public function user(){
        return $this->belongsTo('App\Models\User','user_id','id');
    }

    public function admin(){
        return $this->belongsTo('App\Models\Admin','user_id','user_id');
    }
}
