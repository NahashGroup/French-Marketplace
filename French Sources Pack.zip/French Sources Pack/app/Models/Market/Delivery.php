<?php

namespace App\Models\Market;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Delivery extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'delay',
        'country_id',
        'price',
        'user_id',
        'token',
        'gps',
    ];

    public function country(){
        return $this->belongsTo('App\Models\Country', 'country_id','id');
    }
}
