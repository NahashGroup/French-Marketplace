<?php

namespace App\Models\Market;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use MoneroIntegrations\MoneroPhp\daemonRPC;
use MoneroIntegrations\MoneroPhp\walletRPC;

class Monero extends Model
{
    use HasFactory;

    public function walletRPC(){

        $walletRPC = new walletRPC('127.0.0.1', 18082, false);
        return $walletRPC;
        
    }

    public function atomicToXMR($data){

        $final = $data * 0.000000000001;
        return $final;

    }

    public function atomicToXMRminusFees($data){

        $final = (($data * 0.000000000001) - 0.000100000000);

        if($final <= 0.000100000000){

            return 0;

        }

        return $final;

    }

}
