<?php

namespace App\Models\Market;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use DB;

class Category extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'parent_id',
        'token',
    ];

    public function parent(){

        return $this->belongTo('App\Models\Market\Category','parent_id','id');

    }

    public static function allCategorie(){

                // Get all categories in level 4 maximum in left front office
        
                $categories = DB::table('categories as c1')
                ->leftJoin('categories as c2','c2.parent_id','=','c1.id')
                ->leftJoin('categories as c3','c3.parent_id','=','c2.id')
                ->leftJoin('categories as c4','c4.parent_id','=','c3.id')
                ->select('c1.id as c1_id','c1.name as c1_name','c1.token as c1_token','c2.id as c2_id','c2.name as c2_name','c2.token as c2_token','c3.id as c3_id','c3.name as c3_name','c3.token as c3_token','c4.id  as c4_id','c4.name as c4_name','c4.token as c4_token')
                ->where('c1.parent_id','=',0)
                ->get();
        
                $all_categories = [];
                $category_c1_id = '';
                $category_c2_id = '';
                $category_c3_id = '';
                $category_c4_id = '';

                $c1_id = -1;
                $c2_id = -1;
                $c3_id = -1;
                $c4_id = -1;

                $c1_token = -1;
                $c2_token = -1;
                $c3_token = -1;
                $c4_token = -1;

        
                foreach ($categories as $k=>$category){
                    if($category->c1_id != $category_c1_id){
                        $c1_id = $c1_id +1;
                        $all_categories[$c1_id]['id'] = $category->c1_id;
                        $all_categories[$c1_id]['name'] = $category->c1_name;
                        $all_categories[$c1_id]['token'] = $category->c1_token;
                        $c2_id = -1;
                    }
                    if($category->c2_id != $category_c2_id && $category->c2_id <> NULL){
                        $c2_id = $c2_id +1;
                        $all_categories[$c1_id]['children'][$c2_id]['id'] = $category->c2_id;
                        $all_categories[$c1_id]['children'][$c2_id]['name'] = $category->c2_name;
                        $all_categories[$c1_id]['children'][$c2_id]['token'] = $category->c2_token;
                        $c3_id = -1;
                    }
                    if($category->c3_id != $category_c3_id && $category->c3_id <> NULL){
                        $c3_id = $c3_id +1;
                        $all_categories[$c1_id]['children'][$c2_id]['children'][$c3_id]['id'] = $category->c3_id;
                        $all_categories[$c1_id]['children'][$c2_id]['children'][$c3_id]['name'] = $category->c3_name;
                        $all_categories[$c1_id]['children'][$c2_id]['children'][$c3_id]['token'] = $category->c3_token;
                        $c4_id = -1;
                    }
                    if($category->c4_id != $category_c4_id && $category->c3_id <> NULL){
                        $c4_id = $c4_id +1;
                        $all_categories[$c1_id]['children'][$c2_id]['children'][$c3_id]['children'][$c4_id]['id'] = $category->c4_id;
                        $all_categories[$c1_id]['children'][$c2_id]['children'][$c3_id]['children'][$c4_id]['name'] = $category->c4_name;
                        $all_categories[$c1_id]['children'][$c2_id]['children'][$c3_id]['children'][$c4_id]['token'] = $category->c4_token;
                    }
                    $category_c1_id = $category->c1_id;
                    $category_c2_id = $category->c2_id;
                    $category_c3_id = $category->c3_id;
                    $category_c4_id = $category->c4_id;

                    $category_c1_token = $category->c1_token;
                    $category_c2_token = $category->c2_token;
                    $category_c3_token = $category->c3_token;
                    $category_c4_token = $category->c4_token;
                }
        
        
        
                return $all_categories;

    }

}
