<?php

namespace App\Models\Market;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\Market\Review;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'price',
        'stock',
        'description',
        'category_token',
        'delivery_token',
        'picture',
        'picsupp1',
        'picsupp2',
        'picsupp3',
        'vendor_id',
        'token',
        'locked',
    ];

    public function vendor(){
        return $this->belongsTo('App\Models\Market\Vendor','vendor_id','user_id');
    }

    public function delivery(){
        return $this->belongsTo('App\Models\Market\Delivery','delivery_token','token');
    }

    public function category(){
        return $this->belongsTo('App\Models\Market\Category','category_token','token');
    }

    public function order(){
        return $this->hasMany('App\Models\Market\Order','product_token','token');
    }

    public function review(){
        return $this->hasMany('App\Models\Market\Review','product_token','token');
    }

    public function qualityReviewSum($token){

        $cQuality = Review::where('product_token', $token)->count();

        if($cQuality > 0){
            
            $sQuality = Review::where('product_token', $token)->sum('rating_qual');

            $tQuality = $sQuality / $cQuality;
            $pQuality = round(($tQuality / 5) * 100, 2);

            return $pQuality;

        }else{

            return '0';

        }
    }

    public function commuReviewSum($token){
        
        $cCommu = Review::where('product_token', $token)->count();

        if($cCommu > 0){

            $sCommu = Review::where('product_token', $token)->sum('rating_com');

            $tCommu = $sCommu / $cCommu;
            $pCommu = round(($tCommu / 5) * 100, 2);

            return $pCommu;

        }else{

            return '0';

        }
    }

    public function deliReviewSum($token){
        
        $cDeli = Review::where('product_token', $token)->count();

        if($cDeli > 0){

            $sDeli = Review::where('product_token', $token)->sum('rating_deli');

            $tDeli = $sDeli / $cDeli;
            $pDeli = round(($tDeli / 5) * 100, 2);

            return $pDeli;

        }else{

            return '0';

        }
    }

    public static function priceXMR($token){

        $product = Product::where('token', $token)->firstOrFail();

        $get_price = file_get_contents('https://min-api.cryptocompare.com/data/price?fsym=XMR&tsyms=EUR');
        $xmr = json_decode($get_price, true);
        $price_item = $product->price / $xmr['EUR'];

        return $price_item;

    }
}
