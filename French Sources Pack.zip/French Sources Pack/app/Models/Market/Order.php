<?php

namespace App\Models\Market;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'product_picture',
        'product_name',
        'product_price',
        'monero_price',
        'product_token',
        'vendor_id',
        'user_id',
        'address',
        'status',
        'delivery_id',
        'token',
        'test',
    ];

    protected $guarded = [
        'status',
    ];

    public function product(){
        return $this->belongsTo('App\Models\Market\Product','product_token','token');
    }

    public function delivery(){
        return $this->belongsTo('App\Models\Market\Delivery','delivery_id','id');
    }

    public function customer(){
        return $this->belongsTo('App\Models\User','user_id','id');
    }

    public function vendor(){
        return $this->belongsTo('App\Models\Market\Vendor','vendor_id','user_id');
    }

}
