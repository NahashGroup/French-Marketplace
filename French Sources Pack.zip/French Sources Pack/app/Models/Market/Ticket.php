<?php

namespace App\Models\Market;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'token',
        'subject',
        'status',
        'user_id',
    ];

    public function user(){
        return $this->belongsTo('App\Models\User','user_id','id');
    }
}
