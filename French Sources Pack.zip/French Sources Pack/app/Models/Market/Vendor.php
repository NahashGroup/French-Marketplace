<?php

namespace App\Models\Market;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\Market\Order;

class Vendor extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'vacation',
        'desc_shop',
    ];

    public function user(){

        return $this->belongsTo('App\Models\User','user_id','id');

    }

}
