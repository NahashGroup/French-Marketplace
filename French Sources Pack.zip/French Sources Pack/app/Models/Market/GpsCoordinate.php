<?php

namespace App\Models\Market;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GpsCoordinate extends Model
{
    use HasFactory;

    protected $fillable = [
        'info',
        'order_token',
    ];

    public function order(){
        return $this->belongsTo('App\Models\Market\Order', 'order_token','token');
    }
}
