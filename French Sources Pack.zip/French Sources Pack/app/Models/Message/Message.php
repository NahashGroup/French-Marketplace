<?php

namespace App\Models\Message;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    use HasFactory;

    protected $fillable = [
        'last_message',
        'token',
        'from_id',
        'to_id',
    ];

    public function from(){
        return $this->belongsTo('App\Models\User','from_id', 'id');
    }

    public function to(){
        return $this->belongsTo('App\Models\User','to_id', 'id');
    }
}
