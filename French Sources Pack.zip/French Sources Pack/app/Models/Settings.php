<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Settings extends Model
{
    use HasFactory;

    protected $fillable = [
        'information_index',
        'active_test',
        'lock_become_vendor',
        'multi_vendor',
        'commission',
        'fee_vendor',
        'become_page',
    ];
    
    public static function test(){
        
        $active = Settings::where('id', 1)->firstOrFail();

        return $active->active_test;

    }

    public static function eurToXMR($amount){

        $get_price = file_get_contents('https://min-api.cryptocompare.com/data/price?fsym=XMR&tsyms=EUR');
        $xmr = json_decode($get_price, true);
        $priceXmr = $amount / $xmr['EUR'];

        return $priceXmr;

    }

}
