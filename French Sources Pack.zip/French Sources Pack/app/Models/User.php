<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

use App\Models\Market\Review;
use App\Models\Market\Product;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'picture',
        'pgp',
        'description',
        'password',
        'ban',
        'twofa',
        'monero_index',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    public function vendor(){

        return $this->belongsTo('App\Models\Market\Vendor','id','user_id');

    }

    public function admin(){

        return $this->belongsTo('App\Models\Admin','id','user_id');

    }

    public function totalQualityUserSum($name){

        $user = User::where('name', $name)->firstOrFail();
        $cProduct = Product::where('vendor_id', $user->id)->get();

        $cQuality = 0;
        $sQuality = 0;
        
        foreach($cProduct as $item){

            $cQuality += Review::where('product_token', $item->token)->count();
            $sQuality += Review::where('product_token', $item->token)->sum('rating_qual');

        }

        if($cQuality != 0 ){

            $tQuality = $sQuality / $cQuality;
            $pQuality = round(($tQuality / 5) * 100, 2);

            return $pQuality;

        }else{

            return '0';

        }
    }

    public function totalCommuUserSum($name){

        $user = User::where('name', $name)->firstOrFail();
        $cProduct = Product::where('vendor_id', $user->id)->get();

        $cCommu = 0;
        $sCommu = 0;
        
        foreach($cProduct as $item){

            $cCommu += Review::where('product_token', $item->token)->count();
            $sCommu += Review::where('product_token', $item->token)->sum('rating_com');

        }

        if($cCommu != 0 ){

            $tCommu = $sCommu / $cCommu;
            $pCommu = round(($tCommu / 5) * 100, 2);

            return $pCommu;

        }else{

            return '0';

        }

    }

    public function totalDeliUserSum($name){

        $user = User::where('name', $name)->firstOrFail();
        $cProduct = Product::where('vendor_id', $user->id)->get();

        $cDeli = 0;
        $sDeli = 0;
        
        foreach($cProduct as $item){

            $cDeli += Review::where('product_token', $item->token)->count();
            $sDeli += Review::where('product_token', $item->token)->sum('rating_deli');

        }

        if($cDeli != 0 ){

            $tDeli = $sDeli / $cDeli;
            $pDeli = round(($tDeli / 5) * 100, 2);

            return $pDeli;

        }else{

            return '0';

        }
    }
}
