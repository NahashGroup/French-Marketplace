<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use Auth;

class Notification extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'description',
        'ticket_token',
        'message_token',
        'order_token',
        'from_id',
        'read',
    ];

    public function message(){
        return $this->belongsTo('App\Models\Message\Message','message_token', 'token');
    }

    public function ticket(){
        return $this->belongsTo('App\Models\Market\Ticket','ticket_token', 'token');
    }

    public function order(){
        return $this->belongsTo('App\Models\Market\Order','order_token', 'token');
    }

    public function user(){
        return $this->belongsTo('App\Models\User','user_id', 'id');
    }

    public function from(){
        return $this->belongsTo('App\Models\User','from_id', 'id');
    }

    public static function unread(){

       $cNotif = Notification::where('user_id', Auth::user()->id)->where('read', 0)->count();

       return $cNotif;

    }
}
